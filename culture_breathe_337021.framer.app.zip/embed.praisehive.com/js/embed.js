"use strict";
var c = Object.defineProperty;
var a = Object.getOwnPropertySymbols;
var d = Object.prototype.hasOwnProperty,
    o = Object.prototype.propertyIsEnumerable;
var n = (t, e, r) => e in t ? c(t, e, {
        enumerable: !0,
        configurable: !0,
        writable: !0,
        value: r
    }) : t[e] = r,
    u = (t, e) => {
        for (var r in e || = {}) d.call(e, r) && n(t, r, e[r]);
        if (a)
            for (var r of a(e)) o.call(e, r) && n(t, r, e[r]);
        return t
    };

function prepareIFrameResizer() {
    var t = document.createElement("script");
    t.setAttribute("id", "praisehive-iframeResizer"), t.setAttribute("src", "https://embed.praisehive.com/js/iframeResizer.min.js"), t.setAttribute("type", "text/javascript"), t.setAttribute("async", !0), t.onload = function() {
        appendWidgets(), observeDocumentChanges()
    }, document.head.appendChild(t)
}

function appendWidgets() {
    var t = document.querySelectorAll(".praisehive-embed");
    t.forEach(function(e) {
        if (!(e.children.length > 0)) {
            var r = e.getAttribute("id").split("praisehive-")[1],
                l = e.getAttribute("data-widget-layout") || e.getAttribute("widget-layout"),
                s = l === "avatars",
                i = document.createElement("iframe");
            i.setAttribute("id", r), i.setAttribute("title", "PraiseHive - ".concat(r)), i.setAttribute("src", "https://embed.praisehive.com/".concat(r)), i.setAttribute("scrolling", "no"), i.setAttribute("frameborder", "0"), i.style.width = "0px", i.style.height = "0px", s ? e.style.width = "fit-content" : (e.style.width = "100%", i.style.minWidth = "100%"), e.appendChild(i), iFrameResize(u({
                log: !1,
                checkOrigin: !1
            }, s && {
                sizeWidth: !0
            }), "#".concat(r))
        }
    })
}

function observeDocumentChanges() {
    var t = new MutationObserver(function() {
        var e = document.querySelectorAll(".praisehive-embed");
        e.length > 0 && appendWidgets()
    });
    t.observe(document, {
        childList: !0,
        subtree: !0
    })
}
prepareIFrameResizer();