(self.webpackChunk_N_E = self.webpackChunk_N_E || []).push([
    [658], {
        9361: function(e, t) {
            "use strict";
            t.Z = function(e, t, n) {
                return t in e ? Object.defineProperty(e, t, {
                    value: n,
                    enumerable: !0,
                    configurable: !0,
                    writable: !0
                }) : e[t] = n, e
            }
        },
        1154: function(e, t) {
            "use strict";
            var n = Object.assign || function(e) {
                    for (var t = 1; t < arguments.length; t++) {
                        var n = arguments[t];
                        for (var r in n) Object.prototype.hasOwnProperty.call(n, r) && (e[r] = n[r])
                    }
                    return e
                },
                r = function() {
                    var e = arguments.length > 0 && void 0 !== arguments[0] ? arguments[0] : {},
                        t = Object.create(null);

                    function r(e, n) {
                        return t[e] = t[e] || [], t[e].push(n), this
                    }

                    function i(e) {
                        var n = arguments.length > 1 && void 0 !== arguments[1] && arguments[1];
                        return n ? t[e].splice(t[e].indexOf(n), 1) : delete t[e], this
                    }
                    return n({}, e, {
                        on: r,
                        once: function(e, t) {
                            return t._once = !0, r(e, t), this
                        },
                        off: i,
                        emit: function(e) {
                            for (var n = this, r = arguments.length, o = Array(r > 1 ? r - 1 : 0), l = 1; l < r; l++) o[l - 1] = arguments[l];
                            var u = t[e] && t[e].slice();
                            return u && u.forEach(function(t) {
                                t._once && i(e, t), t.apply(n, o)
                            }), this
                        }
                    })
                },
                i = function() {
                    var e = arguments.length > 0 && void 0 !== arguments[0] ? arguments[0] : {},
                        t = void 0,
                        n = void 0,
                        i = void 0,
                        o = void 0,
                        l = void 0,
                        u = void 0,
                        a = void 0,
                        c = void 0,
                        s = void 0,
                        f = void 0,
                        d = void 0,
                        p = void 0,
                        h = void 0,
                        m = 0 === e.packed.indexOf("data-") ? e.packed : "data-" + e.packed,
                        g = e.sizes.slice().reverse(),
                        y = !1 !== e.position,
                        v = e.container.nodeType ? e.container : document.querySelector(e.container),
                        b = {
                            all: function() {
                                return S(v.children)
                            },
                            new: function() {
                                return S(v.children).filter(function(e) {
                                    return !e.hasAttribute("" + m)
                                })
                            }
                        },
                        x = [function() {
                            i = C()
                        }, function() {
                            o = -1 === i ? g[g.length - 1] : g[i]
                        }, function() {
                            var e;
                            u = Array.apply(null, Array(e = o.columns)).map(function() {
                                return 0
                            })
                        }],
                        k = [function() {
                            d = b[t ? "new" : "all"]()
                        }, function() {
                            0 !== d.length && (p = d.map(function(e) {
                                return e.clientWidth
                            }), h = d.map(function(e) {
                                return e.clientHeight
                            }))
                        }, function() {
                            d.forEach(function(e, t) {
                                l = u.indexOf(Math.min.apply(Math, u)), e.style.position = "absolute", a = u[l] + "px", c = l * p[t] + l * o.gutter + "px", y ? (e.style.top = a, e.style.left = c) : e.style.transform = "translate3d(" + c + ", " + a + ", 0)", e.setAttribute(m, ""), s = p[t], f = h[t], s && f && (u[l] += f + o.gutter)
                            })
                        }, function() {
                            v.style.position = "relative", v.style.width = o.columns * s + (o.columns - 1) * o.gutter + "px", v.style.height = Math.max.apply(Math, u) - o.gutter + "px"
                        }],
                        w = r({
                            pack: M,
                            update: function() {
                                return t = !0, E(k), w.emit("update")
                            },
                            resize: function() {
                                var e = !(arguments.length > 0) || void 0 === arguments[0] || arguments[0];
                                return window[e ? "addEventListener" : "removeEventListener"]("resize", A), w
                            }
                        });
                    return w;

                    function E(e) {
                        e.forEach(function(e) {
                            return e()
                        })
                    }

                    function S(e) {
                        return arguments.length > 1 && void 0 !== arguments[1] && arguments[1], Array.prototype.slice.call(e)
                    }

                    function C() {
                        return g.map(function(e) {
                            return e.mq && window.matchMedia("(min-width: " + e.mq + ")").matches
                        }).indexOf(!0)
                    }

                    function A() {
                        n || (window.requestAnimationFrame(P), n = !0)
                    }

                    function P() {
                        i !== C() && (M(), w.emit("resize", o)), n = !1
                    }

                    function M() {
                        return t = !1, E(x.concat(k)), w.emit("pack")
                    }
                };
            t.Z = i
        },
        9107: function(e, t, n) {
            "use strict";
            n.d(t, {
                Z: function() {
                    return o
                }
            });
            var r = n(1689),
                i = {
                    active: !0,
                    breakpoints: {},
                    destroyHeight: "auto"
                };

            function o(e) {
                var t, n, l = r.Z.optionsHandler(),
                    u = l.merge(i, o.globalOptions),
                    a = [],
                    c = [],
                    s = ["select", "pointerUp"];

                function f(e) {
                    var r, i, o, l = "destroy" === e ? t.destroyHeight : "".concat((i = (r = n.internalEngine()).slidesInView, o = r.target, i.check(o.get(), a).map(function(e) {
                        return c[e]
                    }).reduce(function(e, t) {
                        return Math.max(e, t)
                    }, 0)), "px");
                    n.containerNode().style.height = l
                }
                var d = {
                    name: "autoHeight",
                    options: l.merge(u, e),
                    init: function(e) {
                        n = e, t = l.atMedia(d.options);
                        var r = n.internalEngine(),
                            i = r.options.axis,
                            o = r.slidesInView,
                            u = r.slideRects;
                        "y" !== i && (a = o.findSlideBounds(void 0, .5), c = u.map(function(e) {
                            return e.height
                        }), s.forEach(function(e) {
                            return n.on(e, f)
                        }), f())
                    },
                    destroy: function() {
                        s.forEach(function(e) {
                            return n.off(e, f)
                        }), f("destroy")
                    }
                };
                return d
            }
            o.globalOptions = void 0
        },
        2074: function(e, t, n) {
            "use strict";
            n.d(t, {
                Z: function() {
                    return o
                }
            });
            var r = n(1689),
                i = {
                    active: !0,
                    breakpoints: {},
                    delay: 4e3,
                    jump: !1,
                    playOnInit: !0,
                    stopOnInteraction: !0,
                    stopOnMouseEnter: !1,
                    stopOnLastSnap: !1,
                    rootNode: null
                };

            function o(e) {
                var t, n, l, u = r.Z.optionsHandler(),
                    a = u.merge(i, o.globalOptions),
                    c = 0,
                    s = !1;

                function f() {
                    n.off("pointerDown", l), t.stopOnInteraction || n.off("pointerUp", h), p(), c = 0
                }

                function d(e) {
                    p(), void 0 !== e && (s = e), c = window.setTimeout(m, t.delay)
                }

                function p() {
                    c && window.clearTimeout(c)
                }

                function h() {
                    c && (p(), d())
                }

                function m() {
                    var e = n.internalEngine().index;
                    if (t.stopOnLastSnap && e.get() === e.max) return f();
                    n.canScrollNext() ? n.scrollNext(s) : n.scrollTo(0, s), d()
                }
                var g = {
                    name: "autoplay",
                    options: u.merge(a, e),
                    init: function(e) {
                        n = e, s = (t = u.atMedia(g.options)).jump, l = t.stopOnInteraction ? f : p;
                        var r = n.internalEngine().eventStore,
                            i = n.rootNode(),
                            o = t.rootNode && t.rootNode(i) || i;
                        n.on("pointerDown", l), t.stopOnInteraction || n.on("pointerUp", h), t.stopOnMouseEnter && (r.add(o, "mouseenter", l), t.stopOnInteraction || r.add(o, "mouseleave", h)), r.add(document, "visibilitychange", function() {
                            if ("hidden" === document.visibilityState) return p();
                            h()
                        }), r.add(window, "pagehide", function(e) {
                            e.persisted && p()
                        }), t.playOnInit && d()
                    },
                    destroy: f,
                    play: d,
                    stop: p,
                    reset: h
                };
                return g
            }
            o.globalOptions = void 0
        },
        5585: function(e, t, n) {
            "use strict";
            n.d(t, {
                Z: function() {
                    return l
                }
            });
            var r = n(7294),
                i = n(1689);

            function o(e) {
                return e.concat().sort(function(e, t) {
                    return e.name > t.name ? 1 : -1
                }).map(function(e) {
                    return e.options
                })
            }

            function l(e, t) {
                void 0 === e && (e = {}), void 0 === t && (t = []);
                var n = (0, r.useRef)(i.Z.optionsHandler()),
                    u = (0, r.useRef)(e),
                    a = (0, r.useRef)(t),
                    c = (0, r.useState)(),
                    s = c[0],
                    f = c[1],
                    d = (0, r.useState)(),
                    p = d[0],
                    h = d[1],
                    m = (0, r.useCallback)(function() {
                        s && s.reInit(u.current, a.current)
                    }, [s]);
                return (0, r.useEffect)(function() {
                    if ("undefined" != typeof window && window.document && window.document.createElement && p) {
                        i.Z.globalOptions = l.globalOptions;
                        var e = (0, i.Z)(p, u.current, a.current);
                        return f(e),
                            function() {
                                return e.destroy()
                            }
                    }
                    f(void 0)
                }, [p, f]), (0, r.useEffect)(function() {
                    n.current.areEqual(u.current, e) || (u.current = e, m())
                }, [e, m]), (0, r.useEffect)(function() {
                    ! function(e, t) {
                        if (e.length !== t.length) return !1;
                        var n = i.Z.optionsHandler().areEqual,
                            r = o(e),
                            l = o(t);
                        return r.every(function(e, t) {
                            return n(e, l[t])
                        })
                    }(a.current, t) && (a.current = t, m())
                }, [t, m]), [h, s]
            }
            l.globalOptions = void 0
        },
        1689: function(e, t, n) {
            "use strict";

            function r(e) {
                return "number" == typeof e
            }

            function i(e) {
                return "[object Object]" === Object.prototype.toString.call(e)
            }

            function o(e) {
                var t;
                return i(e) || Array.isArray(e)
            }

            function l(e) {
                return Math.abs(e)
            }

            function u(e) {
                return e ? e / l(e) : 0
            }

            function a(e) {
                return f(e).map(Number)
            }

            function c(e) {
                return e[s(e)]
            }

            function s(e) {
                return Math.max(0, e.length - 1)
            }

            function f(e) {
                return Object.keys(e)
            }

            function d(e, t) {
                var n = l(e - t);

                function r(t) {
                    return t < e
                }

                function i(e) {
                    return e > t
                }

                function o(n) {
                    var r, i;
                    return n < e || n > t
                }
                return {
                    length: n,
                    max: t,
                    min: e,
                    constrain: function(n) {
                        var r;
                        return o(n) ? n < e ? e : t : n
                    },
                    reachedAny: o,
                    reachedMax: i,
                    reachedMin: r,
                    removeOffset: function(e) {
                        return n ? e - n * Math.ceil((e - t) / n) : e
                    }
                }
            }

            function p() {
                var e = [],
                    t = {
                        add: function(n, r, i, o) {
                            return void 0 === o && (o = !1), n.addEventListener(r, i, o), e.push(function() {
                                return n.removeEventListener(r, i, o)
                            }), t
                        },
                        removeAll: function() {
                            return e = e.filter(function(e) {
                                return e()
                            }), t
                        }
                    };
                return t
            }

            function h(e) {
                var t = e;

                function n() {
                    return t
                }

                function i(e) {
                    return t /= e, l
                }

                function o(e) {
                    return r(e) ? e : e.get()
                }
                var l = {
                    add: function(e) {
                        return t += o(e), l
                    },
                    divide: i,
                    get: n,
                    multiply: function(e) {
                        return t *= e, l
                    },
                    normalize: function() {
                        return 0 !== t && i(t), l
                    },
                    set: function(e) {
                        return t = o(e), l
                    },
                    subtract: function(e) {
                        return t -= o(e), l
                    }
                };
                return l
            }

            function m(e, t, n) {
                var r = "x" === e.scroll ? function(e) {
                        return "translate3d(".concat(e, "px,0px,0px)")
                    } : function(e) {
                        return "translate3d(0px,".concat(e, "px,0px)")
                    },
                    i = n.style,
                    o = !1;

                function l(e) {
                    o = !e
                }
                return {
                    clear: function() {
                        o || (i.transform = "", n.getAttribute("style") || n.removeAttribute("style"))
                    },
                    to: function(e) {
                        o || (i.transform = r(t.apply(e.get())))
                    },
                    toggleActive: l
                }
            }
            n.d(t, {
                Z: function() {
                    return v
                }
            });
            var g = {
                align: "center",
                axis: "x",
                containScroll: "",
                direction: "ltr",
                slidesToScroll: 1,
                breakpoints: {},
                dragFree: !1,
                draggable: !0,
                inViewThreshold: 0,
                loop: !1,
                skipSnaps: !1,
                speed: 10,
                startIndex: 0,
                active: !0
            };

            function y() {
                function e(e, t) {
                    return function e(t, n) {
                        return [t, n].reduce(function(t, n) {
                            return f(n).forEach(function(r) {
                                var o = t[r],
                                    l = n[r],
                                    u = i(o) && i(l);
                                t[r] = u ? e(o, l) : l
                            }), t
                        }, {})
                    }(e, t || {})
                }
                return {
                    merge: e,
                    areEqual: function(e, t) {
                        var n = JSON.stringify(f(e.breakpoints || {})),
                            r = JSON.stringify(f(t.breakpoints || {}));
                        return n === r && function e(t, n) {
                            var r = f(t),
                                i = f(n);
                            return r.length === i.length && r.every(function(r) {
                                var i = t[r],
                                    l = n[r];
                                return "function" == typeof i ? "".concat(i) === "".concat(l) : o(i) && o(l) ? e(i, l) : i === l
                            })
                        }(e, t)
                    },
                    atMedia: function(t) {
                        var n = t.breakpoints || {},
                            r = f(n).filter(function(e) {
                                return window.matchMedia(e).matches
                            }).map(function(e) {
                                return n[e]
                            }).reduce(function(t, n) {
                                return e(t, n)
                            }, {});
                        return e(t, r)
                    }
                }
            }

            function v(e, t, n) {
                var i, o, f, b, x, k = p(),
                    w = y(),
                    E = function() {
                        var e = y(),
                            t = e.atMedia,
                            n = e.areEqual,
                            r = [],
                            i = [];

                        function o(e) {
                            var r = t(e.options);
                            return function() {
                                return !n(r, t(e.options))
                            }
                        }
                        return {
                            init: function(e, n) {
                                return i = e.map(o), (r = e.filter(function(e) {
                                    return t(e.options).active
                                })).forEach(function(e) {
                                    return e.init(n)
                                }), e.reduce(function(e, t) {
                                    var n;
                                    return Object.assign(e, ((n = {})[t.name] = t, n))
                                }, {})
                            },
                            destroy: function() {
                                r = r.filter(function(e) {
                                    return e.destroy()
                                })
                            },
                            haveChanged: function() {
                                return i.some(function(e) {
                                    return e()
                                })
                            }
                        }
                    }(),
                    S = function() {
                        var e = {};

                        function t(t) {
                            return e[t] || []
                        }
                        var n = {
                            emit: function(e) {
                                return t(e).forEach(function(t) {
                                    return t(e)
                                }), n
                            },
                            off: function(r, i) {
                                return e[r] = t(r).filter(function(e) {
                                    return e !== i
                                }), n
                            },
                            on: function(r, i) {
                                return e[r] = t(r).concat([i]), n
                            }
                        };
                        return n
                    }(),
                    C = S.on,
                    A = S.off,
                    P = !1,
                    M = w.merge(g, v.globalOptions),
                    L = w.merge(M),
                    T = [],
                    O = 0;

                function F(t, n) {
                    if (!P) {
                        var g, y, v, k, C, A, I, D, z, R, N, B, _, $, H, V, U, Z, W, J, K, G, Q, Y, X, ee, et, en, er, ei, eo, el, eu, ea, ec, es, ef, ed, ep, eh, em, eg, ey, ev, eb, ex, ek, ew, eE, eS, eC, eA, eP, eM, eL, eT, eO, eF, eI, ej, eD, ez, eR, eN, eB, e_, e$, eH, eq, eV, eU, eZ, eW, eJ, eK, eG, eQ, eY, eX, e0, e1, e6, e3, e2, e9, e4, e5, e7, e8, te, tt, tn, tr, ti, to, tl, tu, ta, tc, ts, tf, td, tp, th, tm, tg, ty, tv, tb, tx;
                        if (g = "container" in e && e.container, y = "slides" in e && e.slides, f = "root" in e ? e.root : e, b = g || f.children[0], x = y || [].slice.call(b.children), M = w.merge(M, t), L = w.atMedia(M), v = f, k = b, C = x, D = (A = L).align, z = A.axis, R = A.direction, N = A.startIndex, B = A.inViewThreshold, _ = A.loop, $ = A.speed, H = A.dragFree, V = A.slidesToScroll, U = A.skipSnaps, Z = A.containScroll, W = k.getBoundingClientRect(), J = C.map(function(e) {
                                return e.getBoundingClientRect()
                            }), K = function(e) {
                                var t = "rtl" === e ? -1 : 1;

                                function n(e) {
                                    return e * t
                                }
                                return {
                                    apply: n
                                }
                            }(R), X = "y" == (Y = "y" === z ? "y" : "x") ? "top" : "rtl" === R ? "right" : "left", ee = "y" === Y ? "bottom" : "rtl" === R ? "left" : "right", en = (et = {
                                scroll: Y,
                                cross: "y" === z ? "x" : "y",
                                startEdge: X,
                                endEdge: ee,
                                measureSize: function(e) {
                                    var t = e.width,
                                        n = e.height;
                                    return "x" === Y ? t : n
                                }
                            }).measureSize(W), ei = {
                                measure: function(e) {
                                    return en * (e / 100)
                                }
                            }, eo = function(e, t) {
                                var n = {
                                    start: i,
                                    center: function(e) {
                                        var n;
                                        return n = e, (t - n) / 2
                                    },
                                    end: o
                                };

                                function i() {
                                    return 0
                                }

                                function o(e) {
                                    return t - e
                                }
                                return {
                                    measure: function(i) {
                                        return r(e) ? t * Number(e) : n[e](i)
                                    }
                                }
                            }(D, en), el = !_ && "" !== Z, ef = _ || "" !== Z, ed = et.measureSize, ep = et.startEdge, eh = et.endEdge, em = function() {
                                if (!ef) return 0;
                                var e = J[0];
                                return l(W[ep] - e[ep])
                            }(), eg = function() {
                                if (!ef) return 0;
                                var e = window.getComputedStyle(c(C));
                                return parseFloat(e.getPropertyValue("margin-".concat(eh)))
                            }(), ey = J.map(ed), ev = J.map(function(e, t, n) {
                                var r = t === s(n);
                                return t ? r ? ey[t] + eg : n[t + 1][ep] - e[ep] : ey[t] + em
                            }).map(l), ex = (eb = {
                                slideSizes: ey,
                                slideSizesWithGaps: ev
                            }).slideSizes, ek = eb.slideSizesWithGaps, eC = r(V), eA = {
                                groupSlides: function(e) {
                                    var t, n, r;
                                    return eC ? a(e).filter(function(e) {
                                        return e % V == 0
                                    }).map(function(t) {
                                        return e.slice(t, t + V)
                                    }) : a(e).reduce(function(e, t) {
                                        var n = ek.slice(c(e), t + 1).reduce(function(e, t) {
                                            return e + t
                                        }, 0);
                                        return !t || n > en ? e.concat(t) : e
                                    }, []).map(function(t, n, r) {
                                        return e.slice(t, r[n + 1])
                                    })
                                }
                            }, ej = et.startEdge, eD = et.endEdge, eR = (ez = eA.groupSlides)(J).map(function(e) {
                                return c(e)[eD] - e[0][ej]
                            }).map(l).map(eo.measure), eN = J.map(function(e) {
                                return W[ej] - e[ej]
                            }).map(function(e) {
                                return -l(e)
                            }), tv = c(eN) - c(ek), eB = ez(eN).map(function(e) {
                                return e[0]
                            }).map(function(e, t, n) {
                                var r = t === s(n);
                                return el && !t ? 0 : el && r ? tv : e + eR[t]
                            }), e$ = (e_ = {
                                snaps: eN,
                                snapsAligned: eB
                            }).snaps, eH = e_.snapsAligned, eq = -c(e$) + c(ek), eQ = (eJ = d(-eq + en, eH[0]), eK = eH.map(eJ.constrain), {
                                snapsContained: eG = function() {
                                    if (eq <= en) return [eJ.max];
                                    if ("keepSnaps" === Z) return eK;
                                    var e, t, n, r, i = (e = eK[0], t = c(eK), n = eK.lastIndexOf(e), r = eK.indexOf(t) + 1, d(n, r)),
                                        o = i.min,
                                        l = i.max;
                                    return eK.slice(o, l)
                                }()
                            }).snapsContained, e3 = (tb = (eY = el ? eQ : eH)[0], tx = c(eY), {
                                limit: e6 = d(_ ? tb - eq : tx, tb)
                            }).limit, e9 = (e2 = function e(t, n, r) {
                                var i = d(0, t),
                                    o = i.min,
                                    u = i.constrain,
                                    a = t + 1,
                                    c = s(n);

                                function s(e) {
                                    return r ? l((a + e) % a) : u(e)
                                }

                                function f() {
                                    return c
                                }

                                function p(e) {
                                    return c = s(e), h
                                }
                                var h = {
                                    add: function(e) {
                                        return p(c + e)
                                    },
                                    clone: function() {
                                        return e(t, c, r)
                                    },
                                    get: f,
                                    set: p,
                                    min: o,
                                    max: t
                                };
                                return h
                            }(s(eY), N, _)).clone(), e4 = a(C), e5 = function(e) {
                                var t = 0;

                                function n(e, n) {
                                    return function() {
                                        !!t === e && n()
                                    }
                                }

                                function r() {
                                    t = window.requestAnimationFrame(e)
                                }
                                return {
                                    proceed: n(!0, r),
                                    start: n(!1, r),
                                    stop: n(!0, function() {
                                        window.cancelAnimationFrame(t), t = 0
                                    })
                                }
                            }(function() {
                                _ || ty.scrollBounds.constrain(ty.dragHandler.pointerDown()), ty.scrollBody.seek(te).update();
                                var e = ty.scrollBody.settle(te);
                                e && !ty.dragHandler.pointerDown() && (ty.animation.stop(), S.emit("settle")), e || S.emit("scroll"), _ && (ty.scrollLooper.loop(ty.scrollBody.direction()), ty.slideLooper.loop()), ty.translate.to(e8), ty.animation.proceed()
                            }), e8 = h(e7 = eY[e2.get()]), te = h(e7), tt = function(e, t, n) {
                                var r, i = h(0),
                                    o = h(0),
                                    l = h(0),
                                    a = 0,
                                    c = t,
                                    s = n;

                                function f() {
                                    return a
                                }

                                function d(e) {
                                    return c = e, m
                                }

                                function p(e) {
                                    return s = e, m
                                }
                                var m = {
                                    direction: f,
                                    seek: function(t) {
                                        l.set(t).subtract(e);
                                        var n, r, f, d, p, h = (n = l.get(), 0 + ((d = c) - 0) * ((n - 0) / 100));
                                        return a = u(l.get()), l.normalize().multiply(h).subtract(i), l.divide(s), o.add(l), m
                                    },
                                    settle: function(t) {
                                        var n, r = (n = t.get() - e.get(), !(Math.round(100 * n) / 100));
                                        return r && e.set(t), r
                                    },
                                    update: function() {
                                        i.add(o), e.add(i), o.multiply(0)
                                    },
                                    useBaseMass: function() {
                                        return p(n)
                                    },
                                    useBaseSpeed: function() {
                                        return d(t)
                                    },
                                    useMass: p,
                                    useSpeed: d
                                };
                                return m
                            }(e8, $, 1), tn = function(e, t, n, r, i) {
                                var o = r.reachedAny,
                                    a = r.removeOffset,
                                    c = r.constrain;

                                function s(e) {
                                    return e.concat().sort(function(e, t) {
                                        return l(e) - l(t)
                                    })[0]
                                }

                                function f(t, r) {
                                    var i = [t, t + n, t - n];
                                    if (!e) return i[0];
                                    if (!r) return s(i);
                                    var o = i.filter(function(e) {
                                        return u(e) === r
                                    });
                                    return s(o)
                                }
                                return {
                                    byDistance: function(n, r) {
                                        var u, s, d = i.get() + n,
                                            p = (s = e ? a(d) : c(d), {
                                                index: t.map(function(e) {
                                                    return e - s
                                                }).map(function(e) {
                                                    return f(e, 0)
                                                }).map(function(e, t) {
                                                    return {
                                                        diff: e,
                                                        index: t
                                                    }
                                                }).sort(function(e, t) {
                                                    return l(e.diff) - l(t.diff)
                                                })[0].index,
                                                distance: s
                                            }),
                                            h = p.index,
                                            m = p.distance,
                                            g = !e && o(d);
                                        if (!r || g) return {
                                            index: h,
                                            distance: n
                                        };
                                        var y = n + f(t[h] - m, 0);
                                        return {
                                            index: h,
                                            distance: y
                                        }
                                    },
                                    byIndex: function(e, n) {
                                        var r = f(t[e] - i.get(), n);
                                        return {
                                            index: e,
                                            distance: r
                                        }
                                    },
                                    shortcut: f
                                }
                            }(_, eY, eq, e3, te), tr = function(e, t, n, r, i, o) {
                                function l(r) {
                                    var l = r.distance,
                                        u = r.index !== t.get();
                                    l && (e.start(), i.add(l)), u && (n.set(t.get()), t.set(r.index), o.emit("select"))
                                }
                                return {
                                    distance: function(e, t) {
                                        l(r.byDistance(e, t))
                                    },
                                    index: function(e, n) {
                                        var i = t.clone().set(e);
                                        l(r.byIndex(i.get(), n))
                                    }
                                }
                            }(e5, e2, e9, tn, te, S), ti = function(e, t, n, r, i, o, l) {
                                var u = i.removeOffset,
                                    a = i.constrain,
                                    c = o ? [0, t, -t] : [0],
                                    s = f(c, l);

                                function f(t, i) {
                                    var o, l, u = (l = i || 0, n.map(function(e) {
                                        return d(.5, e - .5).constrain(e * l)
                                    }));
                                    return (t || c).reduce(function(t, i) {
                                        var o = r.map(function(t, r) {
                                            return {
                                                start: t - n[r] + u[r] + i,
                                                end: t + e - u[r] + i,
                                                index: r
                                            }
                                        });
                                        return t.concat(o)
                                    }, [])
                                }
                                return {
                                    check: function(e, t) {
                                        var n = o ? u(e) : a(e);
                                        return (t || s).reduce(function(e, t) {
                                            var r, i = t.index,
                                                o = t.start,
                                                l = t.end;
                                            return !(-1 !== e.indexOf(i)) && o < n && l > n ? e.concat([i]) : e
                                        }, [])
                                    },
                                    findSlideBounds: f
                                }
                            }(en, eq, ex, e$, e3, _, B), to = function(e, t, n, r, i, o, a, c, s, f, d, m, g, y, v, b) {
                                var x = e.cross,
                                    k = ["INPUT", "SELECT", "TEXTAREA"],
                                    w = h(0),
                                    E = p(),
                                    S = p(),
                                    C = g.measure(20),
                                    A = {
                                        mouse: 300,
                                        touch: 400
                                    },
                                    P = {
                                        mouse: 500,
                                        touch: 600
                                    },
                                    M = v ? 5 : 16,
                                    L = 0,
                                    T = 0,
                                    O = !1,
                                    F = !1,
                                    I = !1,
                                    j = !1;

                                function D(e) {
                                    if (!(j = "mousedown" === e.type) || 0 === e.button) {
                                        var t, u, a, c, f, d = (t = r.get(), l(t - (u = o.get())) >= 2),
                                            p = j || !d,
                                            h = (c = (a = e.target).nodeName || "", !(k.indexOf(c) > -1)),
                                            g = d || j && h;
                                        O = !0, i.pointerDown(e), w.set(r), r.set(o), s.useBaseMass().useSpeed(80), f = j ? document : n, S.add(f, "touchmove", z).add(f, "touchend", R).add(f, "mousemove", z).add(f, "mouseup", R), L = i.readPoint(e), T = i.readPoint(e, x), m.emit("pointerDown"), p && (I = !1), g && e.preventDefault()
                                    }
                                }

                                function z(e) {
                                    if (!F && !j) {
                                        if (!e.cancelable) return R(e);
                                        var n, o, u, c, s = i.readPoint(e),
                                            f = i.readPoint(e, x),
                                            d = (o = L, l(s - o)),
                                            p = (c = T, l(f - c));
                                        if (!(F = d > p) && !I) return R(e)
                                    }
                                    var h = i.pointerMove(e);
                                    !I && h && (I = !0), a.start(), r.add(t.apply(h)), e.preventDefault()
                                }

                                function R(e) {
                                    var n, o, a, p, h, g, x, k = f.byDistance(0, !1).index !== d.get(),
                                        E = i.pointerUp(e) * (v ? P : A)[j ? "mouse" : "touch"],
                                        L = (n = t.apply(E), p = (a = d.clone().add(-1 * u(n))).get() === d.min || a.get() === d.max, h = f.byDistance(n, !v).distance, v || l(n) < C ? h : !y && p ? .4 * h : b && k ? .5 * h : f.byIndex(a.get(), 0).distance),
                                        T = function(e, t) {
                                            if (0 === e || 0 === t || l(e) <= l(t)) return 0;
                                            var n, r, i = (n = l(e), r = l(t), l(n - r));
                                            return l(i / e)
                                        }(E, L),
                                        D = (g = r.get(), l(g - (x = w.get())) >= .5),
                                        z = k && T > .75,
                                        R = l(E) < C;
                                    D && !j && (I = !0), F = !1, O = !1, S.removeAll(), s.useSpeed(R ? 9 : z ? 10 : M).useMass(z ? 1 + 2.5 * T : 1), c.distance(L, !v), j = !1, m.emit("pointerUp")
                                }

                                function N(e) {
                                    I && e.preventDefault()
                                }

                                function B() {
                                    return !I
                                }

                                function _() {
                                    return O
                                }
                                return {
                                    addActivationEvents: function() {
                                        E.add(n, "touchmove", function() {}).add(n, "touchend", function() {}).add(n, "touchstart", D).add(n, "mousedown", D).add(n, "touchcancel", R).add(n, "contextmenu", R).add(n, "click", N)
                                    },
                                    clickAllowed: B,
                                    pointerDown: _,
                                    removeAllEvents: function() {
                                        E.removeAll(), S.removeAll()
                                    }
                                }
                            }(et, K, v, te, function(e) {
                                var t, n;

                                function r(e) {
                                    return "undefined" != typeof TouchEvent && e instanceof TouchEvent
                                }

                                function i(e) {
                                    return e.timeStamp
                                }

                                function o(t, n) {
                                    var i = n || e.scroll,
                                        o = "client".concat("x" === i ? "X" : "Y");
                                    return (r(t) ? t.touches[0] : t)[o]
                                }
                                return {
                                    isTouchEvent: r,
                                    pointerDown: function(e) {
                                        return t = e, n = e, o(e)
                                    },
                                    pointerMove: function(e) {
                                        var r = o(e) - o(n),
                                            l = i(e) - i(t) > 170;
                                        return n = e, l && (t = e), r
                                    },
                                    pointerUp: function(e) {
                                        if (!t || !n) return 0;
                                        var r = o(n) - o(t),
                                            u = i(e) - i(t),
                                            a = i(e) - i(n) > 170,
                                            c = r / u;
                                        return u && !a && l(c) > .1 ? c : 0
                                    },
                                    readPoint: o
                                }
                            }(et), e8, e5, tr, tt, tn, e2, S, ei, _, H, U), O = (i = ty = {
                                containerRect: W,
                                slideRects: J,
                                animation: e5,
                                axis: et,
                                direction: K,
                                dragHandler: to,
                                eventStore: p(),
                                percentOfView: ei,
                                index: e2,
                                indexPrevious: e9,
                                limit: e3,
                                location: e8,
                                options: A,
                                scrollBody: tt,
                                scrollBounds: function(e, t, n, r, i) {
                                    var o = i.measure(10),
                                        u = i.measure(50),
                                        a = !1;

                                    function c(e) {
                                        a = !e
                                    }
                                    return {
                                        constrain: function(i) {
                                            if (!a && e.reachedAny(n.get()) && e.reachedAny(t.get())) {
                                                var c = l(e[e.reachedMin(t.get()) ? "min" : "max"] - t.get()),
                                                    s = n.get() - t.get();
                                                n.subtract(s * Math.min(c / u, .85)), !i && l(s) < o && (n.set(e.constrain(n.get())), r.useSpeed(10).useMass(3))
                                            }
                                        },
                                        toggleActive: c
                                    }
                                }(e3, e8, te, tt, ei),
                                scrollLooper: (ta = e8, tc = [e8, te], td = (tf = d(ts = e3.min + .1, e3.max + .1)).reachedMin, tp = tf.reachedMax, {
                                    loop: function(e) {
                                        var t;
                                        if (1 === e ? !!tp(ta.get()) : !!(-1 === e && td(ta.get()))) {
                                            var n = eq * (-1 * e);
                                            tc.forEach(function(e) {
                                                return e.add(n)
                                            })
                                        }
                                    }
                                }),
                                scrollProgress: (tm = e3.max, tg = e3.length, {
                                    get: function(e) {
                                        return -((e - tm) / tg)
                                    }
                                }),
                                scrollSnaps: eY,
                                scrollTarget: tn,
                                scrollTo: tr,
                                slideLooper: function(e, t, n, r, i, o, l, u, c) {
                                    var s, f, d = a(i),
                                        p = a(i).reverse(),
                                        g = (s = v(p, o[0] - 1), b(s, "end")).concat((f = v(d, n - o[0] - 1), b(f, "start")));

                                    function y(e, t) {
                                        return e.reduce(function(e, t) {
                                            return e - i[t]
                                        }, t)
                                    }

                                    function v(e, t) {
                                        return e.reduce(function(e, n) {
                                            return y(e, t) > 0 ? e.concat([n]) : e
                                        }, [])
                                    }

                                    function b(n, i) {
                                        var o = "start" === i,
                                            a = l.findSlideBounds([o ? -r : r]);
                                        return n.map(function(n) {
                                            var i = o ? 0 : -r,
                                                l = o ? r : 0,
                                                s = a.filter(function(e) {
                                                    return e.index === n
                                                })[0][o ? "end" : "start"],
                                                f = h(-1),
                                                d = h(-1),
                                                p = m(e, t, c[n]);
                                            return {
                                                index: n,
                                                location: d,
                                                translate: p,
                                                target: function() {
                                                    return f.set(u.get() > s ? i : l)
                                                }
                                            }
                                        })
                                    }
                                    return {
                                        canLoop: function() {
                                            return g.every(function(e) {
                                                var t = e.index;
                                                return .1 >= y(d.filter(function(e) {
                                                    return e !== t
                                                }), n)
                                            })
                                        },
                                        clear: function() {
                                            g.forEach(function(e) {
                                                return e.translate.clear()
                                            })
                                        },
                                        loop: function() {
                                            g.forEach(function(e) {
                                                var t = e.target,
                                                    n = e.translate,
                                                    r = e.location,
                                                    i = t();
                                                i.get() !== r.get() && (0 === i.get() ? n.clear() : n.to(i), r.set(i))
                                            })
                                        },
                                        loopPoints: g
                                    }
                                }(et, K, en, eq, ek, eY, ti, e8, C),
                                slidesToScroll: eA,
                                slidesInView: ti,
                                slideIndexes: e4,
                                target: te,
                                translate: m(et, K, k)
                            }).axis.measureSize(f.getBoundingClientRect()), !L.active) return j();
                        if (i.translate.to(i.location), T = n || T, o = E.init(T, q), L.loop) {
                            if (!i.slideLooper.canLoop()) return j(), F({
                                loop: !1
                            }, n);
                            i.slideLooper.loop()
                        }
                        L.draggable && b.offsetParent && x.length && i.dragHandler.addActivationEvents()
                    }
                }

                function I(e, t) {
                    var n = R();
                    j(), F(w.merge({
                        startIndex: n
                    }, e), t), S.emit("reInit")
                }

                function j() {
                    i.dragHandler.removeAllEvents(), i.animation.stop(), i.eventStore.removeAll(), i.translate.clear(), i.slideLooper.clear(), E.destroy()
                }

                function D(e) {
                    var t = i[e ? "target" : "location"].get(),
                        n = L.loop ? "removeOffset" : "constrain";
                    return i.slidesInView.check(i.limit[n](t))
                }

                function z(e, t, n) {
                    L.active && !P && (i.scrollBody.useBaseMass().useSpeed(t ? 100 : L.speed), i.scrollTo.index(e, n || 0))
                }

                function R() {
                    return i.index.get()
                }

                function N() {
                    return o
                }

                function B() {
                    return i
                }

                function _() {
                    return f
                }

                function $() {
                    return b
                }

                function H() {
                    return x
                }
                var q = {
                    canScrollNext: function() {
                        return i.index.clone().add(1).get() !== R()
                    },
                    canScrollPrev: function() {
                        return i.index.clone().add(-1).get() !== R()
                    },
                    clickAllowed: function() {
                        return i.dragHandler.clickAllowed()
                    },
                    containerNode: $,
                    internalEngine: B,
                    destroy: function() {
                        P || (P = !0, k.removeAll(), j(), S.emit("destroy"))
                    },
                    off: A,
                    on: C,
                    plugins: N,
                    previousScrollSnap: function() {
                        return i.indexPrevious.get()
                    },
                    reInit: I,
                    rootNode: _,
                    scrollNext: function(e) {
                        z(i.index.clone().add(1).get(), !0 === e, -1)
                    },
                    scrollPrev: function(e) {
                        z(i.index.clone().add(-1).get(), !0 === e, 1)
                    },
                    scrollProgress: function() {
                        return i.scrollProgress.get(i.location.get())
                    },
                    scrollSnapList: function() {
                        return i.scrollSnaps.map(i.scrollProgress.get)
                    },
                    scrollTo: z,
                    selectedScrollSnap: R,
                    slideNodes: H,
                    slidesInView: D,
                    slidesNotInView: function(e) {
                        var t = D(e);
                        return i.slideIndexes.filter(function(e) {
                            return -1 === t.indexOf(e)
                        })
                    }
                };
                return F(t, n), k.add(window, "resize", function() {
                    var e = w.atMedia(M),
                        t = !w.areEqual(e, L),
                        n = O !== i.axis.measureSize(f.getBoundingClientRect()),
                        r = E.haveChanged();
                    (n || t || r) && I(), S.emit("resize")
                }), setTimeout(function() {
                    return S.emit("init")
                }, 0), q
            }
            v.globalOptions = void 0, v.optionsHandler = y
        },
        4470: function(e) {
            "use strict";
            var t = Object.prototype.hasOwnProperty,
                n = Object.prototype.toString,
                r = Object.defineProperty,
                i = Object.getOwnPropertyDescriptor,
                o = function(e) {
                    return "function" == typeof Array.isArray ? Array.isArray(e) : "[object Array]" === n.call(e)
                },
                l = function(e) {
                    if (!e || "[object Object]" !== n.call(e)) return !1;
                    var r, i = t.call(e, "constructor"),
                        o = e.constructor && e.constructor.prototype && t.call(e.constructor.prototype, "isPrototypeOf");
                    if (e.constructor && !i && !o) return !1;
                    for (r in e);
                    return void 0 === r || t.call(e, r)
                },
                u = function(e, t) {
                    r && "__proto__" === t.name ? r(e, t.name, {
                        enumerable: !0,
                        configurable: !0,
                        value: t.newValue,
                        writable: !0
                    }) : e[t.name] = t.newValue
                },
                a = function(e, n) {
                    if ("__proto__" === n) {
                        if (!t.call(e, n)) return;
                        if (i) return i(e, n).value
                    }
                    return e[n]
                };
            e.exports = function e() {
                var t, n, r, i, c, s, f = arguments[0],
                    d = 1,
                    p = arguments.length,
                    h = !1;
                for ("boolean" == typeof f && (h = f, f = arguments[1] || {}, d = 2), (null == f || "object" != typeof f && "function" != typeof f) && (f = {}); d < p; ++d)
                    if (t = arguments[d], null != t)
                        for (n in t) r = a(f, n), f !== (i = a(t, n)) && (h && i && (l(i) || (c = o(i))) ? (c ? (c = !1, s = r && o(r) ? r : []) : s = r && l(r) ? r : {}, u(f, {
                            name: n,
                            newValue: e(h, s, i)
                        })) : void 0 !== i && u(f, {
                            name: n,
                            newValue: i
                        }));
                return f
            }
        },
        8139: function(e) {
            var t = /\/\*[^*]*\*+([^/*][^*]*\*+)*\//g,
                n = /\n/g,
                r = /^\s*/,
                i = /^(\*?[-#/*\\\w]+(\[[0-9a-z_-]+\])?)\s*/,
                o = /^:\s*/,
                l = /^((?:'(?:\\'|.)*?'|"(?:\\"|.)*?"|\([^)]*?\)|[^};])+)/,
                u = /^[;\s]*/,
                a = /^\s+|\s+$/g;

            function c(e) {
                return e ? e.replace(a, "") : ""
            }
            e.exports = function(e, a) {
                if ("string" != typeof e) throw TypeError("First argument must be a string");
                if (!e) return [];
                a = a || {};
                var s = 1,
                    f = 1;

                function d(e) {
                    var t = e.match(n);
                    t && (s += t.length);
                    var r = e.lastIndexOf("\n");
                    f = ~r ? e.length - r : f + e.length
                }

                function p() {
                    var e = {
                        line: s,
                        column: f
                    };
                    return function(t) {
                        return t.position = new h(e), v(), t
                    }
                }

                function h(e) {
                    this.start = e, this.end = {
                        line: s,
                        column: f
                    }, this.source = a.source
                }
                h.prototype.content = e;
                var m = [];

                function g(t) {
                    var n = Error(a.source + ":" + s + ":" + f + ": " + t);
                    if (n.reason = t, n.filename = a.source, n.line = s, n.column = f, n.source = e, a.silent) m.push(n);
                    else throw n
                }

                function y(t) {
                    var n = t.exec(e);
                    if (n) {
                        var r = n[0];
                        return d(r), e = e.slice(r.length), n
                    }
                }

                function v() {
                    y(r)
                }

                function b(e) {
                    var t;
                    for (e = e || []; t = x();) !1 !== t && e.push(t);
                    return e
                }

                function x() {
                    var t = p();
                    if ("/" == e.charAt(0) && "*" == e.charAt(1)) {
                        for (var n = 2;
                            "" != e.charAt(n) && ("*" != e.charAt(n) || "/" != e.charAt(n + 1));) ++n;
                        if (n += 2, "" === e.charAt(n - 1)) return g("End of comment missing");
                        var r = e.slice(2, n - 2);
                        return f += 2, d(r), e = e.slice(n), f += 2, t({
                            type: "comment",
                            comment: r
                        })
                    }
                }

                function k() {
                    var e = p(),
                        n = y(i);
                    if (n) {
                        if (x(), !y(o)) return g("property missing ':'");
                        var r = y(l),
                            a = e({
                                type: "declaration",
                                property: c(n[0].replace(t, "")),
                                value: r ? c(r[0].replace(t, "")) : ""
                            });
                        return y(u), a
                    }
                }
                return v(),
                    function() {
                        var e, t = [];
                        for (b(t); e = k();) !1 !== e && (t.push(e), b(t));
                        return t
                    }()
            }
        },
        8738: function(e) {
            /*!
             * Determine if an object is a Buffer
             *
             * @author Feross Aboukhadijeh <https://feross.org>
             * @license MIT
             */
            e.exports = function(e) {
                return null != e && null != e.constructor && "function" == typeof e.constructor.isBuffer && e.constructor.isBuffer(e)
            }
        },
        1210: function(e, t) {
            "use strict";

            function n(e, t, n, r) {
                return !1
            }
            Object.defineProperty(t, "__esModule", {
                value: !0
            }), t.getDomainLocale = n, ("function" == typeof t.default || "object" == typeof t.default && null !== t.default) && void 0 === t.default.__esModule && (Object.defineProperty(t.default, "__esModule", {
                value: !0
            }), Object.assign(t.default, t), e.exports = t.default)
        },
        8045: function(e, t, n) {
            "use strict";
            Object.defineProperty(t, "__esModule", {
                value: !0
            });
            var r = n(9361).Z,
                i = n(4941).Z,
                o = n(3929).Z;
            Object.defineProperty(t, "__esModule", {
                value: !0
            }), t.default = function(e) {
                var t, n, u = e.src,
                    a = e.sizes,
                    m = e.unoptimized,
                    g = void 0 !== m && m,
                    x = e.priority,
                    C = void 0 !== x && x,
                    P = e.loading,
                    M = e.lazyRoot,
                    L = e.lazyBoundary,
                    T = e.className,
                    O = e.quality,
                    F = e.width,
                    I = e.height,
                    j = e.style,
                    D = e.objectFit,
                    z = e.objectPosition,
                    R = e.onLoadingComplete,
                    N = e.placeholder,
                    B = void 0 === N ? "empty" : N,
                    _ = e.blurDataURL,
                    $ = c(e, ["src", "sizes", "unoptimized", "priority", "loading", "lazyRoot", "lazyBoundary", "className", "quality", "width", "height", "style", "objectFit", "objectPosition", "onLoadingComplete", "placeholder", "blurDataURL"]),
                    H = s.useContext(h.ImageConfigContext),
                    q = s.useMemo(function() {
                        var e = y || H || d.imageConfigDefault,
                            t = o(e.deviceSizes).concat(o(e.imageSizes)).sort(function(e, t) {
                                return e - t
                            }),
                            n = e.deviceSizes.sort(function(e, t) {
                                return e - t
                            });
                        return l({}, e, {
                            allSizes: t,
                            deviceSizes: n
                        })
                    }, [H]),
                    V = a ? "responsive" : "intrinsic";
                "layout" in $ && ($.layout && (V = $.layout), delete $.layout);
                var U = S;
                if ("loader" in $) {
                    if ($.loader) {
                        var Z = $.loader;
                        U = function(e) {
                            e.config;
                            var t = c(e, ["config"]);
                            return Z(t)
                        }
                    }
                    delete $.loader
                }
                var W = "";
                if (function(e) {
                        var t;
                        return "object" == typeof e && (k(e) || void 0 !== e.src)
                    }(u)) {
                    var J = k(u) ? u.default : u;
                    if (!J.src) throw Error("An object should only be passed to the image component src parameter if it comes from a static image import. It must include src. Received ".concat(JSON.stringify(J)));
                    if (_ = _ || J.blurDataURL, W = J.src, (!V || "fill" !== V) && (I = I || J.height, F = F || J.width, !J.height || !J.width)) throw Error("An object should only be passed to the image component src parameter if it comes from a static image import. It must include height and width. Received ".concat(JSON.stringify(J)))
                }
                u = "string" == typeof u ? u : W;
                var K = !C && ("lazy" === P || void 0 === P);
                (u.startsWith("data:") || u.startsWith("blob:")) && (g = !0, K = !1), v.has(u) && (K = !1), q.unoptimized && (g = !0);
                var G = i(s.useState(!1), 2),
                    Q = G[0],
                    Y = G[1],
                    X = i(p.useIntersection({
                        rootRef: void 0 === M ? null : M,
                        rootMargin: L || "200px",
                        disabled: !K
                    }), 3),
                    ee = X[0],
                    et = X[1],
                    en = X[2],
                    er = !K || et,
                    ei = {
                        boxSizing: "border-box",
                        display: "block",
                        overflow: "hidden",
                        width: "initial",
                        height: "initial",
                        background: "none",
                        opacity: 1,
                        border: 0,
                        margin: 0,
                        padding: 0
                    },
                    eo = {
                        boxSizing: "border-box",
                        display: "block",
                        width: "initial",
                        height: "initial",
                        background: "none",
                        opacity: 1,
                        border: 0,
                        margin: 0,
                        padding: 0
                    },
                    el = !1,
                    eu = E(F),
                    ea = E(I),
                    ec = E(O),
                    es = Object.assign({}, j, {
                        position: "absolute",
                        top: 0,
                        left: 0,
                        bottom: 0,
                        right: 0,
                        boxSizing: "border-box",
                        padding: 0,
                        border: "none",
                        margin: "auto",
                        display: "block",
                        width: 0,
                        height: 0,
                        minWidth: "100%",
                        maxWidth: "100%",
                        minHeight: "100%",
                        maxHeight: "100%",
                        objectFit: D,
                        objectPosition: z
                    }),
                    ef = "blur" !== B || Q ? {} : {
                        backgroundSize: D || "cover",
                        backgroundPosition: z || "0% 0%",
                        filter: "blur(20px)",
                        backgroundImage: 'url("'.concat(_, '")')
                    };
                if ("fill" === V) ei.display = "block", ei.position = "absolute", ei.top = 0, ei.left = 0, ei.bottom = 0, ei.right = 0;
                else if (void 0 !== eu && void 0 !== ea) {
                    var ed = ea / eu,
                        ep = isNaN(ed) ? "100%" : "".concat(100 * ed, "%");
                    "responsive" === V ? (ei.display = "block", ei.position = "relative", el = !0, eo.paddingTop = ep) : "intrinsic" === V ? (ei.display = "inline-block", ei.position = "relative", ei.maxWidth = "100%", el = !0, eo.maxWidth = "100%", t = "data:image/svg+xml,%3csvg%20xmlns=%27http://www.w3.org/2000/svg%27%20version=%271.1%27%20width=%27".concat(eu, "%27%20height=%27").concat(ea, "%27/%3e")) : "fixed" === V && (ei.display = "inline-block", ei.position = "relative", ei.width = eu, ei.height = ea)
                }
                var eh = {
                    src: b,
                    srcSet: void 0,
                    sizes: void 0
                };
                er && (eh = w({
                    config: q,
                    src: u,
                    unoptimized: g,
                    layout: V,
                    width: eu,
                    quality: ec,
                    sizes: a,
                    loader: U
                }));
                var em = u,
                    eg = "imagesizes";
                eg = "imageSizes";
                var ey = (r(n = {}, "imageSrcSet", eh.srcSet), r(n, eg, eh.sizes), r(n, "crossOrigin", $.crossOrigin), n),
                    ev = s.default.useLayoutEffect,
                    eb = s.useRef(R),
                    ex = s.useRef(u);
                s.useEffect(function() {
                    eb.current = R
                }, [R]), ev(function() {
                    ex.current !== u && (en(), ex.current = u)
                }, [en, u]);
                var ek = l({
                    isLazy: K,
                    imgAttributes: eh,
                    heightInt: ea,
                    widthInt: eu,
                    qualityInt: ec,
                    layout: V,
                    className: T,
                    imgStyle: es,
                    blurStyle: ef,
                    loading: P,
                    config: q,
                    unoptimized: g,
                    placeholder: B,
                    loader: U,
                    srcString: em,
                    onLoadingCompleteRef: eb,
                    setBlurComplete: Y,
                    setIntersection: ee,
                    isVisible: er,
                    noscriptSizes: a
                }, $);
                return s.default.createElement(s.default.Fragment, null, s.default.createElement("span", {
                    style: ei
                }, el ? s.default.createElement("span", {
                    style: eo
                }, t ? s.default.createElement("img", {
                    style: {
                        display: "block",
                        maxWidth: "100%",
                        width: "initial",
                        height: "initial",
                        background: "none",
                        opacity: 1,
                        border: 0,
                        margin: 0,
                        padding: 0
                    },
                    alt: "",
                    "aria-hidden": !0,
                    src: t
                }) : null) : null, s.default.createElement(A, Object.assign({}, ek))), C ? s.default.createElement(f.default, null, s.default.createElement("link", Object.assign({
                    key: "__nimg-" + eh.src + eh.srcSet + eh.sizes,
                    rel: "preload",
                    as: "image",
                    href: eh.srcSet ? void 0 : eh.src
                }, ey))) : null)
            };
            var l = n(6495).Z,
                u = n(2648).Z,
                a = n(1598).Z,
                c = n(7273).Z,
                s = a(n(7294)),
                f = u(n(5443)),
                d = n(9309),
                p = n(7190),
                h = n(9977);
            n(3794);
            var m = n(2392);

            function g(e) {
                return "/" === e[0] ? e.slice(1) : e
            }
            var y = {
                    deviceSizes: [640, 750, 828, 1080, 1200, 1920, 2048, 3840],
                    imageSizes: [16, 32, 48, 64, 96, 128, 256, 384],
                    path: "/_next/image",
                    loader: "default",
                    dangerouslyAllowSVG: !1,
                    unoptimized: !1
                },
                v = new Set,
                b = "data:image/gif;base64,R0lGODlhAQABAIAAAAAAAP///yH5BAEAAAAALAAAAAABAAEAAAIBRAA7",
                x = new Map([
                    ["default", function(e) {
                        var t = e.config,
                            n = e.src,
                            r = e.width,
                            i = e.quality;
                        return n.endsWith(".svg") && !t.dangerouslyAllowSVG ? n : "".concat(m.normalizePathTrailingSlash(t.path), "?url=").concat(encodeURIComponent(n), "&w=").concat(r, "&q=").concat(i || 75)
                    }],
                    ["imgix", function(e) {
                        var t = e.config,
                            n = e.src,
                            r = e.width,
                            i = e.quality,
                            o = new URL("".concat(t.path).concat(g(n))),
                            l = o.searchParams;
                        return l.set("auto", l.getAll("auto").join(",") || "format"), l.set("fit", l.get("fit") || "max"), l.set("w", l.get("w") || r.toString()), i && l.set("q", i.toString()), o.href
                    }],
                    ["cloudinary", function(e) {
                        var t, n = e.config,
                            r = e.src,
                            i = e.width,
                            o = ["f_auto", "c_limit", "w_" + i, "q_" + (e.quality || "auto")].join(",") + "/";
                        return "".concat(n.path).concat(o).concat(g(r))
                    }],
                    ["akamai", function(e) {
                        var t = e.config,
                            n = e.src,
                            r = e.width;
                        return "".concat(t.path).concat(g(n), "?imwidth=").concat(r)
                    }],
                    ["custom", function(e) {
                        var t = e.src;
                        throw Error('Image with src "'.concat(t, '" is missing "loader" prop.') + "\nRead more: https://nextjs.org/docs/messages/next-image-missing-loader")
                    }],
                ]);

            function k(e) {
                return void 0 !== e.default
            }

            function w(e) {
                var t = e.config,
                    n = e.src,
                    r = e.unoptimized,
                    i = e.layout,
                    l = e.width,
                    u = e.quality,
                    a = e.sizes,
                    c = e.loader;
                if (r) return {
                    src: n,
                    srcSet: void 0,
                    sizes: void 0
                };
                var s = function(e, t, n, r) {
                        var i = e.deviceSizes,
                            l = e.allSizes;
                        if (r && ("fill" === n || "responsive" === n)) {
                            for (var u = /(^|\s)(1?\d?\d)vw/g, a = []; c = u.exec(r); c) a.push(parseInt(c[2]));
                            if (a.length) {
                                var c, s, f = .01 * (s = Math).min.apply(s, o(a));
                                return {
                                    widths: l.filter(function(e) {
                                        return e >= i[0] * f
                                    }),
                                    kind: "w"
                                }
                            }
                            return {
                                widths: l,
                                kind: "w"
                            }
                        }
                        return "number" != typeof t || "fill" === n || "responsive" === n ? {
                            widths: i,
                            kind: "w"
                        } : {
                            widths: o(new Set([t, 2 * t].map(function(e) {
                                return l.find(function(t) {
                                    return t >= e
                                }) || l[l.length - 1]
                            }))),
                            kind: "x"
                        }
                    }(t, l, i, a),
                    f = s.widths,
                    d = s.kind,
                    p = f.length - 1;
                return {
                    sizes: a || "w" !== d ? a : "100vw",
                    srcSet: f.map(function(e, r) {
                        return "".concat(c({
                            config: t,
                            src: n,
                            quality: u,
                            width: e
                        }), " ").concat("w" === d ? e : r + 1).concat(d)
                    }).join(", "),
                    src: c({
                        config: t,
                        src: n,
                        quality: u,
                        width: f[p]
                    })
                }
            }

            function E(e) {
                return "number" == typeof e ? e : "string" == typeof e ? parseInt(e, 10) : void 0
            }

            function S(e) {
                var t, n = (null == (t = e.config) ? void 0 : t.loader) || "default",
                    r = x.get(n);
                if (r) return r(e);
                throw Error('Unknown "loader" found in "next.config.js". Expected: '.concat(d.VALID_LOADERS.join(", "), ". Received: ").concat(n))
            }

            function C(e, t, n, r, i, o) {
                e && e.src !== b && e["data-loaded-src"] !== t && (e["data-loaded-src"] = t, ("decode" in e ? e.decode() : Promise.resolve()).catch(function() {}).then(function() {
                    if (e.parentNode && (v.add(t), "blur" === r && o(!0), null == i ? void 0 : i.current)) {
                        var n = e.naturalWidth,
                            l = e.naturalHeight;
                        i.current({
                            naturalWidth: n,
                            naturalHeight: l
                        })
                    }
                }))
            }
            var A = function(e) {
                var t = e.imgAttributes,
                    n = (e.heightInt, e.widthInt),
                    r = e.qualityInt,
                    i = e.layout,
                    o = e.className,
                    u = e.imgStyle,
                    a = e.blurStyle,
                    f = e.isLazy,
                    d = e.placeholder,
                    p = e.loading,
                    h = e.srcString,
                    m = e.config,
                    g = e.unoptimized,
                    y = e.loader,
                    v = e.onLoadingCompleteRef,
                    b = e.setBlurComplete,
                    x = e.setIntersection,
                    k = e.onLoad,
                    E = e.onError,
                    S = (e.isVisible, e.noscriptSizes),
                    A = c(e, ["imgAttributes", "heightInt", "widthInt", "qualityInt", "layout", "className", "imgStyle", "blurStyle", "isLazy", "placeholder", "loading", "srcString", "config", "unoptimized", "loader", "onLoadingCompleteRef", "setBlurComplete", "setIntersection", "onLoad", "onError", "isVisible", "noscriptSizes"]);
                return p = f ? "lazy" : p, s.default.createElement(s.default.Fragment, null, s.default.createElement("img", Object.assign({}, A, t, {
                    decoding: "async",
                    "data-nimg": i,
                    className: o,
                    style: l({}, u, a),
                    ref: s.useCallback(function(e) {
                        x(e), (null == e ? void 0 : e.complete) && C(e, h, i, d, v, b)
                    }, [x, h, i, d, v, b, ]),
                    onLoad: function(e) {
                        C(e.currentTarget, h, i, d, v, b), k && k(e)
                    },
                    onError: function(e) {
                        "blur" === d && b(!0), E && E(e)
                    }
                })), (f || "blur" === d) && s.default.createElement("noscript", null, s.default.createElement("img", Object.assign({}, A, w({
                    config: m,
                    src: h,
                    unoptimized: g,
                    layout: i,
                    width: n,
                    quality: r,
                    sizes: S,
                    loader: y
                }), {
                    decoding: "async",
                    "data-nimg": i,
                    style: u,
                    className: o,
                    loading: p
                }))))
            };
            ("function" == typeof t.default || "object" == typeof t.default && null !== t.default) && void 0 === t.default.__esModule && (Object.defineProperty(t.default, "__esModule", {
                value: !0
            }), Object.assign(t.default, t), e.exports = t.default)
        },
        8418: function(e, t, n) {
            "use strict";
            Object.defineProperty(t, "__esModule", {
                value: !0
            });
            var r = n(4941).Z;
            n(5753).default, Object.defineProperty(t, "__esModule", {
                value: !0
            }), t.default = void 0;
            var i = n(2648).Z,
                o = n(7273).Z,
                l = i(n(7294)),
                u = n(6273),
                a = n(2725),
                c = n(3462),
                s = n(1018),
                f = n(7190),
                d = n(1210),
                p = n(8684),
                h = {};

            function m(e, t, n, r) {
                if (e && u.isLocalURL(t)) {
                    Promise.resolve(e.prefetch(t, n, r)).catch(function(e) {});
                    var i = r && void 0 !== r.locale ? r.locale : e && e.locale;
                    h[t + "%" + n + (i ? "%" + i : "")] = !0
                }
            }
            var g = l.default.forwardRef(function(e, t) {
                var n, i, g = e.href,
                    y = e.as,
                    v = e.children,
                    b = e.prefetch,
                    x = e.passHref,
                    k = e.replace,
                    w = e.shallow,
                    E = e.scroll,
                    S = e.locale,
                    C = e.onClick,
                    A = e.onMouseEnter,
                    P = e.onTouchStart,
                    M = e.legacyBehavior,
                    L = void 0 === M ? !0 !== Boolean(!1) : M,
                    T = o(e, ["href", "as", "children", "prefetch", "passHref", "replace", "shallow", "scroll", "locale", "onClick", "onMouseEnter", "onTouchStart", "legacyBehavior"]);
                n = v, L && ("string" == typeof n || "number" == typeof n) && (n = l.default.createElement("a", null, n));
                var O = !1 !== b,
                    F = l.default.useContext(c.RouterContext),
                    I = l.default.useContext(s.AppRouterContext);
                I && (F = I);
                var j = l.default.useMemo(function() {
                        var e = r(u.resolveHref(F, g, !0), 2),
                            t = e[0],
                            n = e[1];
                        return {
                            href: t,
                            as: y ? u.resolveHref(F, y) : n || t
                        }
                    }, [F, g, y]),
                    D = j.href,
                    z = j.as,
                    R = l.default.useRef(D),
                    N = l.default.useRef(z);
                L && (i = l.default.Children.only(n));
                var B = L ? i && "object" == typeof i && i.ref : t,
                    _ = r(f.useIntersection({
                        rootMargin: "200px"
                    }), 3),
                    $ = _[0],
                    H = _[1],
                    q = _[2],
                    V = l.default.useCallback(function(e) {
                        (N.current !== z || R.current !== D) && (q(), N.current = z, R.current = D), $(e), B && ("function" == typeof B ? B(e) : "object" == typeof B && (B.current = e))
                    }, [z, B, D, q, $]);
                l.default.useEffect(function() {
                    var e = H && O && u.isLocalURL(D),
                        t = void 0 !== S ? S : F && F.locale,
                        n = h[D + "%" + z + (t ? "%" + t : "")];
                    e && !n && m(F, D, z, {
                        locale: t
                    })
                }, [z, D, H, S, O, F]);
                var U = {
                    ref: V,
                    onClick: function(e) {
                        L || "function" != typeof C || C(e), L && i.props && "function" == typeof i.props.onClick && i.props.onClick(e), e.defaultPrevented || function(e, t, n, r, i, o, a, c, s, f) {
                            if ("A" !== e.currentTarget.nodeName.toUpperCase() || (!(p = (d = e).currentTarget.target) || "_self" === p) && !d.metaKey && !d.ctrlKey && !d.shiftKey && !d.altKey && (!d.nativeEvent || 2 !== d.nativeEvent.which) && u.isLocalURL(n)) {
                                e.preventDefault();
                                var d, p, h = function() {
                                    "beforePopState" in t ? t[i ? "replace" : "push"](n, r, {
                                        shallow: o,
                                        locale: c,
                                        scroll: a
                                    }) : t[i ? "replace" : "push"](n, {
                                        forceOptimisticNavigation: !f
                                    })
                                };
                                s ? l.default.startTransition(h) : h()
                            }
                        }(e, F, D, z, k, w, E, S, Boolean(I), O)
                    },
                    onMouseEnter: function(e) {
                        L || "function" != typeof A || A(e), L && i.props && "function" == typeof i.props.onMouseEnter && i.props.onMouseEnter(e), !(!O && I) && u.isLocalURL(D) && m(F, D, z, {
                            priority: !0
                        })
                    },
                    onTouchStart: function(e) {
                        L || "function" != typeof P || P(e), L && i.props && "function" == typeof i.props.onTouchStart && i.props.onTouchStart(e), !(!O && I) && u.isLocalURL(D) && m(F, D, z, {
                            priority: !0
                        })
                    }
                };
                if (!L || x || "a" === i.type && !("href" in i.props)) {
                    var Z = void 0 !== S ? S : F && F.locale,
                        W = F && F.isLocaleDomain && d.getDomainLocale(z, Z, F.locales, F.domainLocales);
                    U.href = W || p.addBasePath(a.addLocale(z, Z, F && F.defaultLocale))
                }
                return L ? l.default.cloneElement(i, U) : l.default.createElement("a", Object.assign({}, T, U), n)
            });
            t.default = g, ("function" == typeof t.default || "object" == typeof t.default && null !== t.default) && void 0 === t.default.__esModule && (Object.defineProperty(t.default, "__esModule", {
                value: !0
            }), Object.assign(t.default, t), e.exports = t.default)
        },
        7190: function(e, t, n) {
            "use strict";
            Object.defineProperty(t, "__esModule", {
                value: !0
            });
            var r = n(4941).Z;
            Object.defineProperty(t, "__esModule", {
                value: !0
            }), t.useIntersection = function(e) {
                var t, n = e.rootRef,
                    c = e.rootMargin,
                    s = e.disabled || !l,
                    f = r(i.useState(!1), 2),
                    d = f[0],
                    p = f[1],
                    h = r(i.useState(null), 2),
                    m = h[0],
                    g = h[1];
                return i.useEffect(function() {
                    if (l) {
                        if (!s && !d && m && m.tagName) {
                            var e, t, r, i, f, h, g;
                            return t = function(e) {
                                    return e && p(e)
                                }, f = (i = function(e) {
                                    var t, n = {
                                            root: e.root || null,
                                            margin: e.rootMargin || ""
                                        },
                                        r = a.find(function(e) {
                                            return e.root === n.root && e.margin === n.margin
                                        });
                                    if (r && (t = u.get(r))) return t;
                                    var i = new Map;
                                    return t = {
                                        id: n,
                                        observer: new IntersectionObserver(function(e) {
                                            e.forEach(function(e) {
                                                var t = i.get(e.target),
                                                    n = e.isIntersecting || e.intersectionRatio > 0;
                                                t && n && t(n)
                                            })
                                        }, e),
                                        elements: i
                                    }, a.push(n), u.set(n, t), t
                                }(r = {
                                    root: null == n ? void 0 : n.current,
                                    rootMargin: c
                                })).id, h = i.observer, (g = i.elements).set(m, t), h.observe(m),
                                function() {
                                    if (g.delete(m), h.unobserve(m), 0 === g.size) {
                                        h.disconnect(), u.delete(f);
                                        var e = a.findIndex(function(e) {
                                            return e.root === f.root && e.margin === f.margin
                                        });
                                        e > -1 && a.splice(e, 1)
                                    }
                                }
                        }
                    } else if (!d) {
                        var y = o.requestIdleCallback(function() {
                            return p(!0)
                        });
                        return function() {
                            return o.cancelIdleCallback(y)
                        }
                    }
                }, [m, s, c, n, d]), [g, d, i.useCallback(function() {
                    p(!1)
                }, [])]
            };
            var i = n(7294),
                o = n(9311),
                l = "function" == typeof IntersectionObserver,
                u = new Map,
                a = [];
            ("function" == typeof t.default || "object" == typeof t.default && null !== t.default) && void 0 === t.default.__esModule && (Object.defineProperty(t.default, "__esModule", {
                value: !0
            }), Object.assign(t.default, t), e.exports = t.default)
        },
        1018: function(e, t, n) {
            "use strict";
            Object.defineProperty(t, "__esModule", {
                value: !0
            }), t.TemplateContext = t.GlobalLayoutRouterContext = t.LayoutRouterContext = t.AppRouterContext = void 0;
            var r = (0, n(2648).Z)(n(7294)),
                i = r.default.createContext(null);
            t.AppRouterContext = i;
            var o = r.default.createContext(null);
            t.LayoutRouterContext = o;
            var l = r.default.createContext(null);
            t.GlobalLayoutRouterContext = l;
            var u = r.default.createContext(null);
            t.TemplateContext = u
        },
        5675: function(e, t, n) {
            e.exports = n(8045)
        },
        1664: function(e, t, n) {
            e.exports = n(8418)
        },
        2703: function(e, t, n) {
            "use strict";
            var r = n(414);

            function i() {}

            function o() {}
            o.resetWarningCache = i, e.exports = function() {
                function e(e, t, n, i, o, l) {
                    if (l !== r) {
                        var u = Error("Calling PropTypes validators directly is not supported by the `prop-types` package. Use PropTypes.checkPropTypes() to call them. Read more at http://fb.me/use-check-prop-types");
                        throw u.name = "Invariant Violation", u
                    }
                }

                function t() {
                    return e
                }
                e.isRequired = e;
                var n = {
                    array: e,
                    bigint: e,
                    bool: e,
                    func: e,
                    number: e,
                    object: e,
                    string: e,
                    symbol: e,
                    any: e,
                    arrayOf: t,
                    element: e,
                    elementType: e,
                    instanceOf: t,
                    node: e,
                    objectOf: t,
                    oneOf: t,
                    oneOfType: t,
                    shape: t,
                    exact: t,
                    checkPropTypes: o,
                    resetWarningCache: i
                };
                return n.PropTypes = n, n
            }
        },
        5697: function(e, t, n) {
            e.exports = n(2703)()
        },
        414: function(e) {
            "use strict";
            e.exports = "SECRET_DO_NOT_PASS_THIS_OR_YOU_WILL_BE_FIRED"
        },
        9921: function(e, t) {
            "use strict";
            var n, r = Symbol.for("react.element"),
                i = Symbol.for("react.portal"),
                o = Symbol.for("react.fragment"),
                l = Symbol.for("react.strict_mode"),
                u = Symbol.for("react.profiler"),
                a = Symbol.for("react.provider"),
                c = Symbol.for("react.context"),
                s = Symbol.for("react.server_context"),
                f = Symbol.for("react.forward_ref"),
                d = Symbol.for("react.suspense"),
                p = Symbol.for("react.suspense_list"),
                h = Symbol.for("react.memo"),
                m = Symbol.for("react.lazy"),
                g = Symbol.for("react.offscreen");

            function y(e) {
                if ("object" == typeof e && null !== e) {
                    var t = e.$$typeof;
                    switch (t) {
                        case r:
                            switch (e = e.type) {
                                case o:
                                case u:
                                case l:
                                case d:
                                case p:
                                    return e;
                                default:
                                    switch (e = e && e.$$typeof) {
                                        case s:
                                        case c:
                                        case f:
                                        case m:
                                        case h:
                                        case a:
                                            return e;
                                        default:
                                            return t
                                    }
                            }
                        case i:
                            return t
                    }
                }
            }
            n = Symbol.for("react.module.reference"), t.ContextConsumer = c, t.ContextProvider = a, t.Element = r, t.ForwardRef = f, t.Fragment = o, t.Lazy = m, t.Memo = h, t.Portal = i, t.Profiler = u, t.StrictMode = l, t.Suspense = d, t.SuspenseList = p, t.isAsyncMode = function() {
                return !1
            }, t.isConcurrentMode = function() {
                return !1
            }, t.isContextConsumer = function(e) {
                return y(e) === c
            }, t.isContextProvider = function(e) {
                return y(e) === a
            }, t.isElement = function(e) {
                return "object" == typeof e && null !== e && e.$$typeof === r
            }, t.isForwardRef = function(e) {
                return y(e) === f
            }, t.isFragment = function(e) {
                return y(e) === o
            }, t.isLazy = function(e) {
                return y(e) === m
            }, t.isMemo = function(e) {
                return y(e) === h
            }, t.isPortal = function(e) {
                return y(e) === i
            }, t.isProfiler = function(e) {
                return y(e) === u
            }, t.isStrictMode = function(e) {
                return y(e) === l
            }, t.isSuspense = function(e) {
                return y(e) === d
            }, t.isSuspenseList = function(e) {
                return y(e) === p
            }, t.isValidElementType = function(e) {
                return "string" == typeof e || "function" == typeof e || e === o || e === u || e === l || e === d || e === p || e === g || "object" == typeof e && null !== e && (e.$$typeof === m || e.$$typeof === h || e.$$typeof === a || e.$$typeof === c || e.$$typeof === f || e.$$typeof === n || void 0 !== e.getModuleId)
            }, t.typeOf = y
        },
        9864: function(e, t, n) {
            "use strict";
            e.exports = n(9921)
        },
        7848: function(e, t, n) {
            var r = n(8139);
            e.exports = function(e, t) {
                var n, i, o, l = null;
                if (!e || "string" != typeof e) return l;
                for (var u = r(e), a = "function" == typeof t, c = 0, s = u.length; c < s; c++) i = (n = u[c]).property, o = n.value, a ? t(i, o, n) : o && (l || (l = {}), l[i] = o);
                return l
            }
        },
        2249: function(e, t, n) {
            "use strict";
            var r = n(7294);
            let i = r.forwardRef(function({
                title: e,
                titleId: t,
                ...n
            }, i) {
                return r.createElement("svg", Object.assign({
                    xmlns: "http://www.w3.org/2000/svg",
                    fill: "none",
                    viewBox: "0 0 24 24",
                    strokeWidth: 1.5,
                    stroke: "currentColor",
                    "aria-hidden": "true",
                    ref: i,
                    "aria-labelledby": t
                }, n), e ? r.createElement("title", {
                    id: t
                }, e) : null, r.createElement("path", {
                    strokeLinecap: "round",
                    strokeLinejoin: "round",
                    d: "M19 12H5m0 0l7 7m-7-7l7-7"
                }))
            });
            t.Z = i
        },
        4695: function(e, t, n) {
            "use strict";
            var r = n(7294);
            let i = r.forwardRef(function({
                title: e,
                titleId: t,
                ...n
            }, i) {
                return r.createElement("svg", Object.assign({
                    xmlns: "http://www.w3.org/2000/svg",
                    fill: "none",
                    viewBox: "0 0 24 24",
                    strokeWidth: 1.5,
                    stroke: "currentColor",
                    "aria-hidden": "true",
                    ref: i,
                    "aria-labelledby": t
                }, n), e ? r.createElement("title", {
                    id: t
                }, e) : null, r.createElement("path", {
                    strokeLinecap: "round",
                    strokeLinejoin: "round",
                    d: "M5 12h14m0 0l-7-7m7 7l-7 7"
                }))
            });
            t.Z = i
        },
        4742: function(e, t, n) {
            "use strict";
            var r = n(7294);
            let i = r.forwardRef(function({
                title: e,
                titleId: t,
                ...n
            }, i) {
                return r.createElement("svg", Object.assign({
                    xmlns: "http://www.w3.org/2000/svg",
                    fill: "none",
                    viewBox: "0 0 24 24",
                    strokeWidth: 1.5,
                    stroke: "currentColor",
                    "aria-hidden": "true",
                    ref: i,
                    "aria-labelledby": t
                }, n), e ? r.createElement("title", {
                    id: t
                }, e) : null, r.createElement("path", {
                    strokeLinecap: "round",
                    strokeLinejoin: "round",
                    d: "M15 18l-6-6 6-6"
                }))
            });
            t.Z = i
        },
        2728: function(e, t, n) {
            "use strict";
            var r = n(7294);
            let i = r.forwardRef(function({
                title: e,
                titleId: t,
                ...n
            }, i) {
                return r.createElement("svg", Object.assign({
                    xmlns: "http://www.w3.org/2000/svg",
                    fill: "none",
                    viewBox: "0 0 24 24",
                    strokeWidth: 1.5,
                    stroke: "currentColor",
                    "aria-hidden": "true",
                    ref: i,
                    "aria-labelledby": t
                }, n), e ? r.createElement("title", {
                    id: t
                }, e) : null, r.createElement("path", {
                    strokeLinecap: "round",
                    strokeLinejoin: "round",
                    d: "M9 18l6-6-6-6"
                }))
            });
            t.Z = i
        },
        3090: function(e, t, n) {
            "use strict";
            var r = n(7294);
            let i = r.forwardRef(function({
                title: e,
                titleId: t,
                ...n
            }, i) {
                return r.createElement("svg", Object.assign({
                    xmlns: "http://www.w3.org/2000/svg",
                    fill: "none",
                    viewBox: "0 0 24 24",
                    strokeWidth: 1.5,
                    stroke: "currentColor",
                    "aria-hidden": "true",
                    ref: i,
                    "aria-labelledby": t
                }, n), e ? r.createElement("title", {
                    id: t
                }, e) : null, r.createElement("path", {
                    strokeLinecap: "round",
                    strokeLinejoin: "round",
                    d: "M9.5 15V9m5 6V9m7.5 3c0 5.523-4.477 10-10 10S2 17.523 2 12 6.477 2 12 2s10 4.477 10 10z"
                }))
            });
            t.Z = i
        },
        5311: function(e, t, n) {
            "use strict";
            var r = n(7294);
            let i = r.forwardRef(function({
                title: e,
                titleId: t,
                ...n
            }, i) {
                return r.createElement("svg", Object.assign({
                    xmlns: "http://www.w3.org/2000/svg",
                    viewBox: "0 0 24 24",
                    fill: "currentColor",
                    "aria-hidden": "true",
                    ref: i,
                    "aria-labelledby": t
                }, n), e ? r.createElement("title", {
                    id: t
                }, e) : null, r.createElement("path", {
                    fillRule: "evenodd",
                    d: "M8.006 2.802l.036.024L18.591 9.86c.305.203.588.392.805.567.227.183.495.437.649.808a2 2 0 010 1.532c-.154.371-.422.625-.649.808-.217.175-.5.364-.805.567L8.006 21.198c-.373.248-.708.472-.993.627-.285.154-.676.33-1.132.303a2 2 0 01-1.476-.79c-.276-.364-.346-.788-.376-1.11C4 19.905 4 19.502 4 19.054V4.99v-.043c0-.449 0-.852.03-1.175.029-.322.1-.745.375-1.11a2 2 0 011.476-.79c.456-.027.847.15 1.132.304.285.154.62.378.993.626z",
                    clipRule: "evenodd"
                }))
            });
            t.Z = i
        },
        819: function(e, t, n) {
            "use strict";
            var r = n(7294);
            let i = r.forwardRef(function({
                title: e,
                titleId: t,
                ...n
            }, i) {
                return r.createElement("svg", Object.assign({
                    xmlns: "http://www.w3.org/2000/svg",
                    viewBox: "0 0 24 24",
                    fill: "currentColor",
                    "aria-hidden": "true",
                    ref: i,
                    "aria-labelledby": t
                }, n), e ? r.createElement("title", {
                    id: t
                }, e) : null, r.createElement("path", {
                    d: "M11.538 1.71a.5.5 0 01.923 0l2.596 6.24a.5.5 0 00.421.306l6.736.54a.5.5 0 01.286.878l-5.133 4.396a.5.5 0 00-.16.496l1.567 6.573a.5.5 0 01-.747.543l-5.767-3.523a.5.5 0 00-.52 0l-5.768 3.523a.5.5 0 01-.747-.543l1.568-6.573a.5.5 0 00-.16-.496L1.5 9.674a.5.5 0 01.285-.878l6.736-.54a.5.5 0 00.422-.307l2.595-6.239z"
                }))
            });
            t.Z = i
        },
        6765: function(e, t, n) {
            "use strict";
            n.d(t, {
                Fl: function() {
                    return V
                },
                IC: function() {
                    return r
                },
                Jz: function() {
                    return h
                },
                Ky: function() {
                    return y
                },
                Yn: function() {
                    return b
                },
                Zw: function() {
                    return g
                },
                bR: function() {
                    return v
                },
                cE: function() {
                    return U
                },
                fj: function() {
                    return m
                },
                fw: function() {
                    return x
                },
                mf: function() {
                    return N
                },
                td: function() {
                    return q
                },
                tp: function() {
                    return I
                },
                uG: function() {
                    return w
                },
                v: function() {
                    return k
                }
            });
            var r = Symbol(0),
                i = !1,
                o = !1,
                l = null,
                u = null,
                a = null,
                c = 0,
                s = [],
                f = () => {},
                d = Symbol(0);

            function p() {
                if (!s.length) {
                    i = !1;
                    return
                }
                o = !0;
                for (let e = 0; e < s.length; e++) B(s[e]) || L.call(s[e]);
                s = [], i = !1, o = !1
            }

            function h(e) {
                let t = I();
                return A(t, e.length ? e.bind(null, S.bind(t)) : e, null)
            }

            function m(e) {
                let t = u;
                u = null;
                let n = e();
                return u = t, n
            }

            function g(e) {
                let t = l;
                l = null;
                let n = m(e);
                return l = t, n
            }

            function y() {
                o || p()
            }

            function v() {
                return l
            }

            function b(e, t) {
                try {
                    return A(t, e, null)
                } catch (n) {
                    M(t, n);
                    return
                }
            }

            function x(e, t = l) {
                return P(t, e)
            }

            function k(e, t, n = l) {
                n && ((n.k ? ? = {})[e] = t)
            }

            function w(e) {
                if (!e || !l) return e || f;
                let t = l;
                return t.a ? Array.isArray(t.a) ? t.a.push(e) : t.a = [t.a, e] : t.a = e,
                    function() {
                        3 !== t.f && (e.call(null), N(t.a) ? t.a = null : Array.isArray(t.a) && t.a.splice(t.a.indexOf(e), 1))
                    }
            }
            var E = [];

            function S(e = !0) {
                if (3 === this.f) return;
                let t = e ? this : this.i,
                    n = e ? this.l : this;
                if (t) {
                    E.push(this);
                    do t.f = 3, t.a && C(t), t.b && H(t, 0), t.l && (t.l.i = null), t[r] = null, t.b = null, t.d = null, t.l = null, t.k = null, E.push(t), t = t.i; while (t && E.includes(t[r]))
                }
                n && (n.i = t), t && (t.l = n), E = []
            }

            function C(e) {
                try {
                    if (Array.isArray(e.a))
                        for (let t = 0; t < e.a.length; t++) {
                            let n = e.a[t];
                            n.call(n)
                        } else e.a.call(e.a);
                    e.a = null
                } catch (r) {
                    M(e, r)
                }
            }

            function A(e, t, n) {
                let r = l,
                    i = u;
                l = e, u = n;
                try {
                    return t.call(e)
                } finally {
                    l = r, u = i
                }
            }

            function P(e, t) {
                if (!e) return;
                let n = e,
                    i;
                for (; n;) {
                    if (void 0 !== (i = n.k ? .[t])) return i;
                    n = n[r]
                }
            }

            function M(e, t, n) {
                let i = P(e, d);
                if (!i) throw t;
                try {
                    let o = t instanceof Error ? t : Error(JSON.stringify(t));
                    for (let l of i) l(o)
                } catch (u) {
                    M(e[r], u)
                }
            }

            function L() {
                return 3 === this.f || (u && (!a && u.b && u.b[c] == this ? c++ : a ? a.push(this) : a = [this]), this.o && function e(t) {
                    if (1 === t.f)
                        for (let n = 0; n < t.b.length && (e(t.b[n]), 2 !== t.f); n++);
                    2 === t.f ? function(e) {
                        let t = a,
                            n = c;
                        a = null, c = 0;
                        try {
                            _(e);
                            let r = A(e, e.o, e);
                            if (a) {
                                if (e.b && H(e, c), e.b && c > 0) {
                                    e.b.length = c + a.length;
                                    for (let i = 0; i < a.length; i++) e.b[c + i] = a[i]
                                } else e.b = a;
                                let o;
                                for (let l = c; l < e.b.length; l++)(o = e.b[l]).d ? o.d.push(e) : o.d = [e]
                            } else e.b && c < e.b.length && (H(e, c), e.b.length = c);
                            !e.q && e.t ? T.call(e, r) : (e.j = r, e.t = !0)
                        } catch (u) {
                            M(e, u), 2 === e.f && (_(e), e.b && H(e, 0));
                            return
                        }
                        a = t, c = n, e.f = 0
                    }(t) : t.f = 0
                }(this)), this.j
            }

            function T(e) {
                let t = N(e) ? e(this.j) : e;
                if (this.p(this.j, t) && (this.j = t, this.d))
                    for (let n = 0; n < this.d.length; n++) $(this.d[n], 2);
                return this.j
            }
            var O = function() {
                    this[r] = null, this.i = null, this.l = null, l && l.append(this)
                },
                F = O.prototype;

            function I() {
                return new O
            }
            F.k = null, F.o = null, F.a = null, F.append = function(e) {
                e[r] = this, e.l = this, this.i && (this.i.l = e), e.i = this.i, this.i = e
            };
            var j = function(e, t, n) {
                    O.call(this), this.f = t ? 2 : 0, this.t = !1, this.q = !1, this.b = null, this.d = null, this.j = e, t && (this.o = t), n && n.dirty && (this.p = n.dirty)
                },
                D = j.prototype;

            function z(e, t, n) {
                return new j(e, t, n)
            }

            function R(e, t) {
                return e !== t
            }

            function N(e) {
                return "function" == typeof e
            }

            function B(e) {
                let t = e[r];
                for (; t;) {
                    if (t.o && 2 === t.f) return !0;
                    t = t[r]
                }
                return !1
            }

            function _(e) {
                e.i && e.i[r] === e && S.call(e, !1), e.a && C(e), e.k && e.k[d] && (e.k[d] = [])
            }

            function $(e, t) {
                if (!(e.f >= t) && (e.q && 0 === e.f && (s.push(e), i || (i = !0, queueMicrotask(p))), e.f = t, e.d))
                    for (let n = 0; n < e.d.length; n++) $(e.d[n], 1)
            }

            function H(e, t) {
                let n, r;
                for (let i = t; i < e.b.length; i++)(n = e.b[i]).d && (r = n.d.indexOf(e), n.d[r] = n.d[n.d.length - 1], n.d.pop())
            }

            function q(e, t) {
                let n = z(e, null, t),
                    r = L.bind(n);
                return r.set = T.bind(n), r
            }

            function V(e, t) {
                return L.bind(z(t ? .initial, e, t))
            }

            function U(e, t) {
                let n = z(null, function() {
                    let t = e();
                    return N(t) && w(t), null
                }, void 0);
                return n.q = !0, L.call(n), S.bind(n, !0)
            }
            Object.setPrototypeOf(D, F), D.p = R, D.call = L
        },
        603: function(e, t, n) {
            "use strict";

            function r(e, t) {
                (null == t || t > e.length) && (t = e.length);
                for (var n = 0, r = Array(t); n < t; n++) r[n] = e[n];
                return r
            }

            function i(e, t) {
                return function(e) {
                    if (Array.isArray(e)) return e
                }(e) || function(e) {
                    if ("undefined" != typeof Symbol && null != e[Symbol.iterator] || null != e["@@iterator"]) return Array.from(e)
                }(e, t) || function(e, t) {
                    if (e) {
                        if ("string" == typeof e) return r(e, t);
                        var n = Object.prototype.toString.call(e).slice(8, -1);
                        if ("Object" === n && e.constructor && (n = e.constructor.name), "Map" === n || "Set" === n) return Array.from(n);
                        if ("Arguments" === n || /^(?:Ui|I)nt(?:8|16|32)(?:Clamped)?Array$/.test(n)) return r(e, t)
                    }
                }(e, t) || function() {
                    throw TypeError("Invalid attempt to destructure non-iterable instance.\\nIn order to be iterable, non-array objects must have a [Symbol.iterator]() method.")
                }()
            }
            n.d(t, {
                Z: function() {
                    return i
                }
            })
        },
        4539: function(e, t, n) {
            "use strict";
            n.d(t, {
                Z2: function() {
                    return ef
                },
                UU: function() {
                    return ed
                },
                Sy: function() {
                    return es
                },
                Zz: function() {
                    return ep
                }
            });
            var r = n(629),
                i = n(2805),
                o = n(7371),
                l = n(9739),
                u = n(9071),
                a = n(6765),
                c = n(7294),
                s = c.createContext(null);

            function f(e, t) {
                return c.createElement(s.Provider, {
                    value: e
                }, t)
            }

            function d(e, t) {
                return function(e, t, n) {
                    e(t);
                    class r extends p {}
                    r.displayName = n ? .displayName ? ? (0, i.Fq)(t.tagName), r.contextType = s, r.c = t, r.y = new Set(Object.keys(t.props ? ? {}));
                    let o = c.forwardRef((e, t) => c.createElement(r, { ...e,
                        E: t
                    }, e ? .children));
                    return o.displayName = "ForwardRef_" + r.displayName, o
                }(r.HG, e, t)
            }(class extends c.Component {
                constructor(e, t) {
                    super(e);
                    let n = (0, a.tp)();
                    this.x = n, t && t.append(n);
                    let r = this.constructor;
                    r.p && (0, u.qN)(r.p, r.v ? .(), n)
                }
                render() {
                    return f(this.x, this.props ? .children)
                }
            }).contextType = s;
            var p = class extends c.Component {
                constructor() {
                    super(...arguments), this.d = null
                }
                componentDidMount() {
                    this.d && !this.d.instance && ((0, r.o3)(this.d), this.d.onEventDispatch(e => {
                        let t = `on${(0,i.Fq)(e)}`,
                            n = this.props[t],
                            r = this.constructor;
                        r.q.set(t, e), n && this.A(e, n)
                    }), this.d.attachComponent(this.b))
                }
                componentWillUnmount() {
                    window.requestAnimationFrame(() => {
                        this.d || this.b.destroy()
                    })
                }
                render() {
                    let e = this.constructor,
                        {
                            E: t,
                            className: n,
                            children: r,
                            ...i
                        } = this.props;
                    this.b || (this.l = new Map, this.b = (0, o.c)(e.c, {
                        props: this.props,
                        scope: this.context
                    })), this.r && this.z === t || (this.r = e => {
                        if (this.d = e, t) {
                            var n, r;
                            "function" == typeof(n = t) ? n(e): n.current = e
                        }
                        this.z = t
                    });
                    let u = {
                            class: n,
                            ref: this.r
                        },
                        s = this.b[l.bo];
                    for (let d of Object.keys(i)) {
                        let p = i[d];
                        e.q.has(d) ? this.A(e.q.get(d), p) : e.y.has(d) ? s["$" + d].set(p) : u[d] = p
                    }
                    return (0, a.Ky)(), f(this.b[a.IC], c.createElement(e.c.tagName, { ...u,
                        "mk-d": !0,
                        suppressHydrationWarning: !0
                    }, c.createElement(h, {
                        shadow: e.c.shadowRoot
                    }), r))
                }
                A(e, t) {
                    let n = this.l.get(e);
                    this.d && n ? .handleEvent !== t && (t ? n ? n.handleEvent = t : (this.l.set(e, n = {
                        handleEvent: t
                    }), this.d.addEventListener(e, n)) : n && (this.l.delete(e), this.d.removeEventListener(e, n)))
                }
            };

            function h(e) {
                return c.createElement(e.shadow ? "template" : "shadow-root", {
                    dangerouslySetInnerHTML: {
                        __html: ""
                    },
                    suppressHydrationWarning: !0
                })
            }
            p.q = new Map;
            var m = n(1937),
                g = n(6443),
                y = (0, r.MW)({
                    tagName: "media-outlet",
                    setup({
                        host: e
                    }) {
                        let t = (0, g.G)(),
                            n = (0, a.td)(!1);
                        return (0, r.Qt)(() => {
                            e.el.keepAlive = !0
                        }), (0, u.cE)(() => (t.$loader(), () => n.set(!1))), (0, u.cE)(() => {
                            let e = t.$loader();
                            n() && e && (0, a.fj)(() => {
                                e.load(t).then(n => {
                                    (0, a.fj)(t.$loader) === e && t.delegate.dispatch("provider-change", {
                                        detail: n
                                    })
                                })
                            })
                        }), () => () => (n.set(!0), t.$loader() ? .render(t.$store))
                    }
                }),
                v = (0, r.mT)('<!$><svg viewBox="0 0 32 32" fill="none" aria-hidden="true"></svg>');

            function b({
                slot: e,
                paths: t
            }) {
                return (() => {
                    let [n, i] = (0, r.bG)(v);
                    return (0, r.S1)(n, "slot", e), (0, r.Sb)(n, t), n
                })()
            }

            function x(e, t, n) {
                e.hasAttribute(t) || e.setAttribute(t, n)
            }

            function k(e) {
                let t = !1;
                (0, u.cE)(() => {
                    let n = e();
                    n && ((0, i.yl)(document, "pointerdown", () => {
                        t = !1
                    }), (0, i.yl)(n, "keydown", e => {
                        e.metaKey || e.altKey || e.ctrlKey || (t = !0)
                    }), (0, i.yl)(n, "focus", () => {
                        t && n.classList.add("focus-visible")
                    }), (0, i.yl)(n, "blur", () => {
                        n.classList.remove("focus-visible")
                    }))
                })
            }
            var w = n(8860),
                E = {
                    disabled: {
                        initial: !1
                    },
                    defaultPressed: {
                        initial: !1
                    }
                };

            function S(e, {
                $props: {
                    $pressed: t,
                    $disabled: n
                },
                ...o
            }) {
                function l(e) {
                    let t = n();
                    if (t || (0, i.vd)(e) && !(0, i.gT)(e)) {
                        t && e.stopImmediatePropagation();
                        return
                    }
                    o.onPress ? .(e)
                }
                return e.setAttributes({
                    disabled: n,
                    "aria-pressed": () => (0, w.ariaBool)(t())
                }), k(e.$el), (0, r.Qt)(() => {
                    x(e.el, "tabindex", "0"), x(e.el, "role", "button")
                }), (0, u.cE)(() => {
                    let t = e.$el();
                    if (t)
                        for (let n of ["pointerup", "keydown"])(0, i.yl)(t, n, l)
                }), {
                    get pressed() {
                        return t()
                    },
                    get disabled() {
                        return n()
                    }
                }
            }
            var C = (0, r.MW)({
                    tagName: "media-fullscreen-button",
                    props: { ...E,
                        target: {
                            initial: "prefer-media"
                        }
                    },
                    setup({
                        host: e,
                        props: {
                            $target: t,
                            $disabled: n
                        },
                        accessors: i
                    }) {
                        let {
                            $store: o,
                            remote: l
                        } = (0, g.G)(), u = () => o.fullscreen, a = S(e, {
                            $props: {
                                $pressed: u,
                                $disabled: n
                            },
                            onPress: function(e) {
                                n() || (u() ? l.exitFullscreen(t(), e) : l.enterFullscreen(t(), e))
                            }
                        });
                        return e.setAttributes({
                            hidden: () => !o.canFullscreen,
                            fullscreen: () => o.fullscreen,
                            "aria-label": () => o.fullscreen ? "Exit Fullscreen" : "Enter Fullscreen"
                        }), (0, w.mergeProperties)(a, i(), {
                            $render: () => [(0, r.e1)(b, {
                                paths: '<path d="M25.3299 7.26517C25.2958 6.929 25.0119 6.66666 24.6667 6.66666H19.3334C18.9652 6.66666 18.6667 6.96514 18.6667 7.33333V9.33333C18.6667 9.70152 18.9652 10 19.3334 10L21.8667 10C21.9403 10 22 10.0597 22 10.1333V12.6667C22 13.0349 22.2985 13.3333 22.6667 13.3333H24.6667C25.0349 13.3333 25.3334 13.0349 25.3334 12.6667V7.33333C25.3334 7.31032 25.3322 7.28758 25.3299 7.26517Z" fill="currentColor"/> <path d="M22 21.8667C22 21.9403 21.9403 22 21.8667 22L19.3334 22C18.9652 22 18.6667 22.2985 18.6667 22.6667V24.6667C18.6667 25.0349 18.9652 25.3333 19.3334 25.3333L24.6667 25.3333C25.0349 25.3333 25.3334 25.0349 25.3334 24.6667V19.3333C25.3334 18.9651 25.0349 18.6667 24.6667 18.6667H22.6667C22.2985 18.6667 22 18.9651 22 19.3333V21.8667Z" fill="currentColor"/> <path d="M12.6667 22H10.1334C10.0597 22 10 21.9403 10 21.8667V19.3333C10 18.9651 9.70154 18.6667 9.33335 18.6667H7.33335C6.96516 18.6667 6.66669 18.9651 6.66669 19.3333V24.6667C6.66669 25.0349 6.96516 25.3333 7.33335 25.3333H12.6667C13.0349 25.3333 13.3334 25.0349 13.3334 24.6667V22.6667C13.3334 22.2985 13.0349 22 12.6667 22Z" fill="currentColor"/> <path d="M10 12.6667V10.1333C10 10.0597 10.0597 10 10.1334 10L12.6667 10C13.0349 10 13.3334 9.70152 13.3334 9.33333V7.33333C13.3334 6.96514 13.0349 6.66666 12.6667 6.66666H7.33335C6.96516 6.66666 6.66669 6.96514 6.66669 7.33333V12.6667C6.66669 13.0349 6.96516 13.3333 7.33335 13.3333H9.33335C9.70154 13.3333 10 13.0349 10 12.6667Z" fill="currentColor"/>',
                                slot: "enter"
                            }), (0, r.e1)(b, {
                                paths: '<path d="M19.3334 13.3333C18.9652 13.3333 18.6667 13.0349 18.6667 12.6667L18.6667 7.33333C18.6667 6.96514 18.9652 6.66666 19.3334 6.66666H21.3334C21.7015 6.66666 22 6.96514 22 7.33333V9.86666C22 9.9403 22.0597 10 22.1334 10L24.6667 10C25.0349 10 25.3334 10.2985 25.3334 10.6667V12.6667C25.3334 13.0349 25.0349 13.3333 24.6667 13.3333L19.3334 13.3333Z" fill="currentColor"/> <path d="M13.3334 19.3333C13.3334 18.9651 13.0349 18.6667 12.6667 18.6667H7.33335C6.96516 18.6667 6.66669 18.9651 6.66669 19.3333V21.3333C6.66669 21.7015 6.96516 22 7.33335 22H9.86669C9.94032 22 10 22.0597 10 22.1333L10 24.6667C10 25.0349 10.2985 25.3333 10.6667 25.3333H12.6667C13.0349 25.3333 13.3334 25.0349 13.3334 24.6667L13.3334 19.3333Z" fill="currentColor"/> <path d="M18.6667 24.6667C18.6667 25.0349 18.9652 25.3333 19.3334 25.3333H21.3334C21.7015 25.3333 22 25.0349 22 24.6667V22.1333C22 22.0597 22.0597 22 22.1334 22H24.6667C25.0349 22 25.3334 21.7015 25.3334 21.3333V19.3333C25.3334 18.9651 25.0349 18.6667 24.6667 18.6667L19.3334 18.6667C18.9652 18.6667 18.6667 18.9651 18.6667 19.3333L18.6667 24.6667Z" fill="currentColor"/> <path d="M10.6667 13.3333H12.6667C13.0349 13.3333 13.3334 13.0349 13.3334 12.6667L13.3334 10.6667V7.33333C13.3334 6.96514 13.0349 6.66666 12.6667 6.66666H10.6667C10.2985 6.66666 10 6.96514 10 7.33333L10 9.86666C10 9.9403 9.94033 10 9.86669 10L7.33335 10C6.96516 10 6.66669 10.2985 6.66669 10.6667V12.6667C6.66669 13.0349 6.96516 13.3333 7.33335 13.3333L10.6667 13.3333Z" fill="currentColor"/>',
                                slot: "exit"
                            })]
                        })
                    }
                }),
                A = (0, r.MW)({
                    tagName: "media-mute-button",
                    props: E,
                    setup({
                        host: e,
                        props: {
                            $disabled: t
                        }
                    }) {
                        let {
                            $store: n,
                            remote: i
                        } = (0, g.G)(), o = (0, a.Fl)(() => n.muted || 0 === n.volume), l = S(e, {
                            $props: {
                                $pressed: o,
                                $disabled: t
                            },
                            onPress: function(e) {
                                t() || (o() ? i.unmute(e) : i.mute(e))
                            }
                        });
                        return e.setAttributes({
                            muted: o,
                            "volume-low": () => !n.muted && n.volume > 0 && n.volume < .5,
                            "volume-high": () => !n.muted && n.volume >= .5,
                            "aria-label": () => o() ? "Unmute" : "Mute"
                        }), (0, w.mergeProperties)(l, {
                            $render: () => [(0, r.e1)(b, {
                                paths: '<path d="M17.5091 24.6595C17.5091 25.2066 16.8864 25.5208 16.4463 25.1956L9.44847 20.0252C9.42553 20.0083 9.39776 19.9992 9.36923 19.9992H4.66667C4.29848 19.9992 4 19.7007 4 19.3325V12.6658C4 12.2976 4.29848 11.9992 4.66667 11.9992H9.37115C9.39967 11.9992 9.42745 11.99 9.45039 11.9731L16.4463 6.80363C16.8863 6.47845 17.5091 6.79262 17.5091 7.3398L17.5091 24.6595Z" fill="currentColor"/> <path d="M27.5091 9.33336C27.8773 9.33336 28.1758 9.63184 28.1758 10V22C28.1758 22.3682 27.8773 22.6667 27.5091 22.6667H26.1758C25.8076 22.6667 25.5091 22.3682 25.5091 22V10C25.5091 9.63184 25.8076 9.33336 26.1758 9.33336L27.5091 9.33336Z" fill="currentColor"/> <path d="M22.1758 12C22.544 12 22.8424 12.2985 22.8424 12.6667V19.3334C22.8424 19.7016 22.544 20 22.1758 20H20.8424C20.4743 20 20.1758 19.7016 20.1758 19.3334V12.6667C20.1758 12.2985 20.4743 12 20.8424 12H22.1758Z" fill="currentColor"/>',
                                slot: "volume-high"
                            }), (0, r.e1)(b, {
                                paths: '<path d="M17.5091 24.6594C17.5091 25.2066 16.8864 25.5207 16.4463 25.1956L9.44847 20.0252C9.42553 20.0083 9.39776 19.9991 9.36923 19.9991H4.66667C4.29848 19.9991 4 19.7006 4 19.3324V12.6658C4 12.2976 4.29848 11.9991 4.66667 11.9991H9.37115C9.39967 11.9991 9.42745 11.99 9.45039 11.973L16.4463 6.80358C16.8863 6.4784 17.5091 6.79258 17.5091 7.33975L17.5091 24.6594Z" fill="currentColor"/> <path d="M22.8424 12.6667C22.8424 12.2985 22.544 12 22.1758 12H20.8424C20.4743 12 20.1758 12.2985 20.1758 12.6667V19.3333C20.1758 19.7015 20.4743 20 20.8424 20H22.1758C22.544 20 22.8424 19.7015 22.8424 19.3333V12.6667Z" fill="currentColor"/>',
                                slot: "volume-low"
                            }), (0, r.e1)(b, {
                                paths: '<path d="M17.5091 24.6594C17.5091 25.2066 16.8864 25.5208 16.4463 25.1956L9.44847 20.0252C9.42553 20.0083 9.39776 19.9991 9.36923 19.9991H4.66667C4.29848 19.9991 4 19.7006 4 19.3325V12.6658C4 12.2976 4.29848 11.9991 4.66667 11.9991H9.37115C9.39967 11.9991 9.42745 11.99 9.45039 11.973L16.4463 6.8036C16.8863 6.47842 17.5091 6.79259 17.5091 7.33977L17.5091 24.6594Z" fill="currentColor"/> <path d="M28.8621 13.6422C29.1225 13.3818 29.1225 12.9597 28.8621 12.6994L27.9193 11.7566C27.659 11.4962 27.2368 11.4962 26.9765 11.7566L24.7134 14.0197C24.6613 14.0717 24.5769 14.0717 24.5248 14.0197L22.262 11.7568C22.0016 11.4964 21.5795 11.4964 21.3191 11.7568L20.3763 12.6996C20.116 12.9599 20.116 13.382 20.3763 13.6424L22.6392 15.9053C22.6913 15.9573 22.6913 16.0418 22.6392 16.0938L20.3768 18.3562C20.1165 18.6166 20.1165 19.0387 20.3768 19.299L21.3196 20.2419C21.58 20.5022 22.0021 20.5022 22.2624 20.2418L24.5248 17.9795C24.5769 17.9274 24.6613 17.9274 24.7134 17.9795L26.976 20.2421C27.2363 20.5024 27.6585 20.5024 27.9188 20.2421L28.8616 19.2992C29.122 19.0389 29.122 18.6168 28.8616 18.3564L26.599 16.0938C26.547 16.0418 26.547 15.9573 26.599 15.9053L28.8621 13.6422Z" fill="currentColor"/>',
                                slot: "volume-muted"
                            })]
                        })
                    }
                }),
                P = (0, r.MW)({
                    tagName: "media-play-button",
                    props: E,
                    setup({
                        host: e,
                        props: {
                            $disabled: t
                        }
                    }) {
                        let {
                            $store: n,
                            remote: i
                        } = (0, g.G)(), o = () => !n.paused, l = S(e, {
                            $props: {
                                $pressed: o,
                                $disabled: t
                            },
                            onPress: function(e) {
                                t() || (o() ? i.pause(e) : i.play(e))
                            }
                        });
                        return e.setAttributes({
                            paused: () => n.paused,
                            "aria-label": () => n.paused ? "Play" : "Pause"
                        }), (0, w.mergeProperties)(l, {
                            $render: () => [(0, r.e1)(b, {
                                paths: '<path d="M10.6667 6.6548C10.6667 6.10764 11.2894 5.79346 11.7295 6.11862L24.377 15.4634C24.7377 15.7298 24.7377 16.2692 24.3771 16.5357L11.7295 25.8813C11.2895 26.2065 10.6667 25.8923 10.6667 25.3451L10.6667 6.6548Z" fill="currentColor"/>',
                                slot: "play"
                            }), (0, r.e1)(b, {
                                paths: '<path d="M8.66667 6.66667C8.29848 6.66667 8 6.96514 8 7.33333V24.6667C8 25.0349 8.29848 25.3333 8.66667 25.3333H12.6667C13.0349 25.3333 13.3333 25.0349 13.3333 24.6667V7.33333C13.3333 6.96514 13.0349 6.66667 12.6667 6.66667H8.66667Z" fill="currentColor"/> <path d="M19.3333 6.66667C18.9651 6.66667 18.6667 6.96514 18.6667 7.33333V24.6667C18.6667 25.0349 18.9651 25.3333 19.3333 25.3333H23.3333C23.7015 25.3333 24 25.0349 24 24.6667V7.33333C24 6.96514 23.7015 6.66667 23.3333 6.66667H19.3333Z" fill="currentColor"/>',
                                slot: "pause"
                            })]
                        })
                    }
                }),
                M = n(3984),
                L = (0, r.mT)("<!$><img />"),
                T = (0, r.MW)({
                    tagName: "media-poster",
                    props: {
                        alt: {}
                    },
                    setup({
                        host: e,
                        props: {
                            $alt: t
                        }
                    }) {
                        let {
                            $store: n
                        } = (0, g.G)(), i = new M.w_, o = () => n.canLoad && n.poster.length ? n.poster : null, l = () => o() ? t() : null, c = (0, a.td)(!1), s = (0, a.td)(!1), f = (0, a.td)(!1);

                        function d() {
                            c.set(!1), s.set(!0)
                        }

                        function p() {
                            c.set(!1), f.set(!0)
                        }
                        return e.setAttributes({
                            "img-loading": c,
                            "img-loaded": s,
                            "img-error": f
                        }), (0, r.br)(() => (window.requestAnimationFrame(() => {
                            n.canLoad || (0, M.$P)(n.poster)
                        }), i.setTarget(e.el), i.hidePoster(), () => i.showPoster())), (0, u.cE)(() => {
                            let e = n.canLoad && !!n.poster;
                            c.set(e), s.set(!1), f.set(!1)
                        }), () => (() => {
                            let [e, t] = (0, r.bG)(L);
                            return (0, r.t4)(() => (0, r.S1)(e, "src", o())), (0, r.t4)(() => (0, r.S1)(e, "alt", l())), (0, r.SI)(e, "load", d), (0, r.SI)(e, "error", p), e
                        })()
                    }
                });

            function O(e, t) {
                let n = String(e),
                    r = n.length;
                if (r < t) {
                    let i = "0".repeat(t - r);
                    return `${i}${e}`
                }
                return n
            }

            function F(e) {
                let t = Number((e - Math.trunc(e)).toPrecision(3));
                return {
                    hours: Math.trunc(e / 3600),
                    minutes: Math.trunc(e % 3600 / 60),
                    seconds: Math.trunc(e % 60),
                    fraction: t
                }
            }

            function I(e, t = !1, n = !1) {
                let {
                    hours: r,
                    minutes: i,
                    seconds: o
                } = F(e), l = t ? O(r, 2) : r, u = O(i, 2), a = O(o, 2);
                return r > 0 || n ? `${l}:${u}:${a}` : `${i}:${a}`
            }

            function j(e) {
                let t = [],
                    {
                        hours: n,
                        minutes: r,
                        seconds: i
                    } = F(e),
                    o = (e, t) => 1 === e ? t : `${t}s`;
                return n > 0 && t.push(`${n} ${o(n,"hour")}`), r > 0 && t.push(`${r} ${o(r,"minute")}`), (i > 0 || 0 === t.length) && t.push(`${i} ${o(i,"second")}`), t.join(", ")
            }
            var D = (0, u.MT)({
                    min: 0,
                    max: 100,
                    value: 50,
                    pointerValue: 0,
                    dragging: !1,
                    pointing: !1,
                    get interactive() {
                        return this.dragging || this.pointing
                    },
                    get fillRate() {
                        let z = this.max - this.min,
                            R = this.value - this.min;
                        return z > 0 ? R / z : 0
                    },
                    get fillPercent() {
                        return 100 * this.fillRate
                    },
                    get pointerRate() {
                        let N = this.max - this.min,
                            B = this.pointerValue - this.min;
                        return N > 0 ? B / N : 0
                    },
                    get pointerPercent() {
                        return 100 * this.pointerRate
                    }
                }),
                _ = (0, u.kr)(() => D.create());

            function $() {
                return (0, u.qp)(_)
            }
            var H = n(6291),
                q = (0, r.mT)("<!$><span><!$></span>"),
                V = (0, r.MW)({
                    tagName: "media-slider-value-text",
                    props: {
                        type: {
                            initial: "current"
                        },
                        format: {},
                        showHours: {
                            initial: !1
                        },
                        padHours: {
                            initial: !1
                        },
                        decimalPlaces: {
                            initial: 2
                        }
                    },
                    setup({
                        props: {
                            $type: e,
                            $format: t,
                            $decimalPlaces: n,
                            $padHours: i,
                            $showHours: o
                        }
                    }) {
                        let l = $(),
                            u = (0, a.Fl)(() => {
                                let r = "current" === e() ? l.value : l.pointerValue,
                                    u = t();
                                if ("percent" === u) {
                                    let a = l.max - l.min;
                                    return (0, H.NM)(r / a * 100, n()) + "﹪"
                                }
                                return "time" === u ? I(r, i(), o()) : r.toFixed(2)
                            });
                        return () => (() => {
                            let [e, t] = (0, r.bG)(q), n = t.nextNode();
                            return (0, r.PB)(n, u), e
                        })()
                    }
                }),
                U = (0, r.mT)('<!$><video muted="" playsinline="" preload="auto"></video>'),
                Z = (0, r.MW)({
                    tagName: "media-slider-video",
                    props: {
                        src: {}
                    },
                    setup({
                        host: e,
                        props: {
                            $src: t
                        }
                    }) {
                        let n = null,
                            o = (0, a.td)(!1),
                            l = (0, a.td)(!1),
                            c = $();

                        function s(t) {
                            o.set(!0), (0, i.Nu)(e.el, "can-play", {
                                trigger: t
                            })
                        }

                        function f(t) {
                            l.set(!0), (0, i.Nu)(e.el, "error", {
                                trigger: t
                            })
                        }
                        return e.setAttributes({
                            "can-play": o,
                            error: l
                        }), (0, u.cE)(() => {
                            o() && n && (n.currentTime = c.pointerValue)
                        }), (0, u.cE)(() => {
                            t(), o.set(!1), l.set(!1)
                        }), () => (() => {
                            let [e, i] = (0, r.bG)(U);
                            return (0, r.t4)(() => (0, r.S1)(e, "src", t())), (0, r.SI)(e, "canplay", s), (0, r.SI)(e, "error", f), (0, r.lj)(e, e => void(n = e)), e
                        })()
                    }
                }),
                W = n(2262),
                J = {
                    Left: -1,
                    ArrowLeft: -1,
                    Up: -1,
                    ArrowUp: -1,
                    Right: 1,
                    ArrowRight: 1,
                    Down: 1,
                    ArrowDown: 1
                },
                K = (0, r.mT)('<!$><div part="track"></div>'),
                G = (0, r.mT)('<!$><div part="track track-fill"></div>'),
                Q = (0, r.mT)('<!$><div part="track track-progress"></div>'),
                Y = (0, r.mT)('<!$><div part="thumb-container"><div part="thumb"></div></div>');

            function X(e, {
                $props: t,
                readonly: n,
                aria: o,
                ...l
            }, c) {
                (0, u.qN)(_);
                let s = (0, a.bR)(),
                    f = (0, u.qp)(_),
                    {
                        $disabled: d,
                        $min: p,
                        $max: h,
                        $value: m,
                        $step: y
                    } = t;
                return e.setAttributes({
                    disabled: t.$disabled,
                    dragging: () => f.dragging,
                    pointing: () => f.pointing,
                    interactive: () => f.interactive,
                    "aria-disabled": () => (0, w.ariaBool)(d()),
                    "aria-valuemin": o ? .valueMin ? ? (() => f.min),
                    "aria-valuemax": o ? .valueMax ? ? (() => f.max),
                    "aria-valuenow": o ? .valueNow ? ? (() => f.value),
                    "aria-valuetext": o ? .valueText ? ? (() => (0, H.NM)(f.value / f.max * 100, 2) + "%")
                }), e.setCSSVars({
                    "--slider-fill-rate": () => f.fillRate,
                    "--slider-fill-value": () => f.value,
                    "--slider-fill-percent": () => f.fillPercent + "%",
                    "--slider-pointer-rate": () => f.pointerRate,
                    "--slider-pointer-value": () => f.pointerValue,
                    "--slider-pointer-percent": () => f.pointerPercent + "%"
                }), k(e.$el), ! function(e, {
                    $disabled: t,
                    $step: n,
                    $keyboardStep: r,
                    $shiftKeyMultiplier: o
                }, {
                    onValueChange: l,
                    onDragStart: a,
                    onDragValueChange: c,
                    onDragEnd: s
                }, f) {
                    let d = (0, g.G)().remote;

                    function p(t) {
                        let r = t.clientX,
                            {
                                left: i,
                                width: o
                            } = e.el.getBoundingClientRect();
                        return function(e, t, n, r) {
                            let i = (0, H.IV)(0, n, 1);
                            return e + r * Math.round((t - e) * i / r)
                        }(f.min, f.max, (r - i) / o, n())
                    }

                    function h(t, n) {
                        f.value = t;
                        let r = (0, i.yM)(e.el, "value-change", {
                            detail: f.value,
                            trigger: n
                        });
                        e.el ? .dispatchEvent(r), l ? .(r)
                    }

                    function m(t, n) {
                        if (f.pointerValue = t, (0, i.Nu)(e.el, "value-change", {
                                detail: t,
                                trigger: n
                            }), f.dragging) {
                            let r = (0, i.yM)(e.el, "drag-value-change", {
                                detail: t,
                                trigger: n
                            });
                            e.el ? .dispatchEvent(r), c ? .(r)
                        }
                    }

                    function y() {
                        f.pointing = !0
                    }

                    function v(e) {
                        f.dragging || m(p(e), e)
                    }

                    function b(e) {
                        f.pointing = !1
                    }

                    function x(t) {
                        (function(t) {
                            if (f.dragging) return;
                            f.dragging = !0;
                            let n = p(t);
                            m(n, t), d.pauseUserIdle(t);
                            let r = (0, i.yM)(e.el, "drag-start", {
                                detail: n,
                                trigger: t
                            });
                            e.el ? .dispatchEvent(r), a ? .(r)
                        })(t), m(p(t), t)
                    }

                    function k(e) {
                        let {
                            key: t,
                            shiftKey: i
                        } = e, l = Object.keys(J).includes(t);
                        if (!l) return;
                        let u = i ? r() * o() : r(),
                            a = Number(J[t]),
                            c = (f.value + u * a) / n();
                        h(n() * c, e)
                    }

                    function w(t) {
                        ! function(t) {
                            if (!f.dragging) return;
                            f.dragging = !1;
                            let n = p(t);
                            h(n, t), m(n, t), d.resumeUserIdle(t);
                            let r = (0, i.yM)(e.el, "drag-start", {
                                detail: n,
                                trigger: t
                            });
                            e.el ? .dispatchEvent(r), s ? .(r)
                        }(t)
                    }

                    function E(e) {
                        e.preventDefault()
                    }

                    function S(e) {
                        m(p(e), e)
                    }(0, u.cE)(() => {
                        let n = e.$el();
                        !n || t() || ((0, i.yl)(n, "pointerenter", y), (0, i.yl)(n, "pointermove", v), (0, i.yl)(n, "pointerleave", b), (0, i.yl)(n, "pointerdown", x), (0, i.yl)(n, "keydown", k))
                    }), (0, u.cE)(() => {
                        !t() && f.dragging && ((0, i.yl)(document, "pointerup", w), (0, i.yl)(document, "pointermove", S), W.s$ && (0, i.yl)(document, "touchmove", E, {
                            passive: !1
                        }))
                    })
                }(e, t, l, f), (0, r.Qt)(() => {
                    x(e.el, "role", "slider"), x(e.el, "tabindex", "0"), x(e.el, "aria-orientation", "horizontal"), x(e.el, "autocomplete", "off")
                }), (0, u.cE)(() => {
                    let t = e.$el();
                    if (!t) return;
                    let n = t.querySelector('[slot="preview"]');
                    if (!n) return;
                    let r = n.getBoundingClientRect(),
                        o = {
                            "--computed-width": r.width + "px",
                            "--computed-height": r.height + "px",
                            "--preview-top": "calc(-1 * var(--media-slider-preview-gap, calc(var(--preview-height) + 8px)))",
                            "--preview-width": "var(--media-slider-preview-width, var(--computed-width))",
                            "--preview-height": "var(--media-slider-preview-height, var(--computed-height))",
                            "--preview-width-half": "calc(var(--preview-width) / 2)",
                            "--preview-left-clamp": "max(var(--preview-width-half), var(--slider-pointer-percent))",
                            "--preview-right-clamp": "calc(100% - var(--preview-width-half))",
                            "--preview-left": "min(var(--preview-left-clamp), var(--preview-right-clamp))"
                        };
                    for (let l of Object.keys(o))(0, i.A_)(n, l, o[l]);
                    let u = !1,
                        a = new ResizeObserver(function([e]) {
                            if (u) {
                                u = !1;
                                return
                            }
                            let {
                                inlineSize: t,
                                blockSize: r
                            } = e.borderBoxSize ? .[0] || {
                                inlineSize: e.contentRect.width,
                                blockSize: e.contentRect.height
                            };
                            (0, i.A_)(n, "--computed-width", t + "px"), (0, i.A_)(n, "--computed-height", r + "px"), u = !0
                        });
                    return a.observe(n), () => a.disconnect()
                }), n || ((0, u.cE)(() => {
                    f.min = p(), f.max = h()
                }), (0, u.cE)(() => {
                    if (!(0, a.fj)(() => f.dragging)) {
                        var e, t, n, r;
                        f.value = (e = f.min, t = f.max, n = m(), r = y(), (0, H.IV)(e, (0, H.NM)(n, (0, H.YZ)(r)), t))
                    }
                })), (0, u.cE)(() => {
                    d() && (f.dragging = !1, f.pointing = !1)
                }), {
                    $store: f,
                    members: (0, w.mergeProperties)(f, c(), {
                        $store: f,
                        get dragging() {
                            return f.dragging
                        },
                        get pointing() {
                            return f.pointing
                        },
                        get value() {
                            return f.value
                        },
                        set value(value) {
                            f.value = value
                        },
                        subscribe: e => (0, a.Yn)(() => (0, u.cE)(() => e(f)), s),
                        $render: () => [(0, r.ti)(K), (0, r.ti)(G), (0, r.ti)(Q), (0, r.ti)(Y)]
                    }, {})
                }
            }
            var ee = {
                    min: {
                        initial: 0
                    },
                    max: {
                        initial: 100
                    },
                    disabled: {
                        initial: !1
                    },
                    value: {
                        initial: 100
                    },
                    step: {
                        initial: 1
                    },
                    keyboardStep: {
                        initial: 1
                    },
                    shiftKeyMultiplier: {
                        initial: 5
                    }
                },
                et = (0, r.MW)({
                    tagName: "media-slider",
                    props: ee,
                    setup({
                        host: e,
                        props: t,
                        accessors: n
                    }) {
                        let {
                            members: r
                        } = X(e, {
                            $props: t
                        }, n);
                        return r
                    }
                }),
                en = n(7066),
                er = { ...ee,
                    step: {
                        initial: .1
                    },
                    min: {
                        initial: 0,
                        attribute: !1
                    },
                    max: {
                        initial: 0,
                        attribute: !1
                    },
                    value: {
                        initial: 0,
                        attribute: !1
                    },
                    pauseWhileDragging: {
                        initial: !1
                    },
                    seekingRequestThrottle: {
                        initial: 100
                    }
                },
                ei = (0, r.MW)({
                    tagName: "media-time-slider",
                    props: er,
                    setup({
                        host: e,
                        props: {
                            $pauseWhileDragging: t,
                            $seekingRequestThrottle: n,
                            ...o
                        },
                        accessors: l
                    }) {
                        let {
                            $store: a,
                            remote: c
                        } = (0, g.G)(), {
                            $store: s,
                            members: f
                        } = X(e, {
                            $props: o,
                            readonly: !0,
                            aria: {
                                valueMin: 0,
                                valueMax: 100,
                                valueNow: () => Math.round(s.fillPercent),
                                valueText: () => `${j(s.value)} out of ${j(s.max)}`
                            },
                            onValueChange: function(e) {
                                (0, i.vd)(e.originEvent) && (d.cancel(), c.seek(e.detail, e))
                            },
                            onDragStart: function(e) {
                                t() && (h = !a.paused, c.pause(e))
                            },
                            onDragEnd: function(e) {
                                d.cancel(), c.seek(e.detail, e), t() && h && c.play(e)
                            },
                            onDragValueChange: function(e) {
                                d(e.detail, e)
                            }
                        }, l);
                        (0, r.Qt)(() => {
                            x(e.el, "aria-label", "Media time")
                        }), (0, u.cE)(() => {
                            s.value = a.currentTime
                        }), (0, u.cE)(() => {
                            s.max = a.duration
                        });
                        let d;

                        function p(e, t) {
                            c.seeking(e, t)
                        }(0, u.cE)(() => {
                            d = (0, en.n)(p, n())
                        });
                        let h = !1;
                        return (0, w.mergeProperties)(f, {
                            get min() {
                                return f.min
                            },
                            get max() {
                                return f.max
                            },
                            get value() {
                                return f.value
                            }
                        })
                    }
                }),
                eo = (0, r.mT)("<!$><span><!$></span>"),
                el = (0, r.MW)({
                    tagName: "media-time",
                    props: {
                        type: {
                            initial: "current"
                        },
                        showHours: {
                            initial: !1
                        },
                        padHours: {
                            initial: !1
                        },
                        remainder: {
                            initial: !1
                        }
                    },
                    setup({
                        props: {
                            $remainder: e,
                            $padHours: t,
                            $showHours: n,
                            $type: i
                        }
                    }) {
                        let o = (0, g.G)().$store,
                            l = (0, a.Fl)(() => {
                                let r = function(e, t) {
                                        switch (e) {
                                            case "buffered":
                                                return t.bufferedAmount;
                                            case "seekable":
                                                return t.seekableAmount;
                                            case "duration":
                                                return t.duration;
                                            default:
                                                return t.currentTime
                                        }
                                    }(i(), o),
                                    l = e() ? Math.max(0, o.duration - r) : r;
                                return I(l, t(), n())
                            });
                        return () => (() => {
                            let [e, t] = (0, r.bG)(eo), n = t.nextNode();
                            return (0, r.PB)(n, l), e
                        })()
                    }
                }),
                eu = (0, r.MW)({
                    tagName: "media-toggle-button",
                    props: E,
                    setup({
                        host: e,
                        props: t
                    }) {
                        let n = (0, a.td)(t.$defaultPressed()),
                            r = S(e, {
                                $props: { ...t,
                                    $pressed: n
                                },
                                onPress: function() {
                                    t.$disabled() || n.set(e => !e)
                                }
                            });
                        return e.setAttributes({
                            pressed: n
                        }), r
                    }
                }),
                ea = { ...ee,
                    min: {
                        initial: 0,
                        attribute: !1
                    },
                    max: {
                        initial: 100,
                        attribute: !1
                    },
                    value: {
                        initial: 100,
                        attribute: !1
                    }
                },
                ec = (0, r.MW)({
                    tagName: "media-volume-slider",
                    props: ea,
                    setup({
                        host: e,
                        props: t,
                        accessors: n
                    }) {
                        let {
                            $store: i,
                            remote: o
                        } = (0, g.G)(), {
                            $store: l,
                            members: a
                        } = X(e, {
                            $props: t,
                            readonly: !0,
                            aria: {
                                valueMin: 0,
                                valueMax: 100
                            },
                            onValueChange: (0, en.n)(c, 25),
                            onDragValueChange: (0, en.n)(c, 25)
                        }, n);

                        function c(e) {
                            let t = (0, H.NM)(e.detail / 100, 3);
                            o.changeVolume(t, e)
                        }
                        return (0, r.Qt)(() => {
                            x(e.el, "aria-label", "Media volume")
                        }), (0, u.cE)(() => {
                            l.value = i.muted ? 0 : 100 * i.volume
                        }), (0, w.mergeProperties)(a, {
                            get min() {
                                return a.min
                            },
                            get max() {
                                return a.max
                            },
                            get value() {
                                return a.value
                            }
                        })
                    }
                }),
                es = d(m.a4),
                ef = d(y);
            d(C), d(A);
            var ed = d(P);

            function ep(e) {
                let t = function(e) {
                    let t = c.useContext(s);
                    return c.useMemo(() => (0, a.fw)(e.id, t), [t])
                }(g._);
                return function(e, t, n) {
                    let [r, i] = (0, c.useState)(n), [o, l] = (0, c.useState)(0), s = (0, c.useRef)({
                        $props: (0, a.td)([]),
                        observing: new Set
                    });
                    return (0, c.useEffect)(() => {
                        t ? .current && i(t.current.$store)
                    }, []), (0, c.useEffect)(() => {
                        if (r) return (0, u.cE)(() => {
                            let e = s.current.$props();
                            for (let t = 0; t < e.length; t++) r[e[t]];
                            l(e => e + 1)
                        })
                    }, [r]), (0, c.useMemo)(() => {
                        if (!r) return e.initial;
                        let {
                            observing: t,
                            $props: n
                        } = s.current;
                        return new Proxy(r, {
                            get: (e, i) => (t.has(i) || (n.set(e => [...e, i]), t.add(i)), r[i]),
                            set: u.ZT
                        })
                    }, [r])
                }(m.Gn, e, t ? .$store)
            }
            d(T), d(V), d(Z), d(et), d(ei), d(el), d(eu), d(ec)
        },
        2805: function(e, t, n) {
            "use strict";
            n.d(t, {
                A_: function() {
                    return d
                },
                Cn: function() {
                    return h
                },
                Fj: function() {
                    return V
                },
                Fq: function() {
                    return k
                },
                IR: function() {
                    return q
                },
                KH: function() {
                    return g
                },
                Kh: function() {
                    return v
                },
                LX: function() {
                    return z
                },
                N5: function() {
                    return $
                },
                Nu: function() {
                    return O
                },
                P$: function() {
                    return f
                },
                PD: function() {
                    return m
                },
                Q0: function() {
                    return w
                },
                Rn: function() {
                    return D
                },
                Ss: function() {
                    return I
                },
                VF: function() {
                    return function e(t) {
                        let n = [];
                        for (let r = 0; r < t.length; r++)(0, i.kJ)(t[r]) ? n.push(...e(t[r])) : (t[r] || 0 === t[r]) && n.push(t[r]);
                        return n
                    }
                },
                Xt: function() {
                    return j
                },
                Yr: function() {
                    return s
                },
                ZM: function() {
                    return R
                },
                aY: function() {
                    return u
                },
                bX: function() {
                    return B
                },
                c4: function() {
                    return y
                },
                do: function() {
                    return x
                },
                f2: function() {
                    return A
                },
                gT: function() {
                    return U
                },
                m_: function() {
                    return b
                },
                og: function() {
                    return p
                },
                p0: function() {
                    return E
                },
                qN: function() {
                    return a
                },
                q_: function() {
                    return F
                },
                u4: function() {
                    return S
                },
                uF: function() {
                    return l
                },
                vd: function() {
                    return H
                },
                xJ: function() {
                    return c
                },
                yM: function() {
                    return T
                },
                yb: function() {
                    return L
                },
                yl: function() {
                    return N
                },
                z6: function() {
                    return _
                }
            });
            var r, i = n(9071),
                o = n(6765);

            function l(e) {
                return e instanceof Node
            }

            function u(e) {
                return l(e) && 1 === e.nodeType
            }

            function a(e) {
                return l(e) && 11 === e.nodeType
            }

            function c() {
                return document.createDocumentFragment()
            }

            function s(e) {
                return document.createComment(e)
            }

            function f(e, t, n) {
                if (n || "" === n || 0 === n) {
                    let r = n + "";
                    e.getAttribute(t) !== r && e.setAttribute(t, r)
                } else e.removeAttribute(t)
            }

            function d(e, t, n) {
                n || 0 === n ? e.style.setProperty(t, n + "") : e.style.removeProperty(t)
            }

            function p(e, t, n) {
                e.classList[n ? "add" : "remove"](t)
            }

            function h(e, t) {
                let n = t ? `slot[name="${t}"]` : "slot:not([name])",
                    r = e.shadowRoot ? .querySelector(n),
                    i = r ? .assignedNodes({
                        flatten: !0
                    }) ? ? [];
                return Array.prototype.filter.call(i, e => 1 == e.nodeType)
            }

            function m(e) {
                let t = e.firstChild,
                    n = t.getAttribute("shadowroot"),
                    r = t.parentNode.attachShadow({
                        mode: n
                    });
                r.appendChild(t.content), t.remove()
            }

            function g(e) {
                return e()
            }

            function y(e) {
                for (let t of e) t()
            }

            function v(e) {
                return e.replace(/([a-z])([A-Z])/g, "$1-$2").toLowerCase()
            }

            function b(e) {
                return E(e.replace(/([A-Z])/g, " $1"))
            }

            function x(e) {
                return e.replace(/-./g, e => e[1].toUpperCase())
            }

            function k(e) {
                return w(e).replace(/\s/g, "")
            }

            function w(e) {
                return E(e.replace(/-./g, e => " " + e[1].toUpperCase()))
            }

            function E(e) {
                return e.charAt(0).toUpperCase() + e.slice(1)
            }

            function S(e) {
                return e.charAt(0).toLowerCase() + e.slice(1)
            }
            var C = /;\s*$/;

            function A(e) {
                return e.replace(C, "")
            }
            var P = Event,
                M = Symbol("DOM_EVENT"),
                L = class extends P {
                    constructor(e, ...t) {
                        super(e, t[0]), this[r] = !0, this.detail = t[0] ? .detail, this.trigger = t[0] ? .trigger
                    }
                    get originEvent() {
                        return I(this) ? ? this
                    }
                    get isOriginTrusted() {
                        return I(this) ? .isTrusted ? ? !1
                    }
                };

            function T(e, t, ...n) {
                return new L(t, n[0])
            }

            function O(e, t, ...n) {
                return !!e && e.dispatchEvent(new L(t, n[0]))
            }

            function F(e) {
                return !!e ? .[M]
            }

            function I(e) {
                let t = e.trigger;
                for (; t && t.trigger;) t = t.trigger;
                return t
            }

            function j(e, t) {
                if (!F(e)) return;
                let n = e.trigger;
                for (; n;) {
                    let r = t(n);
                    if (r) return [n, r];
                    n = n.trigger
                }
            }

            function D(e, t) {
                return j(e, e => e.type === t) ? .[0]
            }

            function z(e, t) {
                return !!D(e, t)
            }

            function R(e, t) {
                let n = I(e) ? ? e;
                if (n === t) throw Error("");
                Object.defineProperty(n, "trigger", {
                    configurable: !0,
                    enumerable: !0,
                    get: () => t
                })
            }

            function N(e, t, n, r) {
                return e.addEventListener(t, n, r), (0, o.uG)(() => e.removeEventListener(t, n, r))
            }

            function B(e) {
                return !!e ? .type.startsWith("pointer")
            }

            function _(e) {
                return !!e ? .type.startsWith("touch")
            }

            function $(e) {
                return /^(click|mouse)/.test(e ? .type ? ? "")
            }

            function H(e) {
                return !!e ? .type.startsWith("key")
            }

            function q(e) {
                return H(e) && "Enter" === e.key
            }

            function V(e) {
                return H(e) && "Escape" === e.key
            }

            function U(e) {
                return H(e) && ("Enter" === e.key || " " === e.key)
            }
            r = M
        },
        629: function(e, t, n) {
            "use strict";
            n.d(t, {
                HG: function() {
                    return W
                },
                MW: function() {
                    return z
                },
                PB: function() {
                    return S
                },
                Qt: function() {
                    return U
                },
                S1: function() {
                    return M
                },
                SI: function() {
                    return T
                },
                Sb: function() {
                    return L
                },
                bG: function() {
                    return k
                },
                br: function() {
                    return Z
                },
                e1: function() {
                    return C
                },
                lj: function() {
                    return P
                },
                mT: function() {
                    return x
                },
                o3: function() {
                    return E
                },
                t4: function() {
                    return O
                },
                ti: function() {
                    return w
                }
            });
            var r, i = n(2805),
                o = n(9739),
                l = n(6765),
                u = n(9071),
                a = e => document.createTreeWalker(e, NodeFilter.SHOW_COMMENT, e => "$" === e.nodeValue),
                c = null,
                s = Symbol(0),
                f = (0, i.Yr)("$$"),
                d = Symbol(0),
                p = (0, i.Yr)("/$");

            function h(e, t, n) {
                let r = (0, u.mf)(t);
                r && t[A] && (t = t(), r = (0, u.mf)(t)), r ? g(e, t, n) : !c && (t || 0 === t) && m(e, (0, u.kJ)(t) ? b(t) : (0, i.uF)(t) ? t : document.createTextNode(t + ""), n)
            }

            function m(e, t, n) {
                t && (n ? e.insertBefore(t, n) : e.appendChild(t))
            }

            function g(e, t, n) {
                let r = n && 8 === n.nodeType ? n : f.cloneNode();
                r !== n && m(e, r, n), (0, u.cE)(() => void
                    function(e, t) {
                        let n = e[d];
                        if ((0, u.kJ)(t)) {
                            if (c) e[d] = function(e) {
                                for (; e;) {
                                    if (8 === e.nodeType && "/[]" === e.nodeValue) return e;
                                    e = e.nextSibling
                                }
                            }(e);
                            else {
                                n && v(e, n);
                                let r = b(t);
                                if (!r) return;
                                n || r.appendChild(y(e)), e.after(r)
                            }
                        } else if ((0, i.uF)(t)) n && v(e, n), c || e.after(t), n || t.after(y(e));
                        else if ((0, u.HD)(t) || (0, u.hj)(t)) {
                            if (e[s]) {
                                e.nextSibling.data = t + "";
                                return
                            }
                            n && v(e, n);
                            let o;
                            c ? o = e.nextSibling : (o = document.createTextNode(t + ""), e.after(o)), e[s] = !0, n || o.after(y(e))
                        } else n && v(e, n)
                    }(r, (0, u.D0)(t)))
            }

            function y(e) {
                return e[d] = p.cloneNode()
            }

            function v(e, t) {
                for (; e.nextSibling !== t;) e.nextSibling.remove();
                e[s] = !1
            }

            function b(e) {
                let t = (0, i.VF)(e);
                if (!t.length) return null;
                let n = (0, i.xJ)();
                for (let r = 0; r < t.length; r++) {
                    let o = t[r];
                    (0, u.mf)(o) ? g(n, o): n.append(o)
                }
                return n
            }

            function x(e) {
                let t = document.createElement("template");
                return t.innerHTML = e, t.content
            }

            function k(e, t = c ? .w) {
                try {
                    var n;
                    return [(n = t, n.nextNode().nextSibling), t]
                } catch (r) {
                    return k(e, a(e.cloneNode(!0)))
                }
            }

            function w(e) {
                return k(e)[0]
            }

            function E(e) {
                e.firstChild ? .nodeName === "TEMPLATE" && (e.firstChild.hasAttribute("shadowroot") ? (0, i.PD)(e) : e.firstChild.remove())
            }

            function S(e, t) {
                h(e.parentElement, t, e)
            }

            function C(e, t = {}) {
                return (0, l.fj)(() => e(t))
            }
            i.xJ;
            var A = Symbol(0);

            function P(e, t) {
                (0, u.kJ)(t) ? t.filter(u.mf).forEach(t => t(e)): (0, u.mf)(t) && t(e)
            }
            var M = i.P$;

            function L(e, t) {
                (0, u.mf)(t) ? (0, u.cE)(() => {
                    c || (e.innerHTML = t() + "")
                }) : c || (e.innerHTML = t + "")
            }

            function T(e, t, n, r = !1) {
                (0, u.mf)(n) && (0, i.yl)(e, t, n, {
                    capture: r
                })
            }
            i.og, i.A_, l.fj;
            var O = u.cE;

            function F(e, t) {
                return function(e, t, n) {
                    let r = c;
                    c = n.resume && c ? c : {
                        w: a(n.target)
                    };
                    let i = t(e, n);
                    return c = r, i
                }(e, I, t)
            }

            function I(e, t) {
                return (0, l.Jz)(n => (c ? (0, u.D0)(e) : h(t.target, e()), n))
            }
            l.Fl;
            var j = HTMLElement,
                D = class extends j {
                    constructor() {
                        super(), this.h = !1, this.b = null, this.j = null, this.e = new Set, this.m = [], this.keepAlive = !1, this[r] = [], this.o = !1;
                        let e = this.constructor;
                        e.c.construct ? .call(this)
                    }
                    get C() {
                        return this.hasAttribute("mk-h")
                    }
                    get n() {
                        return this.hasAttribute("mk-d")
                    }
                    get instance() {
                        return this.b
                    }
                    static get observedAttributes() {
                        return this.f ? Array.from(this.f.keys()) : []
                    }
                    attributeChangedCallback(e, t, n) {
                        let r = this.constructor;
                        if (!this.b || !r.f) return;
                        let i = r.f.get(e),
                            l = r.c.props[i] ? .type ? .from;
                        l && this.b[o.bo]["$" + i].set(l(n))
                    }
                    connectedCallback() {
                        let e = this.b;
                        if (!this.n && !e) return this.D();
                        if (!(!e || !this.isConnected || e.host.$connected())) {
                            if (this.h) return;
                            this.hasAttribute("keep-alive") && (this.keepAlive = !0), e.host[o.bo].$connected.set(!0), (0, l.Ky)(), e[o.JD].length && (0, l.Yn)(() => {
                                (0, l.Jz)(t => {
                                    for (let n of (this.j = (0, l.bR)(), e[o.JD]))(0, l.Yn)(() => {
                                        let e = n();
                                        "function" == typeof e && this.m.push(e)
                                    }, this.j);
                                    this.m.push(t)
                                })
                            }, e[l.IC]), (0, u.kJ)(this[o.JD]) && ((0, i.c4)(this[o.JD]), this[o.JD] = !0), (0, l.Ky)()
                        }
                    }
                    disconnectedCallback() {
                        let e = this.b;
                        if (e ? .host.$connected() && !this.h) {
                            for (let t of (e.host[o.bo].$connected.set(!1), (0, l.Ky)(), this.m))(0, l.Yn)(t, this.j);
                            this.j = null, (0, l.Ky)(), this.n || this.keepAlive || requestAnimationFrame(() => {
                                this.isConnected || (e ? .destroy(), this.h = !0)
                            })
                        }
                    }
                    attachComponent(e) {
                        let t = this.constructor,
                            n = t.c,
                            r = t.s;
                        if (this.b || this.h) return;
                        let a = e[o.kq];
                        this.i = a ? n.shadowRoot ? this.shadowRoot ? ? this.attachShadow((0, u.jn)(n.shadowRoot) ? {
                            mode: "open"
                        } : n.shadowRoot) : function(e) {
                            if ((0, i.aY)(e.firstChild) && "shadow-root" === e.firstChild.localName) return e.firstChild; {
                                var t;
                                let n = document.createElement("shadow-root");
                                return e.prepend(n), n
                            }
                        }(this) : null, !c && n.shadowRoot && n.css && r ? .adoptCSS && r.adoptCSS(this.i, n.css);
                        let {
                            $attrs: s,
                            $styles: f
                        } = e.host[o.bo];
                        for (let d of Object.keys(s))(0, l.mf)(s[d]) ? (0, l.cE)(() => (0, i.P$)(this, d, s[d]())) : (0, i.P$)(this, d, s[d]);
                        for (let p of Object.keys(f))(0, l.mf)(f[p]) ? (0, l.cE)(() => (0, i.A_)(this, p, f[p]())) : (0, i.A_)(this, p, f[p]);
                        for (let h of (e.host[o.bo].$attrs = null, e.host[o.bo].$styles = null, e[o.xA] && (Object.defineProperties(this, Object.getOwnPropertyDescriptors(e[o.xA])), e[o.xA] = null), e.host.el = this, this.b = e, [...e[o.Qv], ...this.e]))(0, l.Yn)(h, e[l.IC]);
                        if (this.e = null, this.i && r && a) {
                            let m = this.C ? r.hydrate : r.render;
                            m(a, {
                                target: this.i,
                                resume: !n.shadowRoot
                            })
                        }(0, l.Ky)(), this.connectedCallback()
                    }
                    onAttach(e) {
                        return this.b ? (e(), u.ZT) : (this.e.add(e), () => this.e ? .delete(e))
                    }
                    onEventDispatch(e) {
                        let t = this.constructor;
                        if (t.g)
                            for (let n of t.g) e(n);
                        this.t = e
                    }
                    destroy() {
                        this.disconnectedCallback(), this.b ? .destroy(), this.b = null, this.h = !0
                    }
                    dispatchEvent(e) {
                        if (this.n) {
                            let t = this.constructor;
                            t.g || (t.g = new Set), t.g.has(e.type) || (this.t ? .(e.type), t.g.add(e.type))
                        }
                        return (0, l.Zw)(() => super.dispatchEvent(e))
                    }
                    async D() {
                        if (this.o) return;
                        this.o = !0;
                        let {
                            setup: e
                        } = await n.e(496).then(n.bind(n, 8496));
                        await e(this), this.o = !1
                    }
                };

            function z(e) {
                let t = { ...e,
                    setup(t) {
                        let n = e.setup ? .(t) ? ? {};
                        return (0, u.mf)(n) ? {
                            $render: n
                        } : n
                    }
                };
                if ("props" in t)
                    for (let n of Object.values(t.props)) !1 === n.attribute || n.type || (n.type = q(n.initial));
                return t
            }
            r = o.JD, new WeakMap, o.M5, new WeakMap;
            var R = {
                    from: e => null === e ? "" : e + ""
                },
                N = {
                    from: e => null === e ? 0 : Number(e)
                },
                B = {
                    from: e => null !== e,
                    to: e => e ? "" : null
                },
                _ = {
                    from: !1,
                    to: () => null
                },
                $ = {
                    from: e => null === e ? [] : JSON.parse(e),
                    to: e => JSON.stringify(e)
                },
                H = {
                    from: e => null === e ? {} : JSON.parse(e),
                    to: e => JSON.stringify(e)
                };

            function q(e) {
                switch (typeof e) {
                    case "undefined":
                    case "string":
                    default:
                        return R;
                    case "boolean":
                        return B;
                    case "number":
                        return N;
                    case "function":
                        return _;
                    case "object":
                        return (0, u.kJ)(e) ? $ : H
                }
            }
            var V = e => t => {
                    let n = (0, o.Jm)();
                    n && n[e].push(t)
                },
                U = V(o.Qv),
                Z = V(o.JD);

            function W(e) {
                var t, n;
                t = e, n = {
                    render: I,
                    hydrate: F
                }, customElements.get(t.tagName) || customElements.define(t.tagName, function(e, t) {
                    var n;
                    let r, o;
                    if (e.props)
                        for (let l of (r = new Map, o = new Map, Object.keys(e.props))) {
                            let u = e.props[l],
                                a = u.attribute;
                            if (!1 !== a) {
                                let c = a ? ? (0, i.Kh)(l);
                                r.set(c, l), o.set(l, c)
                            }
                        }
                    return (n = class extends D {}).c = e, n.s = t, n.f = r, n.B = o, n
                }(t, n))
            }
        },
        9071: function(e, t, n) {
            "use strict";
            n.d(t, {
                D0: function() {
                    return x
                },
                FJ: function() {
                    return g
                },
                Ft: function() {
                    return l
                },
                HD: function() {
                    return f
                },
                Kn: function() {
                    return c
                },
                MT: function() {
                    return y
                },
                Wg: function() {
                    return b
                },
                ZT: function() {
                    return o
                },
                cE: function() {
                    return v
                },
                hj: function() {
                    return s
                },
                jn: function() {
                    return d
                },
                kJ: function() {
                    return h
                },
                kK: function() {
                    return a
                },
                kr: function() {
                    return k
                },
                mf: function() {
                    return p
                },
                o8: function() {
                    return u
                },
                p$: function() {
                    return m
                },
                qN: function() {
                    return w
                },
                qp: function() {
                    return E
                },
                yL: function() {
                    return i
                }
            });
            var r = n(6765);

            function i(e) {
                let t = {};
                for (let n of Object.keys(e)) Object.defineProperty(t, n, {
                    configurable: !0,
                    enumerable: !0,
                    get: e[n],
                    set: e[n].set
                });
                return t
            }

            function o(...e) {}

            function l(e) {
                return null === e
            }

            function u(e) {
                return void 0 === e
            }

            function a(e) {
                return l(e) || u(e)
            }

            function c(e) {
                return e ? .constructor === Object
            }

            function s(e) {
                return "number" == typeof e && !Number.isNaN(e)
            }

            function f(e) {
                return "string" == typeof e
            }

            function d(e) {
                return "boolean" == typeof e
            }

            function p(e) {
                return "function" == typeof e
            }

            function h(e) {
                return Array.isArray(e)
            }

            function m(e) {
                return f(e) ? RegExp(e) : e
            }

            function g(e) {
                return e === window
            }

            function y(e) {
                let t = Object.getOwnPropertyDescriptors(e);
                return {
                    initial: e,
                    create() {
                        let n = {};
                        for (let i of Object.keys(e)) {
                            let o = t[i].get || (0, r.td)(e[i]);
                            Object.defineProperty(n, i, {
                                configurable: !0,
                                enumerable: !0,
                                get: o,
                                set: o.set
                            })
                        }
                        return n
                    },
                    reset(n, r) {
                        for (let i of Object.keys(n)) !t[i].get && (!r || r(i)) && (n[i] = e[i])
                    }
                }
            }
            var v = r.cE;

            function b(e) {
                return p(e) ? e() : e
            }

            function x(e) {
                let t = e;
                for (;
                    "function" == typeof t;) t = t();
                return t
            }

            function k(e) {
                return {
                    id: Symbol(),
                    provide: e
                }
            }

            function w(e, t, n = (0, r.bR)()) {
                let i = !u(t);
                (0, r.v)(e.id, i ? t : e.provide ? .(), n)
            }

            function E(e) {
                let t = (0, r.fw)(e.id);
                return t
            }
        },
        7371: function(e, t, n) {
            "use strict";
            n.d(t, {
                c: function() {
                    return l
                }
            });
            var r = n(9739),
                i = n(6765),
                o = n(9071);

            function l(e, t = {}) {
                return (0, i.Jz)(n => {
                    t.scope && t.scope.append((0, i.bR)());
                    let l = null,
                        u = !1,
                        a = "props" in e,
                        c = a ? function(e) {
                            let t = {};
                            for (let n of Object.keys(e)) {
                                let r = e[n];
                                t["$" + n] = (0, i.td)(r.initial, r)
                            }
                            return t
                        }(e.props) : {},
                        s = (0, i.td)(!1),
                        f = {},
                        d = {},
                        p = e => void Object.assign(f, e),
                        h = e => void Object.assign(d, e);
                    if (t.props && a)
                        for (let m of Object.keys(t.props)) m in e.props && c["$" + m].set(t.props[m]);
                    let g = {
                            [r.bo]: {
                                $attrs: f,
                                $styles: d,
                                $connected: s
                            },
                            el: null,
                            $el: () => s() ? g.el : null,
                            $connected: s,
                            setAttributes: p,
                            setStyles: h,
                            setCSSVars: h
                        },
                        y = {
                            host: g,
                            props: c,
                            [i.IC]: (0, i.bR)(),
                            [r.bo]: c,
                            [r.Qv]: [],
                            [r.JD]: [],
                            accessors() {
                                if (l) return l;
                                let t = {};
                                for (let n of Object.keys(e.props)) t[n] = c["$" + n];
                                return l = (0, o.yL)(t)
                            },
                            destroy() {
                                u || (u = !0, g.el ? .destroy(), (0, i.Ky)(), y[r.Qv].length = 0, y[r.JD].length = 0, n(), y[i.IC] = null, y[r.xA] = null, y[r.kq] = null, g.el = null)
                            }
                        };
                    try {
                        (0, r.JN)(y), y[r.xA] = e.setup(y)
                    } finally {
                        (0, r.JN)(null)
                    }
                    let v = y[r.xA] ? .$render;
                    return v && (y[r.kq] = function() {
                        let e = null;
                        return (0, i.Yn)(() => {
                            try {
                                (0, r.JN)(y), e = v()
                            } finally {
                                (0, r.JN)(null)
                            }
                        }, y[i.IC]), e
                    }), (0, i.uG)(y.destroy), y
                })
            }
        },
        9739: function(e, t, n) {
            "use strict";
            n.d(t, {
                JD: function() {
                    return f
                },
                JN: function() {
                    return o
                },
                Jm: function() {
                    return i
                },
                M5: function() {
                    return l
                },
                Qv: function() {
                    return s
                },
                bo: function() {
                    return u
                },
                kq: function() {
                    return c
                },
                xA: function() {
                    return a
                }
            });
            var r = [null];

            function i() {
                return r[r.length - 1]
            }

            function o(e) {
                if (!e) {
                    r.pop();
                    return
                }
                r.push(e)
            }
            var l = Symbol(0),
                u = Symbol(0),
                a = Symbol(0),
                c = Symbol(0),
                s = Symbol(0),
                f = Symbol(0)
        },
        8860: function(e, t, n) {
            "use strict";
            n.r(t), n.d(t, {
                DOMEvent: function() {
                    return r.yb
                },
                animationFrameThrottle: function() {
                    return b
                },
                appendTriggerEvent: function() {
                    return r.ZM
                },
                ariaBool: function() {
                    return u
                },
                attachDeclarativeShadowDOM: function() {
                    return r.PD
                },
                camelToKebabCase: function() {
                    return r.Kh
                },
                camelToTitleCase: function() {
                    return r.m_
                },
                createComment: function() {
                    return r.Yr
                },
                createDisposalBin: function() {
                    return a
                },
                createEvent: function() {
                    return r.yM
                },
                createFragment: function() {
                    return r.xJ
                },
                createRegex: function() {
                    return l.p$
                },
                deferredPromise: function() {
                    return m
                },
                dispatchEvent: function() {
                    return r.Nu
                },
                findTriggerEvent: function() {
                    return r.Rn
                },
                flattenArray: function() {
                    return r.VF
                },
                getOriginEvent: function() {
                    return r.Ss
                },
                getSlottedChildren: function() {
                    return r.Cn
                },
                hasTriggerEvent: function() {
                    return r.LX
                },
                isArray: function() {
                    return l.kJ
                },
                isBoolean: function() {
                    return l.jn
                },
                isDOMElement: function() {
                    return r.aY
                },
                isDOMEvent: function() {
                    return r.q_
                },
                isDOMFragment: function() {
                    return r.qN
                },
                isDOMNode: function() {
                    return r.uF
                },
                isFunction: function() {
                    return l.mf
                },
                isKeyboardClick: function() {
                    return r.gT
                },
                isKeyboardEvent: function() {
                    return r.vd
                },
                isMouseEvent: function() {
                    return r.N5
                },
                isNil: function() {
                    return l.kK
                },
                isNull: function() {
                    return l.Ft
                },
                isNumber: function() {
                    return l.hj
                },
                isObject: function() {
                    return l.Kn
                },
                isPointerEvent: function() {
                    return r.bX
                },
                isString: function() {
                    return l.HD
                },
                isTouchEvent: function() {
                    return r.z6
                },
                isUndefined: function() {
                    return l.o8
                },
                isWindow: function() {
                    return l.FJ
                },
                kebabToCamelCase: function() {
                    return r.do
                },
                kebabToPascalCase: function() {
                    return r.Fq
                },
                kebabToTitleCase: function() {
                    return r.Q0
                },
                keysOf: function() {
                    return f
                },
                listenEvent: function() {
                    return r.yl
                },
                lowercaseFirstLetter: function() {
                    return r.u4
                },
                mergeProperties: function() {
                    return d
                },
                noop: function() {
                    return l.ZT
                },
                omit: function() {
                    return h
                },
                pick: function() {
                    return p
                },
                run: function() {
                    return r.KH
                },
                runAll: function() {
                    return r.c4
                },
                setAttribute: function() {
                    return r.P$
                },
                setStyle: function() {
                    return r.A_
                },
                timedPromise: function() {
                    return g
                },
                toggleClass: function() {
                    return r.og
                },
                trimTrailingSemicolon: function() {
                    return r.f2
                },
                unwrap: function() {
                    return l.Wg
                },
                unwrapDeep: function() {
                    return l.D0
                },
                uppercaseFirstChar: function() {
                    return r.p0
                },
                useDisposalBin: function() {
                    return c
                },
                useHostConnected: function() {
                    return s
                },
                waitAnimationFrame: function() {
                    return v
                },
                waitIdlePeriod: function() {
                    return k
                },
                waitTimeout: function() {
                    return y
                },
                walkTriggerEventChain: function() {
                    return r.Xt
                },
                wasEnterKeyPressed: function() {
                    return r.IR
                },
                wasEscapeKeyPressed: function() {
                    return r.Fj
                }
            });
            var r = n(2805),
                i = n(9739),
                o = n(6765),
                l = n(9071);

            function u(e) {
                return e ? "true" : "false"
            }

            function a() {
                let e = new Set;
                return {
                    add(...t) {
                        for (let n of t) e.add(n)
                    },
                    empty() {
                        for (let t of e) t();
                        e.clear()
                    }
                }
            }

            function c() {
                let e = a();
                return (0, o.uG)(e.empty), e
            }

            function s() {
                let e = (0, i.Jm)();
                if (!e) throw Error("");
                return () => e.host.$connected()
            }

            function f(e) {
                return Object.keys(e)
            }

            function d(...e) {
                let t = {};
                for (let n = 0; n < e.length; n++) {
                    let r = e[n];
                    r && Object.defineProperties(t, Object.getOwnPropertyDescriptors(r))
                }
                return t
            }

            function p(e, t) {
                let n = {};
                for (let r of t) Object.defineProperty(n, r, Object.getOwnPropertyDescriptor(e, r));
                return n
            }

            function h(e, t) {
                return p(e, f(e).filter(e => !t.includes(e)))
            }

            function m() {
                let e, t, n = new Promise((n, r) => {
                    e = n, t = r
                });
                return {
                    promise: n,
                    resolve: e,
                    reject: t
                }
            }

            function g(e, t, n) {
                let r = new Promise((e, r) => {
                    let i = setTimeout(() => {
                        clearTimeout(i), r(n)
                    }, t)
                });
                return Promise.race([e, r])
            }

            function y(e) {
                return new Promise(t => setTimeout(t, e))
            }

            function v(e) {
                return new Promise(t => {
                    window.requestAnimationFrame(n => {
                        e ? .(n), t()
                    })
                })
            }

            function b(e) {
                let t, n = () => !(0, l.o8)(t),
                    r = () => {
                        (0, l.o8)(t) || (window.cancelAnimationFrame(t), t = void 0)
                    };

                function i(...r) {
                    n() || (t = window.requestAnimationFrame(() => {
                        e.apply(this, r), t = void 0
                    }))
                }
                return i.cancel = r, i.pending = n, i
            }
            var x = "requestIdleCallback" in window ? window.requestIdleCallback : e => window.requestAnimationFrame(e);

            function k(e, t) {
                return new Promise(n => {
                    x(t => {
                        e ? .(t), n()
                    }, t)
                })
            }
        },
        3985: function(e, t, n) {
            "use strict";
            n.d(t, {
                D: function() {
                    return nh
                }
            });
            var r = {};
            n.r(r), n.d(r, {
                attentionMarkers: function() {
                    return e1
                },
                contentInitial: function() {
                    return eK
                },
                disable: function() {
                    return e6
                },
                document: function() {
                    return eJ
                },
                flow: function() {
                    return eQ
                },
                flowInitial: function() {
                    return eG
                },
                insideSpan: function() {
                    return e0
                },
                string: function() {
                    return eY
                },
                text: function() {
                    return eX
                }
            });
            var i = {};
            n.r(i), n.d(i, {
                boolean: function() {
                    return tD
                },
                booleanish: function() {
                    return tz
                },
                commaOrSpaceSeparated: function() {
                    return t$
                },
                commaSeparated: function() {
                    return t_
                },
                number: function() {
                    return tN
                },
                overloadedBoolean: function() {
                    return tR
                },
                spaceSeparated: function() {
                    return tB
                }
            });
            var o = n(7294),
                l = n(8738);

            function u(e) {
                return e && "object" == typeof e ? "position" in e || "type" in e ? c(e.position) : "start" in e || "end" in e ? c(e) : "line" in e || "column" in e ? a(e) : "" : ""
            }

            function a(e) {
                return s(e && e.line) + ":" + s(e && e.column)
            }

            function c(e) {
                return a(e && e.start) + "-" + a(e && e.end)
            }

            function s(e) {
                return e && "number" == typeof e ? e : 1
            }
            class f extends Error {
                constructor(e, t, n) {
                    let r = [null, null],
                        i = {
                            start: {
                                line: null,
                                column: null
                            },
                            end: {
                                line: null,
                                column: null
                            }
                        };
                    if (super(), "string" == typeof t && (n = t, t = void 0), "string" == typeof n) {
                        let o = n.indexOf(":"); - 1 === o ? r[1] = n : (r[0] = n.slice(0, o), r[1] = n.slice(o + 1))
                    }
                    t && ("type" in t || "position" in t ? t.position && (i = t.position) : "start" in t || "end" in t ? i = t : ("line" in t || "column" in t) && (i.start = t)), this.name = u(t) || "1:1", this.message = "object" == typeof e ? e.message : e, this.stack = "", "object" == typeof e && e.stack && (this.stack = e.stack), this.reason = this.message, this.fatal, this.line = i.start.line, this.column = i.start.column, this.position = i, this.source = r[0], this.ruleId = r[1], this.file, this.actual, this.expected, this.url, this.note
                }
            }
            f.prototype.file = "", f.prototype.name = "", f.prototype.reason = "", f.prototype.message = "", f.prototype.stack = "", f.prototype.fatal = null, f.prototype.column = null, f.prototype.line = null, f.prototype.source = null, f.prototype.ruleId = null, f.prototype.position = null;
            let d = {
                basename: function(e, t) {
                    if (void 0 !== t && "string" != typeof t) throw TypeError('"ext" argument must be a string');
                    p(e);
                    let n = 0,
                        r = -1,
                        i = e.length,
                        o;
                    if (void 0 === t || 0 === t.length || t.length > e.length) {
                        for (; i--;)
                            if (47 === e.charCodeAt(i)) {
                                if (o) {
                                    n = i + 1;
                                    break
                                }
                            } else r < 0 && (o = !0, r = i + 1);
                        return r < 0 ? "" : e.slice(n, r)
                    }
                    if (t === e) return "";
                    let l = -1,
                        u = t.length - 1;
                    for (; i--;)
                        if (47 === e.charCodeAt(i)) {
                            if (o) {
                                n = i + 1;
                                break
                            }
                        } else l < 0 && (o = !0, l = i + 1), u > -1 && (e.charCodeAt(i) === t.charCodeAt(u--) ? u < 0 && (r = i) : (u = -1, r = l));
                    return n === r ? r = l : r < 0 && (r = e.length), e.slice(n, r)
                },
                dirname: function(e) {
                    if (p(e), 0 === e.length) return ".";
                    let t = -1,
                        n = e.length,
                        r;
                    for (; --n;)
                        if (47 === e.charCodeAt(n)) {
                            if (r) {
                                t = n;
                                break
                            }
                        } else r || (r = !0);
                    return t < 0 ? 47 === e.charCodeAt(0) ? "/" : "." : 1 === t && 47 === e.charCodeAt(0) ? "//" : e.slice(0, t)
                },
                extname: function(e) {
                    p(e);
                    let t = e.length,
                        n = -1,
                        r = 0,
                        i = -1,
                        o = 0,
                        l;
                    for (; t--;) {
                        let u = e.charCodeAt(t);
                        if (47 === u) {
                            if (l) {
                                r = t + 1;
                                break
                            }
                            continue
                        }
                        n < 0 && (l = !0, n = t + 1), 46 === u ? i < 0 ? i = t : 1 !== o && (o = 1) : i > -1 && (o = -1)
                    }
                    return i < 0 || n < 0 || 0 === o || 1 === o && i === n - 1 && i === r + 1 ? "" : e.slice(i, n)
                },
                join: function(...e) {
                    let t = -1,
                        n;
                    for (; ++t < e.length;) p(e[t]), e[t] && (n = void 0 === n ? e[t] : n + "/" + e[t]);
                    return void 0 === n ? "." : function(e) {
                        p(e);
                        let t = 47 === e.charCodeAt(0),
                            n = function e(t, n) {
                                let r = "",
                                    i = 0,
                                    o = -1,
                                    l = 0,
                                    u = -1,
                                    a, c;
                                for (; ++u <= t.length;) {
                                    if (u < t.length) a = t.charCodeAt(u);
                                    else if (47 === a) break;
                                    else a = 47;
                                    if (47 === a) {
                                        if (o === u - 1 || 1 === l);
                                        else if (o !== u - 1 && 2 === l) {
                                            if (r.length < 2 || 2 !== i || 46 !== r.charCodeAt(r.length - 1) || 46 !== r.charCodeAt(r.length - 2)) {
                                                if (r.length > 2) {
                                                    if ((c = r.lastIndexOf("/")) !== r.length - 1) {
                                                        c < 0 ? (r = "", i = 0) : i = (r = r.slice(0, c)).length - 1 - r.lastIndexOf("/"), o = u, l = 0;
                                                        continue
                                                    }
                                                } else if (r.length > 0) {
                                                    r = "", i = 0, o = u, l = 0;
                                                    continue
                                                }
                                            }
                                            n && (r = r.length > 0 ? r + "/.." : "..", i = 2)
                                        } else r.length > 0 ? r += "/" + t.slice(o + 1, u) : r = t.slice(o + 1, u), i = u - o - 1;
                                        o = u, l = 0
                                    } else 46 === a && l > -1 ? l++ : l = -1
                                }
                                return r
                            }(e, !t);
                        return 0 !== n.length || t || (n = "."), n.length > 0 && 47 === e.charCodeAt(e.length - 1) && (n += "/"), t ? "/" + n : n
                    }(n)
                },
                sep: "/"
            };

            function p(e) {
                if ("string" != typeof e) throw TypeError("Path must be a string. Received " + JSON.stringify(e))
            }
            let h = {
                cwd: function() {
                    return "/"
                }
            };

            function m(e) {
                return null !== e && "object" == typeof e && e.href && e.origin
            }
            let g = ["history", "path", "basename", "stem", "extname", "dirname"];
            class y {
                constructor(e) {
                    let t;
                    t = e ? "string" == typeof e || l(e) ? {
                        value: e
                    } : m(e) ? {
                        path: e
                    } : e : {}, this.data = {}, this.messages = [], this.history = [], this.cwd = h.cwd(), this.value, this.stored, this.result, this.map;
                    let n = -1;
                    for (; ++n < g.length;) {
                        let r = g[n];
                        r in t && void 0 !== t[r] && (this[r] = "history" === r ? [...t[r]] : t[r])
                    }
                    let i;
                    for (i in t) g.includes(i) || (this[i] = t[i])
                }
                get path() {
                    return this.history[this.history.length - 1]
                }
                set path(e) {
                    m(e) && (e = function(e) {
                        if ("string" == typeof e) e = new URL(e);
                        else if (!m(e)) {
                            let t = TypeError('The "path" argument must be of type string or an instance of URL. Received `' + e + "`");
                            throw t.code = "ERR_INVALID_ARG_TYPE", t
                        }
                        if ("file:" !== e.protocol) {
                            let n = TypeError("The URL must be of scheme file");
                            throw n.code = "ERR_INVALID_URL_SCHEME", n
                        }
                        return function(e) {
                            if ("" !== e.hostname) {
                                let t = TypeError('File URL host must be "localhost" or empty on darwin');
                                throw t.code = "ERR_INVALID_FILE_URL_HOST", t
                            }
                            let n = e.pathname,
                                r = -1;
                            for (; ++r < n.length;)
                                if (37 === n.charCodeAt(r) && 50 === n.charCodeAt(r + 1)) {
                                    let i = n.charCodeAt(r + 2);
                                    if (70 === i || 102 === i) {
                                        let o = TypeError("File URL path must not include encoded / characters");
                                        throw o.code = "ERR_INVALID_FILE_URL_PATH", o
                                    }
                                }
                            return decodeURIComponent(n)
                        }(e)
                    }(e)), b(e, "path"), this.path !== e && this.history.push(e)
                }
                get dirname() {
                    return "string" == typeof this.path ? d.dirname(this.path) : void 0
                }
                set dirname(e) {
                    x(this.basename, "dirname"), this.path = d.join(e || "", this.basename)
                }
                get basename() {
                    return "string" == typeof this.path ? d.basename(this.path) : void 0
                }
                set basename(e) {
                    b(e, "basename"), v(e, "basename"), this.path = d.join(this.dirname || "", e)
                }
                get extname() {
                    return "string" == typeof this.path ? d.extname(this.path) : void 0
                }
                set extname(e) {
                    if (v(e, "extname"), x(this.dirname, "extname"), e) {
                        if (46 !== e.charCodeAt(0)) throw Error("`extname` must start with `.`");
                        if (e.includes(".", 1)) throw Error("`extname` cannot contain multiple dots")
                    }
                    this.path = d.join(this.dirname, this.stem + (e || ""))
                }
                get stem() {
                    return "string" == typeof this.path ? d.basename(this.path, this.extname) : void 0
                }
                set stem(e) {
                    b(e, "stem"), v(e, "stem"), this.path = d.join(this.dirname || "", e + (this.extname || ""))
                }
                toString(e) {
                    return (this.value || "").toString(e)
                }
                message(e, t, n) {
                    let r = new f(e, t, n);
                    return this.path && (r.name = this.path + ":" + r.name, r.file = this.path), r.fatal = !1, this.messages.push(r), r
                }
                info(e, t, n) {
                    let r = this.message(e, t, n);
                    return r.fatal = null, r
                }
                fail(e, t, n) {
                    let r = this.message(e, t, n);
                    throw r.fatal = !0, r
                }
            }

            function v(e, t) {
                if (e && e.includes(d.sep)) throw Error("`" + t + "` cannot be a path: did not expect `" + d.sep + "`")
            }

            function b(e, t) {
                if (!e) throw Error("`" + t + "` cannot be empty")
            }

            function x(e, t) {
                if (!e) throw Error("Setting `" + t + "` requires `path` to be set too")
            }

            function k(e) {
                if (e) throw e
            }
            var w = n(4470);

            function E(e) {
                if ("object" != typeof e || null === e) return !1;
                let t = Object.getPrototypeOf(e);
                return (null === t || t === Object.prototype || null === Object.getPrototypeOf(t)) && !(Symbol.toStringTag in e) && !(Symbol.iterator in e)
            }
            let S = (function e() {
                    let t = function() {
                            let e = [],
                                t = {
                                    run: function(...t) {
                                        let n = -1,
                                            r = t.pop();
                                        if ("function" != typeof r) throw TypeError("Expected function as last argument, not " + r);
                                        ! function i(o, ...l) {
                                            let u = e[++n],
                                                a = -1;
                                            if (o) {
                                                r(o);
                                                return
                                            }
                                            for (; ++a < t.length;)(null === l[a] || void 0 === l[a]) && (l[a] = t[a]);
                                            t = l, u ? (function(e, t) {
                                                let n;
                                                return function(...t) {
                                                    let o = e.length > t.length,
                                                        l;
                                                    o && t.push(r);
                                                    try {
                                                        l = e.apply(this, t)
                                                    } catch (u) {
                                                        if (o && n) throw u;
                                                        return r(u)
                                                    }
                                                    o || (l instanceof Promise ? l.then(i, r) : l instanceof Error ? r(l) : i(l))
                                                };

                                                function r(e, ...r) {
                                                    n || (n = !0, t(e, ...r))
                                                }

                                                function i(e) {
                                                    r(null, e)
                                                }
                                            })(u, i)(...l) : r(null, ...l)
                                        }(null, ...t)
                                    },
                                    use: function(n) {
                                        if ("function" != typeof n) throw TypeError("Expected `middelware` to be a function, not " + n);
                                        return e.push(n), t
                                    }
                                };
                            return t
                        }(),
                        n = [],
                        r = {},
                        i, o = -1;
                    return u.data = function(e, t) {
                        return "string" == typeof e ? 2 === arguments.length ? (L("data", i), r[e] = t, u) : C.call(r, e) && r[e] || null : e ? (L("data", i), r = e, u) : r
                    }, u.Parser = void 0, u.Compiler = void 0, u.freeze = function() {
                        if (i) return u;
                        for (; ++o < n.length;) {
                            let [e, ...r] = n[o];
                            if (!1 === r[0]) continue;
                            !0 === r[0] && (r[0] = void 0);
                            let l = e.call(u, ...r);
                            "function" == typeof l && t.use(l)
                        }
                        return i = !0, o = Number.POSITIVE_INFINITY, u
                    }, u.attachers = n, u.use = function(e, ...t) {
                        let o;
                        if (L("use", i), null == e);
                        else if ("function" == typeof e) s(e, ...t);
                        else if ("object" == typeof e) Array.isArray(e) ? c(e) : a(e);
                        else throw TypeError("Expected usable value, not `" + e + "`");
                        return o && (r.settings = Object.assign(r.settings || {}, o)), u;

                        function l(e) {
                            if ("function" == typeof e) s(e);
                            else if ("object" == typeof e) {
                                if (Array.isArray(e)) {
                                    let [t, ...n] = e;
                                    s(t, ...n)
                                } else a(e)
                            } else throw TypeError("Expected usable value, not `" + e + "`")
                        }

                        function a(e) {
                            c(e.plugins), e.settings && (o = Object.assign(o || {}, e.settings))
                        }

                        function c(e) {
                            let t = -1;
                            if (null == e);
                            else if (Array.isArray(e))
                                for (; ++t < e.length;) {
                                    let n = e[t];
                                    l(n)
                                } else throw TypeError("Expected a list of plugins, not `" + e + "`")
                        }

                        function s(e, t) {
                            let r = -1,
                                i;
                            for (; ++r < n.length;)
                                if (n[r][0] === e) {
                                    i = n[r];
                                    break
                                }
                            i ? (E(i[1]) && E(t) && (t = w(!0, i[1], t)), i[1] = t) : n.push([...arguments])
                        }
                    }, u.parse = function(e) {
                        u.freeze();
                        let t = F(e),
                            n = u.Parser;
                        return (P("parse", n), A(n, "parse")) ? new n(String(t), t).parse() : n(String(t), t)
                    }, u.stringify = function(e, t) {
                        u.freeze();
                        let n = F(t),
                            r = u.Compiler;
                        return (M("stringify", r), T(e), A(r, "compile")) ? new r(e, n).compile() : r(e, n)
                    }, u.run = function(e, n, r) {
                        if (T(e), u.freeze(), r || "function" != typeof n || (r = n, n = void 0), !r) return new Promise(i);

                        function i(i, o) {
                            t.run(e, F(n), function(t, n, l) {
                                n = n || e, t ? o(t) : i ? i(n) : r(null, n, l)
                            })
                        }
                        i(null, r)
                    }, u.runSync = function(e, t) {
                        let n, r;
                        return u.run(e, t, function(e, t) {
                            k(e), n = t, r = !0
                        }), O("runSync", "run", r), n
                    }, u.process = function(e, t) {
                        if (u.freeze(), P("process", u.Parser), M("process", u.Compiler), !t) return new Promise(n);

                        function n(n, r) {
                            let i = F(e);

                            function o(e, i) {
                                e || !i ? r(e) : n ? n(i) : t(null, i)
                            }
                            u.run(u.parse(i), i, (e, t, n) => {
                                if (!e && t && n) {
                                    var r;
                                    let i = u.stringify(t, n);
                                    null == i || ((r = i, "string" == typeof r || l(r)) ? n.value = i : n.result = i), o(e, n)
                                } else o(e)
                            })
                        }
                        n(null, t)
                    }, u.processSync = function(e) {
                        let t;
                        u.freeze(), P("processSync", u.Parser), M("processSync", u.Compiler);
                        let n = F(e);
                        return u.process(n, function(e) {
                            t = !0, k(e)
                        }), O("processSync", "process", t), n
                    }, u;

                    function u() {
                        let t = e(),
                            i = -1;
                        for (; ++i < n.length;) t.use(...n[i]);
                        return t.data(w(!0, {}, r)), t
                    }
                })().freeze(),
                C = {}.hasOwnProperty;

            function A(e, t) {
                return "function" == typeof e && e.prototype && (function(e) {
                    let t;
                    for (t in e)
                        if (C.call(e, t)) return !0;
                    return !1
                }(e.prototype) || t in e.prototype)
            }

            function P(e, t) {
                if ("function" != typeof t) throw TypeError("Cannot `" + e + "` without `Parser`")
            }

            function M(e, t) {
                if ("function" != typeof t) throw TypeError("Cannot `" + e + "` without `Compiler`")
            }

            function L(e, t) {
                if (t) throw Error("Cannot call `" + e + "` on a frozen processor.\nCreate a new processor first, by calling it: use `processor()` instead of `processor`.")
            }

            function T(e) {
                if (!E(e) || "string" != typeof e.type) throw TypeError("Expected node, got `" + e + "`")
            }

            function O(e, t, n) {
                if (!n) throw Error("`" + e + "` finished async. Use `" + t + "` instead")
            }

            function F(e) {
                var t;
                return (t = e, Boolean(t && "object" == typeof t && "message" in t && "messages" in t)) ? e : new y(e)
            }

            function I(e, t) {
                return e && "object" == typeof e && (e.value || (t ? e.alt : "") || "children" in e && j(e.children, t) || Array.isArray(e) && j(e, t)) || ""
            }

            function j(e, t) {
                for (var n = [], r = -1; ++r < e.length;) n[r] = I(e[r], t);
                return n.join("")
            }

            function D(e, t, n, r) {
                let i = e.length,
                    o = 0,
                    l;
                if (t = t < 0 ? -t > i ? 0 : i + t : t > i ? i : t, n = n > 0 ? n : 0, r.length < 1e4)(l = Array.from(r)).unshift(t, n), [].splice.apply(e, l);
                else
                    for (n && [].splice.apply(e, [t, n]); o < r.length;)(l = r.slice(o, o + 1e4)).unshift(t, 0), [].splice.apply(e, l), o += 1e4, t += 1e4
            }

            function z(e, t) {
                return e.length > 0 ? (D(e, e.length, 0, t), e) : t
            }
            let R = {}.hasOwnProperty;

            function N(e, t) {
                let n;
                for (n in t) {
                    let r = R.call(e, n) ? e[n] : void 0,
                        i = r || (e[n] = {}),
                        o = t[n],
                        l;
                    for (l in o) {
                        R.call(i, l) || (i[l] = []);
                        let u = o[l];
                        B(i[l], Array.isArray(u) ? u : u ? [u] : [])
                    }
                }
            }

            function B(e, t) {
                let n = -1,
                    r = [];
                for (; ++n < t.length;)("after" === t[n].add ? e : r).push(t[n]);
                D(e, 0, 0, r)
            }
            let _ = Y(/[A-Za-z]/),
                $ = Y(/\d/),
                H = Y(/[\dA-Fa-f]/),
                q = Y(/[\dA-Za-z]/),
                V = Y(/[!-/:-@[-`{-~]/),
                U = Y(/[#-'*+\--9=?A-Z^-~]/);

            function Z(e) {
                return null !== e && (e < 32 || 127 === e)
            }

            function W(e) {
                return null !== e && (e < 0 || 32 === e)
            }

            function J(e) {
                return null !== e && e < -2
            }

            function K(e) {
                return -2 === e || -1 === e || 32 === e
            }
            let G = Y(/\s/),
                Q = Y(/[!-/:-@[-`{-~\u00A1\u00A7\u00AB\u00B6\u00B7\u00BB\u00BF\u037E\u0387\u055A-\u055F\u0589\u058A\u05BE\u05C0\u05C3\u05C6\u05F3\u05F4\u0609\u060A\u060C\u060D\u061B\u061E\u061F\u066A-\u066D\u06D4\u0700-\u070D\u07F7-\u07F9\u0830-\u083E\u085E\u0964\u0965\u0970\u09FD\u0A76\u0AF0\u0C77\u0C84\u0DF4\u0E4F\u0E5A\u0E5B\u0F04-\u0F12\u0F14\u0F3A-\u0F3D\u0F85\u0FD0-\u0FD4\u0FD9\u0FDA\u104A-\u104F\u10FB\u1360-\u1368\u1400\u166E\u169B\u169C\u16EB-\u16ED\u1735\u1736\u17D4-\u17D6\u17D8-\u17DA\u1800-\u180A\u1944\u1945\u1A1E\u1A1F\u1AA0-\u1AA6\u1AA8-\u1AAD\u1B5A-\u1B60\u1BFC-\u1BFF\u1C3B-\u1C3F\u1C7E\u1C7F\u1CC0-\u1CC7\u1CD3\u2010-\u2027\u2030-\u2043\u2045-\u2051\u2053-\u205E\u207D\u207E\u208D\u208E\u2308-\u230B\u2329\u232A\u2768-\u2775\u27C5\u27C6\u27E6-\u27EF\u2983-\u2998\u29D8-\u29DB\u29FC\u29FD\u2CF9-\u2CFC\u2CFE\u2CFF\u2D70\u2E00-\u2E2E\u2E30-\u2E4F\u2E52\u3001-\u3003\u3008-\u3011\u3014-\u301F\u3030\u303D\u30A0\u30FB\uA4FE\uA4FF\uA60D-\uA60F\uA673\uA67E\uA6F2-\uA6F7\uA874-\uA877\uA8CE\uA8CF\uA8F8-\uA8FA\uA8FC\uA92E\uA92F\uA95F\uA9C1-\uA9CD\uA9DE\uA9DF\uAA5C-\uAA5F\uAADE\uAADF\uAAF0\uAAF1\uABEB\uFD3E\uFD3F\uFE10-\uFE19\uFE30-\uFE52\uFE54-\uFE61\uFE63\uFE68\uFE6A\uFE6B\uFF01-\uFF03\uFF05-\uFF0A\uFF0C-\uFF0F\uFF1A\uFF1B\uFF1F\uFF20\uFF3B-\uFF3D\uFF3F\uFF5B\uFF5D\uFF5F-\uFF65]/);

            function Y(e) {
                return function(t) {
                    return null !== t && e.test(String.fromCharCode(t))
                }
            }

            function X(e, t, n, r) {
                let i = r ? r - 1 : Number.POSITIVE_INFINITY,
                    o = 0;
                return function(r) {
                    return K(r) ? (e.enter(n), function r(l) {
                        return K(l) && o++ < i ? (e.consume(l), r) : (e.exit(n), t(l))
                    }(r)) : t(r)
                }
            }
            let ee = {
                    tokenize: function(e) {
                        let t = e.attempt(this.parser.constructs.contentInitial, function(n) {
                                if (null === n) {
                                    e.consume(n);
                                    return
                                }
                                return e.enter("lineEnding"), e.consume(n), e.exit("lineEnding"), X(e, t, "linePrefix")
                            }, function(t) {
                                return e.enter("paragraph"),
                                    function t(r) {
                                        let i = e.enter("chunkText", {
                                            contentType: "text",
                                            previous: n
                                        });
                                        return n && (n.next = i), n = i,
                                            function n(r) {
                                                if (null === r) {
                                                    e.exit("chunkText"), e.exit("paragraph"), e.consume(r);
                                                    return
                                                }
                                                return J(r) ? (e.consume(r), e.exit("chunkText"), t) : (e.consume(r), n)
                                            }(r)
                                    }(t)
                            }),
                            n;
                        return t
                    }
                },
                et = {
                    tokenize: function(e) {
                        let t = this,
                            n = [],
                            r = 0,
                            i, o, l;
                        return u;

                        function u(i) {
                            if (r < n.length) {
                                let o = n[r];
                                return t.containerState = o[1], e.attempt(o[0].continuation, a, c)(i)
                            }
                            return c(i)
                        }

                        function a(e) {
                            if (r++, t.containerState._closeFlow) {
                                t.containerState._closeFlow = void 0, i && y();
                                let n = t.events.length,
                                    o = n,
                                    l;
                                for (; o--;)
                                    if ("exit" === t.events[o][0] && "chunkFlow" === t.events[o][1].type) {
                                        l = t.events[o][1].end;
                                        break
                                    }
                                g(r);
                                let a = n;
                                for (; a < t.events.length;) t.events[a][1].end = Object.assign({}, l), a++;
                                return D(t.events, o + 1, 0, t.events.slice(n)), t.events.length = a, c(e)
                            }
                            return u(e)
                        }

                        function c(o) {
                            if (r === n.length) {
                                if (!i) return d(o);
                                if (i.currentConstruct && i.currentConstruct.concrete) return h(o);
                                t.interrupt = Boolean(i.currentConstruct && !i._gfmTableDynamicInterruptHack)
                            }
                            return t.containerState = {}, e.check(en, s, f)(o)
                        }

                        function s(e) {
                            return i && y(), g(r), d(e)
                        }

                        function f(e) {
                            return t.parser.lazy[t.now().line] = r !== n.length, l = t.now().offset, h(e)
                        }

                        function d(n) {
                            return t.containerState = {}, e.attempt(en, p, h)(n)
                        }

                        function p(e) {
                            return r++, n.push([t.currentConstruct, t.containerState]), d(e)
                        }

                        function h(n) {
                            if (null === n) {
                                i && y(), g(0), e.consume(n);
                                return
                            }
                            return i = i || t.parser.flow(t.now()), e.enter("chunkFlow", {
                                    contentType: "flow",
                                    previous: o,
                                    _tokenizer: i
                                }),
                                function n(i) {
                                    if (null === i) {
                                        m(e.exit("chunkFlow"), !0), g(0), e.consume(i);
                                        return
                                    }
                                    return J(i) ? (e.consume(i), m(e.exit("chunkFlow")), r = 0, t.interrupt = void 0, u) : (e.consume(i), n)
                                }(n)
                        }

                        function m(e, n) {
                            let u = t.sliceStream(e);
                            if (n && u.push(null), e.previous = o, o && (o.next = e), o = e, i.defineSkip(e.start), i.write(u), t.parser.lazy[e.start.line]) {
                                let a = i.events.length;
                                for (; a--;)
                                    if (i.events[a][1].start.offset < l && (!i.events[a][1].end || i.events[a][1].end.offset > l)) return;
                                let c = t.events.length,
                                    s = c,
                                    f, d;
                                for (; s--;)
                                    if ("exit" === t.events[s][0] && "chunkFlow" === t.events[s][1].type) {
                                        if (f) {
                                            d = t.events[s][1].end;
                                            break
                                        }
                                        f = !0
                                    }
                                for (g(r), a = c; a < t.events.length;) t.events[a][1].end = Object.assign({}, d), a++;
                                D(t.events, s + 1, 0, t.events.slice(c)), t.events.length = a
                            }
                        }

                        function g(r) {
                            let i = n.length;
                            for (; i-- > r;) {
                                let o = n[i];
                                t.containerState = o[1], o[0].exit.call(t, e)
                            }
                            n.length = r
                        }

                        function y() {
                            i.write([null]), o = void 0, i = void 0, t.containerState._closeFlow = void 0
                        }
                    }
                },
                en = {
                    tokenize: function(e, t, n) {
                        return X(e, e.attempt(this.parser.constructs.document, t, n), "linePrefix", this.parser.constructs.disable.null.includes("codeIndented") ? void 0 : 4)
                    }
                },
                er = {
                    tokenize: function(e, t, n) {
                        return X(e, function(e) {
                            return null === e || J(e) ? t(e) : n(e)
                        }, "linePrefix")
                    },
                    partial: !0
                };

            function ei(e) {
                let t = {},
                    n = -1,
                    r, i, o, l, u, a, c;
                for (; ++n < e.length;) {
                    for (;
                        (n in t);) n = t[n];
                    if (r = e[n], n && "chunkFlow" === r[1].type && "listItemPrefix" === e[n - 1][1].type && ((o = 0) < (a = r[1]._tokenizer.events).length && "lineEndingBlank" === a[o][1].type && (o += 2), o < a.length && "content" === a[o][1].type))
                        for (; ++o < a.length && "content" !== a[o][1].type;) "chunkText" === a[o][1].type && (a[o][1]._isInFirstContentOfListItem = !0, o++);
                    if ("enter" === r[0]) r[1].contentType && (Object.assign(t, eo(e, n)), n = t[n], c = !0);
                    else if (r[1]._container) {
                        for (o = n, i = void 0; o--;)
                            if ("lineEnding" === (l = e[o])[1].type || "lineEndingBlank" === l[1].type) "enter" === l[0] && (i && (e[i][1].type = "lineEndingBlank"), l[1].type = "lineEnding", i = o);
                            else break;
                        i && (r[1].end = Object.assign({}, e[i][1].start), (u = e.slice(i, n)).unshift(r), D(e, i, n - i + 1, u))
                    }
                }
                return !c
            }

            function eo(e, t) {
                let n = e[t][1],
                    r = e[t][2],
                    i = t - 1,
                    o = [],
                    l = n._tokenizer || r.parser[n.contentType](n.start),
                    u = l.events,
                    a = [],
                    c = {},
                    s, f, d = -1,
                    p = n,
                    h = 0,
                    m = 0,
                    g = [m];
                for (; p;) {
                    for (; e[++i][1] !== p;);
                    o.push(i), !p._tokenizer && (s = r.sliceStream(p), p.next || s.push(null), f && l.defineSkip(p.start), p._isInFirstContentOfListItem && (l._gfmTasklistFirstContentOfListItem = !0), l.write(s), p._isInFirstContentOfListItem && (l._gfmTasklistFirstContentOfListItem = void 0)), f = p, p = p.next
                }
                for (p = n; ++d < u.length;) "exit" === u[d][0] && "enter" === u[d - 1][0] && u[d][1].type === u[d - 1][1].type && u[d][1].start.line !== u[d][1].end.line && (m = d + 1, g.push(m), p._tokenizer = void 0, p.previous = void 0, p = p.next);
                for (l.events = [], p ? (p._tokenizer = void 0, p.previous = void 0) : g.pop(), d = g.length; d--;) {
                    let y = u.slice(g[d], g[d + 1]),
                        v = o.pop();
                    a.unshift([v, v + y.length - 1]), D(e, v, 2, y)
                }
                for (d = -1; ++d < a.length;) c[h + a[d][0]] = h + a[d][1], h += a[d][1] - a[d][0] - 1;
                return c
            }
            let el = {
                    tokenize: function(e, t) {
                        let n;
                        return function(t) {
                            return e.enter("content"), n = e.enter("chunkContent", {
                                contentType: "content"
                            }), r(t)
                        };

                        function r(t) {
                            return null === t ? i(t) : J(t) ? e.check(eu, o, i)(t) : (e.consume(t), r)
                        }

                        function i(n) {
                            return e.exit("chunkContent"), e.exit("content"), t(n)
                        }

                        function o(t) {
                            return e.consume(t), e.exit("chunkContent"), n.next = e.enter("chunkContent", {
                                contentType: "content",
                                previous: n
                            }), n = n.next, r
                        }
                    },
                    resolve: function(e) {
                        return ei(e), e
                    }
                },
                eu = {
                    tokenize: function(e, t, n) {
                        let r = this;
                        return function(t) {
                            return e.exit("chunkContent"), e.enter("lineEnding"), e.consume(t), e.exit("lineEnding"), X(e, i, "linePrefix")
                        };

                        function i(i) {
                            if (null === i || J(i)) return n(i);
                            let o = r.events[r.events.length - 1];
                            return !r.parser.constructs.disable.null.includes("codeIndented") && o && "linePrefix" === o[1].type && o[2].sliceSerialize(o[1], !0).length >= 4 ? t(i) : e.interrupt(r.parser.constructs.flow, n, t)(i)
                        }
                    },
                    partial: !0
                },
                ea = {
                    tokenize: function(e) {
                        let t = this,
                            n = e.attempt(er, function(r) {
                                if (null === r) {
                                    e.consume(r);
                                    return
                                }
                                return e.enter("lineEndingBlank"), e.consume(r), e.exit("lineEndingBlank"), t.currentConstruct = void 0, n
                            }, e.attempt(this.parser.constructs.flowInitial, r, X(e, e.attempt(this.parser.constructs.flow, r, e.attempt(el, r)), "linePrefix")));
                        return n;

                        function r(r) {
                            if (null === r) {
                                e.consume(r);
                                return
                            }
                            return e.enter("lineEnding"), e.consume(r), e.exit("lineEnding"), t.currentConstruct = void 0, n
                        }
                    }
                },
                ec = {
                    resolveAll: ep()
                },
                es = ed("string"),
                ef = ed("text");

            function ed(e) {
                return {
                    tokenize: function(t) {
                        let n = this,
                            r = this.parser.constructs[e],
                            i = t.attempt(r, o, l);
                        return o;

                        function o(e) {
                            return a(e) ? i(e) : l(e)
                        }

                        function l(e) {
                            if (null === e) {
                                t.consume(e);
                                return
                            }
                            return t.enter("data"), t.consume(e), u
                        }

                        function u(e) {
                            return a(e) ? (t.exit("data"), i(e)) : (t.consume(e), u)
                        }

                        function a(e) {
                            if (null === e) return !0;
                            let t = r[e],
                                i = -1;
                            if (t)
                                for (; ++i < t.length;) {
                                    let o = t[i];
                                    if (!o.previous || o.previous.call(n, n.previous)) return !0
                                }
                            return !1
                        }
                    },
                    resolveAll: ep("text" === e ? eh : void 0)
                }
            }

            function ep(e) {
                return function(t, n) {
                    let r = -1,
                        i;
                    for (; ++r <= t.length;) void 0 === i ? t[r] && "data" === t[r][1].type && (i = r, r++) : t[r] && "data" === t[r][1].type || (r !== i + 2 && (t[i][1].end = t[r - 1][1].end, t.splice(i + 2, r - i - 2), r = i + 2), i = void 0);
                    return e ? e(t, n) : t
                }
            }

            function eh(e, t) {
                let n = 0;
                for (; ++n <= e.length;)
                    if ((n === e.length || "lineEnding" === e[n][1].type) && "data" === e[n - 1][1].type) {
                        let r = e[n - 1][1],
                            i = t.sliceStream(r),
                            o = i.length,
                            l = -1,
                            u = 0,
                            a;
                        for (; o--;) {
                            let c = i[o];
                            if ("string" == typeof c) {
                                for (l = c.length; 32 === c.charCodeAt(l - 1);) u++, l--;
                                if (l) break;
                                l = -1
                            } else if (-2 === c) a = !0, u++;
                            else if (-1 === c);
                            else {
                                o++;
                                break
                            }
                        }
                        if (u) {
                            let s = {
                                type: n === e.length || a || u < 2 ? "lineSuffix" : "hardBreakTrailing",
                                start: {
                                    line: r.end.line,
                                    column: r.end.column - u,
                                    offset: r.end.offset - u,
                                    _index: r.start._index + o,
                                    _bufferIndex: o ? l : r.start._bufferIndex + l
                                },
                                end: Object.assign({}, r.end)
                            };
                            r.end = Object.assign({}, s.start), r.start.offset === r.end.offset ? Object.assign(r, s) : (e.splice(n, 0, ["enter", s, t], ["exit", s, t]), n += 2)
                        }
                        n++
                    }
                return e
            }

            function em(e, t, n) {
                let r = [],
                    i = -1;
                for (; ++i < e.length;) {
                    let o = e[i].resolveAll;
                    o && !r.includes(o) && (t = o(t, n), r.push(o))
                }
                return t
            }
            let eg = {
                    name: "thematicBreak",
                    tokenize: function(e, t, n) {
                        let r = 0,
                            i;
                        return function(o) {
                            return e.enter("thematicBreak"), i = o,
                                function o(l) {
                                    return l === i ? (e.enter("thematicBreakSequence"), function t(n) {
                                        return n === i ? (e.consume(n), r++, t) : (e.exit("thematicBreakSequence"), o(n))
                                    }(l)) : K(l) ? X(e, o, "whitespace")(l) : r < 3 || null !== l && !J(l) ? n(l) : (e.exit("thematicBreak"), t(l))
                                }(o)
                        }
                    }
                },
                ey = {
                    name: "list",
                    tokenize: function(e, t, n) {
                        let r = this,
                            i = r.events[r.events.length - 1],
                            o = i && "linePrefix" === i[1].type ? i[2].sliceSerialize(i[1], !0).length : 0,
                            l = 0;
                        return function(t) {
                            let i = r.containerState.type || (42 === t || 43 === t || 45 === t ? "listUnordered" : "listOrdered");
                            if ("listUnordered" === i ? !r.containerState.marker || t === r.containerState.marker : $(t)) {
                                if (r.containerState.type || (r.containerState.type = i, e.enter(i, {
                                        _container: !0
                                    })), "listUnordered" === i) return e.enter("listItemPrefix"), 42 === t || 45 === t ? e.check(eg, n, u)(t) : u(t);
                                if (!r.interrupt || 49 === t) return e.enter("listItemPrefix"), e.enter("listItemValue"),
                                    function t(i) {
                                        return $(i) && ++l < 10 ? (e.consume(i), t) : (!r.interrupt || l < 2) && (r.containerState.marker ? i === r.containerState.marker : 41 === i || 46 === i) ? (e.exit("listItemValue"), u(i)) : n(i)
                                    }(t)
                            }
                            return n(t)
                        };

                        function u(t) {
                            return e.enter("listItemMarker"), e.consume(t), e.exit("listItemMarker"), r.containerState.marker = r.containerState.marker || t, e.check(er, r.interrupt ? n : a, e.attempt(ev, s, c))
                        }

                        function a(e) {
                            return r.containerState.initialBlankLine = !0, o++, s(e)
                        }

                        function c(t) {
                            return K(t) ? (e.enter("listItemPrefixWhitespace"), e.consume(t), e.exit("listItemPrefixWhitespace"), s) : n(t)
                        }

                        function s(n) {
                            return r.containerState.size = o + r.sliceSerialize(e.exit("listItemPrefix"), !0).length, t(n)
                        }
                    },
                    continuation: {
                        tokenize: function(e, t, n) {
                            let r = this;
                            return r.containerState._closeFlow = void 0, e.check(er, function(n) {
                                return r.containerState.furtherBlankLines = r.containerState.furtherBlankLines || r.containerState.initialBlankLine, X(e, t, "listItemIndent", r.containerState.size + 1)(n)
                            }, function(n) {
                                return r.containerState.furtherBlankLines || !K(n) ? (r.containerState.furtherBlankLines = void 0, r.containerState.initialBlankLine = void 0, i(n)) : (r.containerState.furtherBlankLines = void 0, r.containerState.initialBlankLine = void 0, e.attempt(eb, t, i)(n))
                            });

                            function i(i) {
                                return r.containerState._closeFlow = !0, r.interrupt = void 0, X(e, e.attempt(ey, t, n), "linePrefix", r.parser.constructs.disable.null.includes("codeIndented") ? void 0 : 4)(i)
                            }
                        }
                    },
                    exit: function(e) {
                        e.exit(this.containerState.type)
                    }
                },
                ev = {
                    tokenize: function(e, t, n) {
                        let r = this;
                        return X(e, function(e) {
                            let i = r.events[r.events.length - 1];
                            return !K(e) && i && "listItemPrefixWhitespace" === i[1].type ? t(e) : n(e)
                        }, "listItemPrefixWhitespace", r.parser.constructs.disable.null.includes("codeIndented") ? void 0 : 5)
                    },
                    partial: !0
                },
                eb = {
                    tokenize: function(e, t, n) {
                        let r = this;
                        return X(e, function(e) {
                            let i = r.events[r.events.length - 1];
                            return i && "listItemIndent" === i[1].type && i[2].sliceSerialize(i[1], !0).length === r.containerState.size ? t(e) : n(e)
                        }, "listItemIndent", r.containerState.size + 1)
                    },
                    partial: !0
                },
                ex = {
                    name: "blockQuote",
                    tokenize: function(e, t, n) {
                        let r = this;
                        return function(t) {
                            if (62 === t) {
                                let o = r.containerState;
                                return o.open || (e.enter("blockQuote", {
                                    _container: !0
                                }), o.open = !0), e.enter("blockQuotePrefix"), e.enter("blockQuoteMarker"), e.consume(t), e.exit("blockQuoteMarker"), i
                            }
                            return n(t)
                        };

                        function i(n) {
                            return K(n) ? (e.enter("blockQuotePrefixWhitespace"), e.consume(n), e.exit("blockQuotePrefixWhitespace"), e.exit("blockQuotePrefix"), t) : (e.exit("blockQuotePrefix"), t(n))
                        }
                    },
                    continuation: {
                        tokenize: function(e, t, n) {
                            return X(e, e.attempt(ex, t, n), "linePrefix", this.parser.constructs.disable.null.includes("codeIndented") ? void 0 : 4)
                        }
                    },
                    exit: function(e) {
                        e.exit("blockQuote")
                    }
                };

            function ek(e, t, n, r, i, o, l, u, a) {
                let c = a || Number.POSITIVE_INFINITY,
                    s = 0;
                return function(t) {
                    return 60 === t ? (e.enter(r), e.enter(i), e.enter(o), e.consume(t), e.exit(o), f) : null === t || 41 === t || Z(t) ? n(t) : (e.enter(r), e.enter(l), e.enter(u), e.enter("chunkString", {
                        contentType: "string"
                    }), h(t))
                };

                function f(n) {
                    return 62 === n ? (e.enter(o), e.consume(n), e.exit(o), e.exit(i), e.exit(r), t) : (e.enter(u), e.enter("chunkString", {
                        contentType: "string"
                    }), d(n))
                }

                function d(t) {
                    return 62 === t ? (e.exit("chunkString"), e.exit(u), f(t)) : null === t || 60 === t || J(t) ? n(t) : (e.consume(t), 92 === t ? p : d)
                }

                function p(t) {
                    return 60 === t || 62 === t || 92 === t ? (e.consume(t), d) : d(t)
                }

                function h(i) {
                    return 40 === i ? ++s > c ? n(i) : (e.consume(i), h) : 41 === i ? s-- ? (e.consume(i), h) : (e.exit("chunkString"), e.exit(u), e.exit(l), e.exit(r), t(i)) : null === i || W(i) ? s ? n(i) : (e.exit("chunkString"), e.exit(u), e.exit(l), e.exit(r), t(i)) : Z(i) ? n(i) : (e.consume(i), 92 === i ? m : h)
                }

                function m(t) {
                    return 40 === t || 41 === t || 92 === t ? (e.consume(t), h) : h(t)
                }
            }

            function ew(e, t, n, r, i, o) {
                let l = this,
                    u = 0,
                    a;
                return function(t) {
                    return e.enter(r), e.enter(i), e.consume(t), e.exit(i), e.enter(o), c
                };

                function c(f) {
                    return null === f || 91 === f || 93 === f && !a || 94 === f && !u && "_hiddenFootnoteSupport" in l.parser.constructs || u > 999 ? n(f) : 93 === f ? (e.exit(o), e.enter(i), e.consume(f), e.exit(i), e.exit(r), t) : J(f) ? (e.enter("lineEnding"), e.consume(f), e.exit("lineEnding"), c) : (e.enter("chunkString", {
                        contentType: "string"
                    }), s(f))
                }

                function s(t) {
                    return null === t || 91 === t || 93 === t || J(t) || u++ > 999 ? (e.exit("chunkString"), c(t)) : (e.consume(t), a = a || !K(t), 92 === t ? f : s)
                }

                function f(t) {
                    return 91 === t || 92 === t || 93 === t ? (e.consume(t), u++, s) : s(t)
                }
            }

            function eE(e, t, n, r, i, o) {
                let l;
                return function(t) {
                    return e.enter(r), e.enter(i), e.consume(t), e.exit(i), l = 40 === t ? 41 : t, u
                };

                function u(n) {
                    return n === l ? (e.enter(i), e.consume(n), e.exit(i), e.exit(r), t) : (e.enter(o), a(n))
                }

                function a(t) {
                    return t === l ? (e.exit(o), u(l)) : null === t ? n(t) : J(t) ? (e.enter("lineEnding"), e.consume(t), e.exit("lineEnding"), X(e, a, "linePrefix")) : (e.enter("chunkString", {
                        contentType: "string"
                    }), c(t))
                }

                function c(t) {
                    return t === l || null === t || J(t) ? (e.exit("chunkString"), a(t)) : (e.consume(t), 92 === t ? s : c)
                }

                function s(t) {
                    return t === l || 92 === t ? (e.consume(t), c) : c(t)
                }
            }

            function eS(e, t) {
                let n;
                return r;

                function r(i) {
                    return J(i) ? (e.enter("lineEnding"), e.consume(i), e.exit("lineEnding"), n = !0, r) : K(i) ? X(e, r, n ? "linePrefix" : "lineSuffix")(i) : t(i)
                }
            }

            function eC(e) {
                return e.replace(/[\t\n\r ]+/g, " ").replace(/^ | $/g, "").toLowerCase().toUpperCase()
            }
            let eA = {
                    tokenize: function(e, t, n) {
                        return function(t) {
                            return W(t) ? eS(e, r)(t) : n(t)
                        };

                        function r(t) {
                            return 34 === t || 39 === t || 40 === t ? eE(e, X(e, i, "whitespace"), n, "definitionTitle", "definitionTitleMarker", "definitionTitleString")(t) : n(t)
                        }

                        function i(e) {
                            return null === e || J(e) ? t(e) : n(e)
                        }
                    },
                    partial: !0
                },
                eP = {
                    name: "codeIndented",
                    tokenize: function(e, t, n) {
                        let r = this;
                        return function(t) {
                            return e.enter("codeIndented"), X(e, i, "linePrefix", 5)(t)
                        };

                        function i(t) {
                            let i = r.events[r.events.length - 1];
                            return i && "linePrefix" === i[1].type && i[2].sliceSerialize(i[1], !0).length >= 4 ? function t(n) {
                                return null === n ? o(n) : J(n) ? e.attempt(eM, t, o)(n) : (e.enter("codeFlowValue"), function n(r) {
                                    return null === r || J(r) ? (e.exit("codeFlowValue"), t(r)) : (e.consume(r), n)
                                }(n))
                            }(t) : n(t)
                        }

                        function o(n) {
                            return e.exit("codeIndented"), t(n)
                        }
                    }
                },
                eM = {
                    tokenize: function(e, t, n) {
                        let r = this;
                        return i;

                        function i(t) {
                            return r.parser.lazy[r.now().line] ? n(t) : J(t) ? (e.enter("lineEnding"), e.consume(t), e.exit("lineEnding"), i) : X(e, o, "linePrefix", 5)(t)
                        }

                        function o(e) {
                            let o = r.events[r.events.length - 1];
                            return o && "linePrefix" === o[1].type && o[2].sliceSerialize(o[1], !0).length >= 4 ? t(e) : J(e) ? i(e) : n(e)
                        }
                    },
                    partial: !0
                },
                eL = {
                    name: "setextUnderline",
                    tokenize: function(e, t, n) {
                        let r = this,
                            i = r.events.length,
                            o, l;
                        for (; i--;)
                            if ("lineEnding" !== r.events[i][1].type && "linePrefix" !== r.events[i][1].type && "content" !== r.events[i][1].type) {
                                l = "paragraph" === r.events[i][1].type;
                                break
                            }
                        return function(t) {
                            return !r.parser.lazy[r.now().line] && (r.interrupt || l) ? (e.enter("setextHeadingLine"), e.enter("setextHeadingLineSequence"), o = t, function t(n) {
                                return n === o ? (e.consume(n), t) : (e.exit("setextHeadingLineSequence"), X(e, u, "lineSuffix")(n))
                            }(t)) : n(t)
                        };

                        function u(r) {
                            return null === r || J(r) ? (e.exit("setextHeadingLine"), t(r)) : n(r)
                        }
                    },
                    resolveTo: function(e, t) {
                        let n = e.length,
                            r, i, o;
                        for (; n--;)
                            if ("enter" === e[n][0]) {
                                if ("content" === e[n][1].type) {
                                    r = n;
                                    break
                                }
                                "paragraph" === e[n][1].type && (i = n)
                            } else "content" === e[n][1].type && e.splice(n, 1), o || "definition" !== e[n][1].type || (o = n);
                        let l = {
                            type: "setextHeading",
                            start: Object.assign({}, e[i][1].start),
                            end: Object.assign({}, e[e.length - 1][1].end)
                        };
                        return e[i][1].type = "setextHeadingText", o ? (e.splice(i, 0, ["enter", l, t]), e.splice(o + 1, 0, ["exit", e[r][1], t]), e[r][1].end = Object.assign({}, e[o][1].end)) : e[r][1] = l, e.push(["exit", l, t]), e
                    }
                },
                eT = ["address", "article", "aside", "base", "basefont", "blockquote", "body", "caption", "center", "col", "colgroup", "dd", "details", "dialog", "dir", "div", "dl", "dt", "fieldset", "figcaption", "figure", "footer", "form", "frame", "frameset", "h1", "h2", "h3", "h4", "h5", "h6", "head", "header", "hr", "html", "iframe", "legend", "li", "link", "main", "menu", "menuitem", "nav", "noframes", "ol", "optgroup", "option", "p", "param", "section", "summary", "table", "tbody", "td", "tfoot", "th", "thead", "title", "tr", "track", "ul"],
                eO = ["pre", "script", "style", "textarea"],
                eF = {
                    tokenize: function(e, t, n) {
                        return function(r) {
                            return e.exit("htmlFlowData"), e.enter("lineEndingBlank"), e.consume(r), e.exit("lineEndingBlank"), e.attempt(er, t, n)
                        }
                    },
                    partial: !0
                },
                eI = {
                    name: "codeFenced",
                    tokenize: function(e, t, n) {
                        let r = this,
                            i = {
                                tokenize: function(e, t, n) {
                                    let r = 0;
                                    return X(e, function(t) {
                                        return e.enter("codeFencedFence"), e.enter("codeFencedFenceSequence"),
                                            function t(o) {
                                                return o === c ? (e.consume(o), r++, t) : r < a ? n(o) : (e.exit("codeFencedFenceSequence"), X(e, i, "whitespace")(o))
                                            }(t)
                                    }, "linePrefix", this.parser.constructs.disable.null.includes("codeIndented") ? void 0 : 4);

                                    function i(r) {
                                        return null === r || J(r) ? (e.exit("codeFencedFence"), t(r)) : n(r)
                                    }
                                },
                                partial: !0
                            },
                            o = {
                                tokenize: function(e, t, n) {
                                    let r = this;
                                    return function(t) {
                                        return e.enter("lineEnding"), e.consume(t), e.exit("lineEnding"), i
                                    };

                                    function i(e) {
                                        return r.parser.lazy[r.now().line] ? n(e) : t(e)
                                    }
                                },
                                partial: !0
                            },
                            l = this.events[this.events.length - 1],
                            u = l && "linePrefix" === l[1].type ? l[2].sliceSerialize(l[1], !0).length : 0,
                            a = 0,
                            c;
                        return function(t) {
                            return e.enter("codeFenced"), e.enter("codeFencedFence"), e.enter("codeFencedFenceSequence"), c = t,
                                function t(r) {
                                    return r === c ? (e.consume(r), a++, t) : (e.exit("codeFencedFenceSequence"), a < 3 ? n(r) : X(e, s, "whitespace")(r))
                                }(t)
                        };

                        function s(t) {
                            return null === t || J(t) ? d(t) : (e.enter("codeFencedFenceInfo"), e.enter("chunkString", {
                                contentType: "string"
                            }), function t(r) {
                                return null === r || W(r) ? (e.exit("chunkString"), e.exit("codeFencedFenceInfo"), X(e, f, "whitespace")(r)) : 96 === r && r === c ? n(r) : (e.consume(r), t)
                            }(t))
                        }

                        function f(t) {
                            return null === t || J(t) ? d(t) : (e.enter("codeFencedFenceMeta"), e.enter("chunkString", {
                                contentType: "string"
                            }), function t(r) {
                                return null === r || J(r) ? (e.exit("chunkString"), e.exit("codeFencedFenceMeta"), d(r)) : 96 === r && r === c ? n(r) : (e.consume(r), t)
                            }(t))
                        }

                        function d(n) {
                            return e.exit("codeFencedFence"), r.interrupt ? t(n) : function t(n) {
                                return null === n ? p(n) : J(n) ? e.attempt(o, e.attempt(i, p, u ? X(e, t, "linePrefix", u + 1) : t), p)(n) : (e.enter("codeFlowValue"), function n(r) {
                                    return null === r || J(r) ? (e.exit("codeFlowValue"), t(r)) : (e.consume(r), n)
                                }(n))
                            }(n)
                        }

                        function p(n) {
                            return e.exit("codeFenced"), t(n)
                        }
                    },
                    concrete: !0
                },
                ej = document.createElement("i");

            function eD(e) {
                let t = "&" + e + ";";
                ej.innerHTML = t;
                let n = ej.textContent;
                return (59 !== n.charCodeAt(n.length - 1) || "semi" === e) && n !== t && n
            }
            let ez = {
                    name: "characterReference",
                    tokenize: function(e, t, n) {
                        let r = this,
                            i = 0,
                            o, l;
                        return function(t) {
                            return e.enter("characterReference"), e.enter("characterReferenceMarker"), e.consume(t), e.exit("characterReferenceMarker"), u
                        };

                        function u(t) {
                            return 35 === t ? (e.enter("characterReferenceMarkerNumeric"), e.consume(t), e.exit("characterReferenceMarkerNumeric"), a) : (e.enter("characterReferenceValue"), o = 31, l = q, c(t))
                        }

                        function a(t) {
                            return 88 === t || 120 === t ? (e.enter("characterReferenceMarkerHexadecimal"), e.consume(t), e.exit("characterReferenceMarkerHexadecimal"), e.enter("characterReferenceValue"), o = 6, l = H, c) : (e.enter("characterReferenceValue"), o = 7, l = $, c(t))
                        }

                        function c(u) {
                            let a;
                            return 59 === u && i ? (a = e.exit("characterReferenceValue"), l !== q || eD(r.sliceSerialize(a))) ? (e.enter("characterReferenceMarker"), e.consume(u), e.exit("characterReferenceMarker"), e.exit("characterReference"), t) : n(u) : l(u) && i++ < o ? (e.consume(u), c) : n(u)
                        }
                    }
                },
                eR = {
                    name: "characterEscape",
                    tokenize: function(e, t, n) {
                        return function(t) {
                            return e.enter("characterEscape"), e.enter("escapeMarker"), e.consume(t), e.exit("escapeMarker"), r
                        };

                        function r(r) {
                            return V(r) ? (e.enter("characterEscapeValue"), e.consume(r), e.exit("characterEscapeValue"), e.exit("characterEscape"), t) : n(r)
                        }
                    }
                },
                eN = {
                    name: "lineEnding",
                    tokenize: function(e, t) {
                        return function(n) {
                            return e.enter("lineEnding"), e.consume(n), e.exit("lineEnding"), X(e, t, "linePrefix")
                        }
                    }
                },
                eB = {
                    name: "labelEnd",
                    tokenize: function(e, t, n) {
                        let r = this,
                            i = r.events.length,
                            o, l;
                        for (; i--;)
                            if (("labelImage" === r.events[i][1].type || "labelLink" === r.events[i][1].type) && !r.events[i][1]._balanced) {
                                o = r.events[i][1];
                                break
                            }
                        return function(t) {
                            return o ? o._inactive ? a(t) : (l = r.parser.defined.includes(eC(r.sliceSerialize({
                                start: o.end,
                                end: r.now()
                            }))), e.enter("labelEnd"), e.enter("labelMarker"), e.consume(t), e.exit("labelMarker"), e.exit("labelEnd"), u) : n(t)
                        };

                        function u(n) {
                            return 40 === n ? e.attempt(e_, t, l ? t : a)(n) : 91 === n ? e.attempt(e$, t, l ? e.attempt(eH, t, a) : a)(n) : l ? t(n) : a(n)
                        }

                        function a(e) {
                            return o._balanced = !0, n(e)
                        }
                    },
                    resolveTo: function(e, t) {
                        let n = e.length,
                            r = 0,
                            i, o, l, u;
                        for (; n--;)
                            if (i = e[n][1], o) {
                                if ("link" === i.type || "labelLink" === i.type && i._inactive) break;
                                "enter" === e[n][0] && "labelLink" === i.type && (i._inactive = !0)
                            } else if (l) {
                            if ("enter" === e[n][0] && ("labelImage" === i.type || "labelLink" === i.type) && !i._balanced && (o = n, "labelLink" !== i.type)) {
                                r = 2;
                                break
                            }
                        } else "labelEnd" === i.type && (l = n);
                        let a = {
                                type: "labelLink" === e[o][1].type ? "link" : "image",
                                start: Object.assign({}, e[o][1].start),
                                end: Object.assign({}, e[e.length - 1][1].end)
                            },
                            c = {
                                type: "label",
                                start: Object.assign({}, e[o][1].start),
                                end: Object.assign({}, e[l][1].end)
                            },
                            s = {
                                type: "labelText",
                                start: Object.assign({}, e[o + r + 2][1].end),
                                end: Object.assign({}, e[l - 2][1].start)
                            };
                        return u = z(u = [
                            ["enter", a, t],
                            ["enter", c, t]
                        ], e.slice(o + 1, o + r + 3)), u = z(u, [
                            ["enter", s, t]
                        ]), u = z(u, em(t.parser.constructs.insideSpan.null, e.slice(o + r + 4, l - 3), t)), u = z(u, [
                            ["exit", s, t], e[l - 2], e[l - 1],
                            ["exit", c, t]
                        ]), u = z(u, e.slice(l + 1)), u = z(u, [
                            ["exit", a, t]
                        ]), D(e, o, e.length, u), e
                    },
                    resolveAll: function(e) {
                        let t = -1,
                            n;
                        for (; ++t < e.length;)("labelImage" === (n = e[t][1]).type || "labelLink" === n.type || "labelEnd" === n.type) && (e.splice(t + 1, "labelImage" === n.type ? 4 : 2), n.type = "data", t++);
                        return e
                    }
                },
                e_ = {
                    tokenize: function(e, t, n) {
                        return function(t) {
                            return e.enter("resource"), e.enter("resourceMarker"), e.consume(t), e.exit("resourceMarker"), eS(e, r)
                        };

                        function r(t) {
                            return 41 === t ? l(t) : ek(e, i, n, "resourceDestination", "resourceDestinationLiteral", "resourceDestinationLiteralMarker", "resourceDestinationRaw", "resourceDestinationString", 32)(t)
                        }

                        function i(t) {
                            return W(t) ? eS(e, o)(t) : l(t)
                        }

                        function o(t) {
                            return 34 === t || 39 === t || 40 === t ? eE(e, eS(e, l), n, "resourceTitle", "resourceTitleMarker", "resourceTitleString")(t) : l(t)
                        }

                        function l(r) {
                            return 41 === r ? (e.enter("resourceMarker"), e.consume(r), e.exit("resourceMarker"), e.exit("resource"), t) : n(r)
                        }
                    }
                },
                e$ = {
                    tokenize: function(e, t, n) {
                        let r = this;
                        return function(t) {
                            return ew.call(r, e, i, n, "reference", "referenceMarker", "referenceString")(t)
                        };

                        function i(e) {
                            return r.parser.defined.includes(eC(r.sliceSerialize(r.events[r.events.length - 1][1]).slice(1, -1))) ? t(e) : n(e)
                        }
                    }
                },
                eH = {
                    tokenize: function(e, t, n) {
                        return function(t) {
                            return e.enter("reference"), e.enter("referenceMarker"), e.consume(t), e.exit("referenceMarker"), r
                        };

                        function r(r) {
                            return 93 === r ? (e.enter("referenceMarker"), e.consume(r), e.exit("referenceMarker"), e.exit("reference"), t) : n(r)
                        }
                    }
                },
                eq = {
                    name: "labelStartImage",
                    tokenize: function(e, t, n) {
                        let r = this;
                        return function(t) {
                            return e.enter("labelImage"), e.enter("labelImageMarker"), e.consume(t), e.exit("labelImageMarker"), i
                        };

                        function i(t) {
                            return 91 === t ? (e.enter("labelMarker"), e.consume(t), e.exit("labelMarker"), e.exit("labelImage"), o) : n(t)
                        }

                        function o(e) {
                            return 94 === e && "_hiddenFootnoteSupport" in r.parser.constructs ? n(e) : t(e)
                        }
                    },
                    resolveAll: eB.resolveAll
                };

            function eV(e) {
                return null === e || W(e) || G(e) ? 1 : Q(e) ? 2 : void 0
            }
            let eU = {
                name: "attention",
                tokenize: function(e, t) {
                    let n = this.parser.constructs.attentionMarkers.null,
                        r = this.previous,
                        i = eV(r),
                        o;
                    return function(l) {
                        return e.enter("attentionSequence"), o = l,
                            function l(u) {
                                if (u === o) return e.consume(u), l;
                                let a = e.exit("attentionSequence"),
                                    c = eV(u),
                                    s = !c || 2 === c && i || n.includes(u),
                                    f = !i || 2 === i && c || n.includes(r);
                                return a._open = Boolean(42 === o ? s : s && (i || !f)), a._close = Boolean(42 === o ? f : f && (c || !s)), t(u)
                            }(l)
                    }
                },
                resolveAll: function(e, t) {
                    let n = -1,
                        r, i, o, l, u, a, c, s;
                    for (; ++n < e.length;)
                        if ("enter" === e[n][0] && "attentionSequence" === e[n][1].type && e[n][1]._close) {
                            for (r = n; r--;)
                                if ("exit" === e[r][0] && "attentionSequence" === e[r][1].type && e[r][1]._open && t.sliceSerialize(e[r][1]).charCodeAt(0) === t.sliceSerialize(e[n][1]).charCodeAt(0)) {
                                    if ((e[r][1]._close || e[n][1]._open) && (e[n][1].end.offset - e[n][1].start.offset) % 3 && !((e[r][1].end.offset - e[r][1].start.offset + e[n][1].end.offset - e[n][1].start.offset) % 3)) continue;
                                    a = e[r][1].end.offset - e[r][1].start.offset > 1 && e[n][1].end.offset - e[n][1].start.offset > 1 ? 2 : 1;
                                    let f = Object.assign({}, e[r][1].end),
                                        d = Object.assign({}, e[n][1].start);
                                    eZ(f, -a), eZ(d, a), l = {
                                        type: a > 1 ? "strongSequence" : "emphasisSequence",
                                        start: f,
                                        end: Object.assign({}, e[r][1].end)
                                    }, u = {
                                        type: a > 1 ? "strongSequence" : "emphasisSequence",
                                        start: Object.assign({}, e[n][1].start),
                                        end: d
                                    }, o = {
                                        type: a > 1 ? "strongText" : "emphasisText",
                                        start: Object.assign({}, e[r][1].end),
                                        end: Object.assign({}, e[n][1].start)
                                    }, i = {
                                        type: a > 1 ? "strong" : "emphasis",
                                        start: Object.assign({}, l.start),
                                        end: Object.assign({}, u.end)
                                    }, e[r][1].end = Object.assign({}, l.start), e[n][1].start = Object.assign({}, u.end), c = [], e[r][1].end.offset - e[r][1].start.offset && (c = z(c, [
                                        ["enter", e[r][1], t],
                                        ["exit", e[r][1], t]
                                    ])), c = z(c, [
                                        ["enter", i, t],
                                        ["enter", l, t],
                                        ["exit", l, t],
                                        ["enter", o, t]
                                    ]), c = z(c, em(t.parser.constructs.insideSpan.null, e.slice(r + 1, n), t)), c = z(c, [
                                        ["exit", o, t],
                                        ["enter", u, t],
                                        ["exit", u, t],
                                        ["exit", i, t]
                                    ]), e[n][1].end.offset - e[n][1].start.offset ? (s = 2, c = z(c, [
                                        ["enter", e[n][1], t],
                                        ["exit", e[n][1], t]
                                    ])) : s = 0, D(e, r - 1, n - r + 3, c), n = r + c.length - s - 2;
                                    break
                                }
                        }
                    for (n = -1; ++n < e.length;) "attentionSequence" === e[n][1].type && (e[n][1].type = "data");
                    return e
                }
            };

            function eZ(e, t) {
                e.column += t, e.offset += t, e._bufferIndex += t
            }
            let eW = {
                    name: "labelStartLink",
                    tokenize: function(e, t, n) {
                        let r = this;
                        return function(t) {
                            return e.enter("labelLink"), e.enter("labelMarker"), e.consume(t), e.exit("labelMarker"), e.exit("labelLink"), i
                        };

                        function i(e) {
                            return 94 === e && "_hiddenFootnoteSupport" in r.parser.constructs ? n(e) : t(e)
                        }
                    },
                    resolveAll: eB.resolveAll
                },
                eJ = {
                    42: ey,
                    43: ey,
                    45: ey,
                    48: ey,
                    49: ey,
                    50: ey,
                    51: ey,
                    52: ey,
                    53: ey,
                    54: ey,
                    55: ey,
                    56: ey,
                    57: ey,
                    62: ex
                },
                eK = {
                    91: {
                        name: "definition",
                        tokenize: function(e, t, n) {
                            let r = this,
                                i;
                            return function(t) {
                                return e.enter("definition"), ew.call(r, e, o, n, "definitionLabel", "definitionLabelMarker", "definitionLabelString")(t)
                            };

                            function o(t) {
                                return (i = eC(r.sliceSerialize(r.events[r.events.length - 1][1]).slice(1, -1)), 58 === t) ? (e.enter("definitionMarker"), e.consume(t), e.exit("definitionMarker"), eS(e, ek(e, e.attempt(eA, X(e, l, "whitespace"), X(e, l, "whitespace")), n, "definitionDestination", "definitionDestinationLiteral", "definitionDestinationLiteralMarker", "definitionDestinationRaw", "definitionDestinationString"))) : n(t)
                            }

                            function l(o) {
                                return null === o || J(o) ? (e.exit("definition"), r.parser.defined.includes(i) || r.parser.defined.push(i), t(o)) : n(o)
                            }
                        }
                    }
                },
                eG = {
                    [-2]: eP,
                    [-1]: eP,
                    32: eP
                },
                eQ = {
                    35: {
                        name: "headingAtx",
                        tokenize: function(e, t, n) {
                            let r = this,
                                i = 0;
                            return function(o) {
                                return e.enter("atxHeading"), e.enter("atxHeadingSequence"),
                                    function o(l) {
                                        return 35 === l && i++ < 6 ? (e.consume(l), o) : null === l || W(l) ? (e.exit("atxHeadingSequence"), r.interrupt ? t(l) : function n(r) {
                                            return 35 === r ? (e.enter("atxHeadingSequence"), function t(r) {
                                                return 35 === r ? (e.consume(r), t) : (e.exit("atxHeadingSequence"), n(r))
                                            }(r)) : null === r || J(r) ? (e.exit("atxHeading"), t(r)) : K(r) ? X(e, n, "whitespace")(r) : (e.enter("atxHeadingText"), function t(r) {
                                                return null === r || 35 === r || W(r) ? (e.exit("atxHeadingText"), n(r)) : (e.consume(r), t)
                                            }(r))
                                        }(l)) : n(l)
                                    }(o)
                            }
                        },
                        resolve: function(e, t) {
                            let n = e.length - 2,
                                r = 3,
                                i, o;
                            return "whitespace" === e[r][1].type && (r += 2), n - 2 > r && "whitespace" === e[n][1].type && (n -= 2), "atxHeadingSequence" === e[n][1].type && (r === n - 1 || n - 4 > r && "whitespace" === e[n - 2][1].type) && (n -= r + 1 === n ? 2 : 4), n > r && (i = {
                                type: "atxHeadingText",
                                start: e[r][1].start,
                                end: e[n][1].end
                            }, o = {
                                type: "chunkText",
                                start: e[r][1].start,
                                end: e[n][1].end,
                                contentType: "text"
                            }, D(e, r, n - r + 1, [
                                ["enter", i, t],
                                ["enter", o, t],
                                ["exit", o, t],
                                ["exit", i, t]
                            ])), e
                        }
                    },
                    42: eg,
                    45: [eL, eg],
                    60: {
                        name: "htmlFlow",
                        tokenize: function(e, t, n) {
                            let r = this,
                                i, o, l, u, a;
                            return function(t) {
                                return e.enter("htmlFlow"), e.enter("htmlFlowData"), e.consume(t), c
                            };

                            function c(u) {
                                return 33 === u ? (e.consume(u), s) : 47 === u ? (e.consume(u), p) : 63 === u ? (e.consume(u), i = 3, r.interrupt ? t : O) : _(u) ? (e.consume(u), l = String.fromCharCode(u), o = !0, h) : n(u)
                            }

                            function s(o) {
                                return 45 === o ? (e.consume(o), i = 2, f) : 91 === o ? (e.consume(o), i = 5, l = "CDATA[", u = 0, d) : _(o) ? (e.consume(o), i = 4, r.interrupt ? t : O) : n(o)
                            }

                            function f(i) {
                                return 45 === i ? (e.consume(i), r.interrupt ? t : O) : n(i)
                            }

                            function d(i) {
                                return i === l.charCodeAt(u++) ? (e.consume(i), u === l.length ? r.interrupt ? t : S : d) : n(i)
                            }

                            function p(t) {
                                return _(t) ? (e.consume(t), l = String.fromCharCode(t), h) : n(t)
                            }

                            function h(u) {
                                if (null === u || 47 === u || 62 === u || W(u)) return 47 !== u && o && eO.includes(l.toLowerCase()) ? (i = 1, r.interrupt ? t(u) : S(u)) : eT.includes(l.toLowerCase()) ? (i = 6, 47 === u) ? (e.consume(u), m) : r.interrupt ? t(u) : S(u) : (i = 7, r.interrupt && !r.parser.lazy[r.now().line] ? n(u) : o ? g(u) : function t(n) {
                                    return K(n) ? (e.consume(n), t) : w(n)
                                }(u));
                                return 45 === u || q(u) ? (e.consume(u), l += String.fromCharCode(u), h) : n(u)
                            }

                            function m(i) {
                                return 62 === i ? (e.consume(i), r.interrupt ? t : S) : n(i)
                            }

                            function g(t) {
                                return 47 === t ? (e.consume(t), w) : 58 === t || 95 === t || _(t) ? (e.consume(t), y) : K(t) ? (e.consume(t), g) : w(t)
                            }

                            function y(t) {
                                return 45 === t || 46 === t || 58 === t || 95 === t || q(t) ? (e.consume(t), y) : v(t)
                            }

                            function v(t) {
                                return 61 === t ? (e.consume(t), b) : K(t) ? (e.consume(t), v) : g(t)
                            }

                            function b(t) {
                                return null === t || 60 === t || 61 === t || 62 === t || 96 === t ? n(t) : 34 === t || 39 === t ? (e.consume(t), a = t, x) : K(t) ? (e.consume(t), b) : (a = null, function t(n) {
                                    return null === n || 34 === n || 39 === n || 60 === n || 61 === n || 62 === n || 96 === n || W(n) ? v(n) : (e.consume(n), t)
                                }(t))
                            }

                            function x(t) {
                                return null === t || J(t) ? n(t) : t === a ? (e.consume(t), k) : (e.consume(t), x)
                            }

                            function k(e) {
                                return 47 === e || 62 === e || K(e) ? g(e) : n(e)
                            }

                            function w(t) {
                                return 62 === t ? (e.consume(t), E) : n(t)
                            }

                            function E(t) {
                                return K(t) ? (e.consume(t), E) : null === t || J(t) ? S(t) : n(t)
                            }

                            function S(t) {
                                return 45 === t && 2 === i ? (e.consume(t), P) : 60 === t && 1 === i ? (e.consume(t), M) : 62 === t && 4 === i ? (e.consume(t), F) : 63 === t && 3 === i ? (e.consume(t), O) : 93 === t && 5 === i ? (e.consume(t), T) : J(t) && (6 === i || 7 === i) ? e.check(eF, F, C)(t) : null === t || J(t) ? C(t) : (e.consume(t), S)
                            }

                            function C(t) {
                                return e.exit("htmlFlowData"),
                                    function t(n) {
                                        return null === n ? I(n) : J(n) ? e.attempt({
                                            tokenize: A,
                                            partial: !0
                                        }, t, I)(n) : (e.enter("htmlFlowData"), S(n))
                                    }(t)
                            }

                            function A(e, t, n) {
                                return function(t) {
                                    return e.enter("lineEnding"), e.consume(t), e.exit("lineEnding"), i
                                };

                                function i(e) {
                                    return r.parser.lazy[r.now().line] ? n(e) : t(e)
                                }
                            }

                            function P(t) {
                                return 45 === t ? (e.consume(t), O) : S(t)
                            }

                            function M(t) {
                                return 47 === t ? (e.consume(t), l = "", L) : S(t)
                            }

                            function L(t) {
                                return 62 === t && eO.includes(l.toLowerCase()) ? (e.consume(t), F) : _(t) && l.length < 8 ? (e.consume(t), l += String.fromCharCode(t), L) : S(t)
                            }

                            function T(t) {
                                return 93 === t ? (e.consume(t), O) : S(t)
                            }

                            function O(t) {
                                return 62 === t ? (e.consume(t), F) : 45 === t && 2 === i ? (e.consume(t), O) : S(t)
                            }

                            function F(t) {
                                return null === t || J(t) ? (e.exit("htmlFlowData"), I(t)) : (e.consume(t), F)
                            }

                            function I(n) {
                                return e.exit("htmlFlow"), t(n)
                            }
                        },
                        resolveTo: function(e) {
                            let t = e.length;
                            for (; t-- && ("enter" !== e[t][0] || "htmlFlow" !== e[t][1].type););
                            return t > 1 && "linePrefix" === e[t - 2][1].type && (e[t][1].start = e[t - 2][1].start, e[t + 1][1].start = e[t - 2][1].start, e.splice(t - 2, 2)), e
                        },
                        concrete: !0
                    },
                    61: eL,
                    95: eg,
                    96: eI,
                    126: eI
                },
                eY = {
                    38: ez,
                    92: eR
                },
                eX = {
                    [-5]: eN,
                    [-4]: eN,
                    [-3]: eN,
                    33: eq,
                    38: ez,
                    42: eU,
                    60: [{
                        name: "autolink",
                        tokenize: function(e, t, n) {
                            let r = 1;
                            return function(t) {
                                return e.enter("autolink"), e.enter("autolinkMarker"), e.consume(t), e.exit("autolinkMarker"), e.enter("autolinkProtocol"), i
                            };

                            function i(t) {
                                return _(t) ? (e.consume(t), o) : U(t) ? u(t) : n(t)
                            }

                            function o(t) {
                                return 43 === t || 45 === t || 46 === t || q(t) ? function t(n) {
                                    return 58 === n ? (e.consume(n), l) : (43 === n || 45 === n || 46 === n || q(n)) && r++ < 32 ? (e.consume(n), t) : u(n)
                                }(t) : u(t)
                            }

                            function l(t) {
                                return 62 === t ? (e.exit("autolinkProtocol"), c(t)) : null === t || 32 === t || 60 === t || Z(t) ? n(t) : (e.consume(t), l)
                            }

                            function u(t) {
                                return 64 === t ? (e.consume(t), r = 0, a) : U(t) ? (e.consume(t), u) : n(t)
                            }

                            function a(t) {
                                return q(t) ? function t(i) {
                                    return 46 === i ? (e.consume(i), r = 0, a) : 62 === i ? (e.exit("autolinkProtocol").type = "autolinkEmail", c(i)) : function i(o) {
                                        return (45 === o || q(o)) && r++ < 63 ? (e.consume(o), 45 === o ? i : t) : n(o)
                                    }(i)
                                }(t) : n(t)
                            }

                            function c(n) {
                                return e.enter("autolinkMarker"), e.consume(n), e.exit("autolinkMarker"), e.exit("autolink"), t
                            }
                        }
                    }, {
                        name: "htmlText",
                        tokenize: function(e, t, n) {
                            let r = this,
                                i, o, l, u;
                            return function(t) {
                                return e.enter("htmlText"), e.enter("htmlTextData"), e.consume(t), a
                            };

                            function a(t) {
                                return 33 === t ? (e.consume(t), c) : 47 === t ? (e.consume(t), w) : 63 === t ? (e.consume(t), x) : _(t) ? (e.consume(t), S) : n(t)
                            }

                            function c(t) {
                                return 45 === t ? (e.consume(t), s) : 91 === t ? (e.consume(t), o = "CDATA[", l = 0, m) : _(t) ? (e.consume(t), b) : n(t)
                            }

                            function s(t) {
                                return 45 === t ? (e.consume(t), f) : n(t)
                            }

                            function f(t) {
                                return null === t || 62 === t ? n(t) : 45 === t ? (e.consume(t), d) : p(t)
                            }

                            function d(e) {
                                return null === e || 62 === e ? n(e) : p(e)
                            }

                            function p(t) {
                                return null === t ? n(t) : 45 === t ? (e.consume(t), h) : J(t) ? (u = p, O(t)) : (e.consume(t), p)
                            }

                            function h(t) {
                                return 45 === t ? (e.consume(t), I) : p(t)
                            }

                            function m(t) {
                                return t === o.charCodeAt(l++) ? (e.consume(t), l === o.length ? g : m) : n(t)
                            }

                            function g(t) {
                                return null === t ? n(t) : 93 === t ? (e.consume(t), y) : J(t) ? (u = g, O(t)) : (e.consume(t), g)
                            }

                            function y(t) {
                                return 93 === t ? (e.consume(t), v) : g(t)
                            }

                            function v(t) {
                                return 62 === t ? I(t) : 93 === t ? (e.consume(t), v) : g(t)
                            }

                            function b(t) {
                                return null === t || 62 === t ? I(t) : J(t) ? (u = b, O(t)) : (e.consume(t), b)
                            }

                            function x(t) {
                                return null === t ? n(t) : 63 === t ? (e.consume(t), k) : J(t) ? (u = x, O(t)) : (e.consume(t), x)
                            }

                            function k(e) {
                                return 62 === e ? I(e) : x(e)
                            }

                            function w(t) {
                                return _(t) ? (e.consume(t), E) : n(t)
                            }

                            function E(t) {
                                return 45 === t || q(t) ? (e.consume(t), E) : function t(n) {
                                    return J(n) ? (u = t, O(n)) : K(n) ? (e.consume(n), t) : I(n)
                                }(t)
                            }

                            function S(t) {
                                return 45 === t || q(t) ? (e.consume(t), S) : 47 === t || 62 === t || W(t) ? C(t) : n(t)
                            }

                            function C(t) {
                                return 47 === t ? (e.consume(t), I) : 58 === t || 95 === t || _(t) ? (e.consume(t), A) : J(t) ? (u = C, O(t)) : K(t) ? (e.consume(t), C) : I(t)
                            }

                            function A(t) {
                                return 45 === t || 46 === t || 58 === t || 95 === t || q(t) ? (e.consume(t), A) : function t(n) {
                                    return 61 === n ? (e.consume(n), P) : J(n) ? (u = t, O(n)) : K(n) ? (e.consume(n), t) : C(n)
                                }(t)
                            }

                            function P(t) {
                                return null === t || 60 === t || 61 === t || 62 === t || 96 === t ? n(t) : 34 === t || 39 === t ? (e.consume(t), i = t, M) : J(t) ? (u = P, O(t)) : K(t) ? (e.consume(t), P) : (e.consume(t), i = void 0, T)
                            }

                            function M(t) {
                                return t === i ? (e.consume(t), L) : null === t ? n(t) : J(t) ? (u = M, O(t)) : (e.consume(t), M)
                            }

                            function L(e) {
                                return 62 === e || 47 === e || W(e) ? C(e) : n(e)
                            }

                            function T(t) {
                                return null === t || 34 === t || 39 === t || 60 === t || 61 === t || 96 === t ? n(t) : 62 === t || W(t) ? C(t) : (e.consume(t), T)
                            }

                            function O(t) {
                                return e.exit("htmlTextData"), e.enter("lineEnding"), e.consume(t), e.exit("lineEnding"), X(e, F, "linePrefix", r.parser.constructs.disable.null.includes("codeIndented") ? void 0 : 4)
                            }

                            function F(t) {
                                return e.enter("htmlTextData"), u(t)
                            }

                            function I(r) {
                                return 62 === r ? (e.consume(r), e.exit("htmlTextData"), e.exit("htmlText"), t) : n(r)
                            }
                        }
                    }],
                    91: eW,
                    92: [{
                        name: "hardBreakEscape",
                        tokenize: function(e, t, n) {
                            return function(t) {
                                return e.enter("hardBreakEscape"), e.enter("escapeMarker"), e.consume(t), r
                            };

                            function r(r) {
                                return J(r) ? (e.exit("escapeMarker"), e.exit("hardBreakEscape"), t(r)) : n(r)
                            }
                        }
                    }, eR],
                    93: eB,
                    95: eU,
                    96: {
                        name: "codeText",
                        tokenize: function(e, t, n) {
                            let r = 0,
                                i, o;
                            return function(t) {
                                return e.enter("codeText"), e.enter("codeTextSequence"),
                                    function t(n) {
                                        return 96 === n ? (e.consume(n), r++, t) : (e.exit("codeTextSequence"), l(n))
                                    }(t)
                            };

                            function l(a) {
                                return null === a ? n(a) : 96 === a ? (o = e.enter("codeTextSequence"), i = 0, function n(l) {
                                    return 96 === l ? (e.consume(l), i++, n) : i === r ? (e.exit("codeTextSequence"), e.exit("codeText"), t(l)) : (o.type = "codeTextData", u(l))
                                }(a)) : 32 === a ? (e.enter("space"), e.consume(a), e.exit("space"), l) : J(a) ? (e.enter("lineEnding"), e.consume(a), e.exit("lineEnding"), l) : (e.enter("codeTextData"), u(a))
                            }

                            function u(t) {
                                return null === t || 32 === t || 96 === t || J(t) ? (e.exit("codeTextData"), l(t)) : (e.consume(t), u)
                            }
                        },
                        resolve: function(e) {
                            let t = e.length - 4,
                                n = 3,
                                r, i;
                            if (("lineEnding" === e[n][1].type || "space" === e[n][1].type) && ("lineEnding" === e[t][1].type || "space" === e[t][1].type)) {
                                for (r = n; ++r < t;)
                                    if ("codeTextData" === e[r][1].type) {
                                        e[n][1].type = "codeTextPadding", e[t][1].type = "codeTextPadding", n += 2, t -= 2;
                                        break
                                    }
                            }
                            for (r = n - 1, t++; ++r <= t;) void 0 === i ? r !== t && "lineEnding" !== e[r][1].type && (i = r) : (r === t || "lineEnding" === e[r][1].type) && (e[i][1].type = "codeTextData", r !== i + 2 && (e[i][1].end = e[r - 1][1].end, e.splice(i + 2, r - i - 2), t -= r - i - 2, r = i + 2), i = void 0);
                            return e
                        },
                        previous: function(e) {
                            return 96 !== e || "characterEscape" === this.events[this.events.length - 1][1].type
                        }
                    }
                },
                e0 = {
                    null: [eU, ec]
                },
                e1 = {
                    null: [42, 95]
                },
                e6 = {
                    null: []
                },
                e3 = /[\0\t\n\r]/g;

            function e2(e, t) {
                let n = Number.parseInt(e, t);
                return n < 9 || 11 === n || n > 13 && n < 32 || n > 126 && n < 160 || n > 55295 && n < 57344 || n > 64975 && n < 65008 || (65535 & n) == 65535 || (65535 & n) == 65534 || n > 1114111 ? "�" : String.fromCharCode(n)
            }
            let e9 = /\\([!-/:-@[-`{-~])|&(#(?:\d{1,7}|x[\da-f]{1,6})|[\da-z]{1,31});/gi;

            function e4(e, t, n) {
                if (t) return t;
                let r = n.charCodeAt(0);
                if (35 === r) {
                    let i = n.charCodeAt(1),
                        o = 120 === i || 88 === i;
                    return e2(n.slice(o ? 2 : 1), o ? 16 : 10)
                }
                return eD(n) || e
            }
            let e5 = {}.hasOwnProperty,
                e7 = function(e, t, n) {
                    "string" != typeof t && (n = t, t = void 0);
                    let i, o, l, a;
                    return (function(e = {}) {
                        let t = function e(t, n) {
                                let r = -1;
                                for (; ++r < n.length;) {
                                    let i = n[r];
                                    Array.isArray(i) ? e(t, i) : e8(t, i)
                                }
                                return t
                            }({
                                transforms: [],
                                canContainEols: ["emphasis", "fragment", "heading", "paragraph", "strong"],
                                enter: {
                                    autolink: a(w),
                                    autolinkProtocol: h,
                                    autolinkEmail: h,
                                    atxHeading: a(b),
                                    blockQuote: a(function() {
                                        return {
                                            type: "blockquote",
                                            children: []
                                        }
                                    }),
                                    characterEscape: h,
                                    characterReference: h,
                                    codeFenced: a(v),
                                    codeFencedFenceInfo: c,
                                    codeFencedFenceMeta: c,
                                    codeIndented: a(v, c),
                                    codeText: a(function() {
                                        return {
                                            type: "inlineCode",
                                            value: ""
                                        }
                                    }, c),
                                    codeTextData: h,
                                    data: h,
                                    codeFlowValue: h,
                                    definition: a(function() {
                                        return {
                                            type: "definition",
                                            identifier: "",
                                            label: null,
                                            title: null,
                                            url: ""
                                        }
                                    }),
                                    definitionDestinationString: c,
                                    definitionLabelString: c,
                                    definitionTitleString: c,
                                    emphasis: a(function() {
                                        return {
                                            type: "emphasis",
                                            children: []
                                        }
                                    }),
                                    hardBreakEscape: a(x),
                                    hardBreakTrailing: a(x),
                                    htmlFlow: a(k, c),
                                    htmlFlowData: h,
                                    htmlText: a(k, c),
                                    htmlTextData: h,
                                    image: a(function() {
                                        return {
                                            type: "image",
                                            title: null,
                                            url: "",
                                            alt: null
                                        }
                                    }),
                                    label: c,
                                    link: a(w),
                                    listItem: a(function(e) {
                                        return {
                                            type: "listItem",
                                            spread: e._spread,
                                            checked: null,
                                            children: []
                                        }
                                    }),
                                    listItemValue: function(e) {
                                        var t, r;
                                        if (n.expectingFirstListItemValue) {
                                            let i = this.stack[this.stack.length - 2];
                                            i.start = Number.parseInt(this.sliceSerialize(e), 10), n[r = "expectingFirstListItemValue"] = void 0
                                        }
                                    },
                                    listOrdered: a(E, function() {
                                        var e, t;
                                        n.expectingFirstListItemValue = !0
                                    }),
                                    listUnordered: a(E),
                                    paragraph: a(function() {
                                        return {
                                            type: "paragraph",
                                            children: []
                                        }
                                    }),
                                    reference: function() {
                                        var e, t;
                                        n.referenceType = "collapsed"
                                    },
                                    referenceString: c,
                                    resourceDestinationString: c,
                                    resourceTitleString: c,
                                    setextHeading: a(b),
                                    strong: a(function() {
                                        return {
                                            type: "strong",
                                            children: []
                                        }
                                    }),
                                    thematicBreak: a(function() {
                                        return {
                                            type: "thematicBreak"
                                        }
                                    })
                                },
                                exit: {
                                    atxHeading: f(),
                                    atxHeadingSequence: function(e) {
                                        let t = this.stack[this.stack.length - 1];
                                        if (!t.depth) {
                                            let n = this.sliceSerialize(e).length;
                                            t.depth = n
                                        }
                                    },
                                    autolink: f(),
                                    autolinkEmail: function(e) {
                                        m.call(this, e);
                                        let t = this.stack[this.stack.length - 1];
                                        t.url = "mailto:" + this.sliceSerialize(e)
                                    },
                                    autolinkProtocol: function(e) {
                                        m.call(this, e);
                                        let t = this.stack[this.stack.length - 1];
                                        t.url = this.sliceSerialize(e)
                                    },
                                    blockQuote: f(),
                                    characterEscapeValue: m,
                                    characterReferenceMarkerHexadecimal: y,
                                    characterReferenceMarkerNumeric: y,
                                    characterReferenceValue: function(e) {
                                        var t, r;
                                        let i = this.sliceSerialize(e),
                                            o = n.characterReferenceType,
                                            u;
                                        o ? (u = e2(i, "characterReferenceMarkerNumeric" === o ? 10 : 16), n[r = "characterReferenceType"] = void 0) : u = eD(i);
                                        let a = this.stack.pop();
                                        a.value += u, a.position.end = l(e.end)
                                    },
                                    codeFenced: f(function() {
                                        var e;
                                        let t = this.resume(),
                                            r = this.stack[this.stack.length - 1];
                                        r.value = t.replace(/^(\r?\n|\r)|(\r?\n|\r)$/g, ""), n.flowCodeInside = void 0
                                    }),
                                    codeFencedFence: function() {
                                        var e, t, r;
                                        !n.flowCodeInside && (this.buffer(), r = !0, n[t = "flowCodeInside"] = r)
                                    },
                                    codeFencedFenceInfo: function() {
                                        let e = this.resume(),
                                            t = this.stack[this.stack.length - 1];
                                        t.lang = e
                                    },
                                    codeFencedFenceMeta: function() {
                                        let e = this.resume(),
                                            t = this.stack[this.stack.length - 1];
                                        t.meta = e
                                    },
                                    codeFlowValue: m,
                                    codeIndented: f(function() {
                                        let e = this.resume(),
                                            t = this.stack[this.stack.length - 1];
                                        t.value = e.replace(/(\r?\n|\r)$/g, "")
                                    }),
                                    codeText: f(function() {
                                        let e = this.resume(),
                                            t = this.stack[this.stack.length - 1];
                                        t.value = e
                                    }),
                                    codeTextData: m,
                                    data: m,
                                    definition: f(),
                                    definitionDestinationString: function() {
                                        let e = this.resume(),
                                            t = this.stack[this.stack.length - 1];
                                        t.url = e
                                    },
                                    definitionLabelString: function(e) {
                                        let t = this.resume(),
                                            n = this.stack[this.stack.length - 1];
                                        n.label = t, n.identifier = eC(this.sliceSerialize(e)).toLowerCase()
                                    },
                                    definitionTitleString: function() {
                                        let e = this.resume(),
                                            t = this.stack[this.stack.length - 1];
                                        t.title = e
                                    },
                                    emphasis: f(),
                                    hardBreakEscape: f(g),
                                    hardBreakTrailing: f(g),
                                    htmlFlow: f(function() {
                                        let e = this.resume(),
                                            t = this.stack[this.stack.length - 1];
                                        t.value = e
                                    }),
                                    htmlFlowData: m,
                                    htmlText: f(function() {
                                        let e = this.resume(),
                                            t = this.stack[this.stack.length - 1];
                                        t.value = e
                                    }),
                                    htmlTextData: m,
                                    image: f(function() {
                                        var e, t, r;
                                        let i = this.stack[this.stack.length - 1];
                                        n.inReference ? (i.type += "Reference", i.referenceType = n[t = "referenceType"] || "shortcut", delete i.url, delete i.title) : (delete i.identifier, delete i.label), n.referenceType = void 0
                                    }),
                                    label: function() {
                                        var e, t;
                                        let r = this.stack[this.stack.length - 1],
                                            i = this.resume(),
                                            o = this.stack[this.stack.length - 1];
                                        n.inReference = !0, "link" === o.type ? o.children = r.children : o.alt = i
                                    },
                                    labelText: function(e) {
                                        var t;
                                        let n = this.stack[this.stack.length - 2],
                                            r = this.sliceSerialize(e);
                                        n.label = r.replace(e9, e4), n.identifier = eC(r).toLowerCase()
                                    },
                                    lineEnding: function(e) {
                                        var r, i, o;
                                        let u = this.stack[this.stack.length - 1];
                                        if (n.atHardBreak) {
                                            let a = u.children[u.children.length - 1];
                                            a.position.end = l(e.end), n[i = "atHardBreak"] = void 0;
                                            return
                                        }!n.setextHeadingSlurpLineEnding && t.canContainEols.includes(u.type) && (h.call(this, e), m.call(this, e))
                                    },
                                    link: f(function() {
                                        var e, t, r;
                                        let i = this.stack[this.stack.length - 1];
                                        n.inReference ? (i.type += "Reference", i.referenceType = n[t = "referenceType"] || "shortcut", delete i.url, delete i.title) : (delete i.identifier, delete i.label), n.referenceType = void 0
                                    }),
                                    listItem: f(),
                                    listOrdered: f(),
                                    listUnordered: f(),
                                    paragraph: f(),
                                    referenceString: function(e) {
                                        var t, r;
                                        let i = this.resume(),
                                            o = this.stack[this.stack.length - 1];
                                        o.label = i, o.identifier = eC(this.sliceSerialize(e)).toLowerCase(), n.referenceType = "full"
                                    },
                                    resourceDestinationString: function() {
                                        let e = this.resume(),
                                            t = this.stack[this.stack.length - 1];
                                        t.url = e
                                    },
                                    resourceTitleString: function() {
                                        let e = this.resume(),
                                            t = this.stack[this.stack.length - 1];
                                        t.title = e
                                    },
                                    resource: function() {
                                        var e;
                                        n.inReference = void 0
                                    },
                                    setextHeading: f(function() {
                                        var e;
                                        n.setextHeadingSlurpLineEnding = void 0
                                    }),
                                    setextHeadingLineSequence: function(e) {
                                        let t = this.stack[this.stack.length - 1];
                                        t.depth = 61 === this.sliceSerialize(e).charCodeAt(0) ? 1 : 2
                                    },
                                    setextHeadingText: function() {
                                        var e, t;
                                        n.setextHeadingSlurpLineEnding = !0
                                    },
                                    strong: f(),
                                    thematicBreak: f()
                                }
                            }, e.mdastExtensions || []),
                            n = {};
                        return function(e) {
                            let n = {
                                    type: "root",
                                    children: []
                                },
                                u = [n],
                                a = [],
                                f = [],
                                h = {
                                    stack: u,
                                    tokenStack: a,
                                    config: t,
                                    enter: s,
                                    exit: d,
                                    buffer: c,
                                    resume: p,
                                    setData: i,
                                    getData: o
                                },
                                m = -1;
                            for (; ++m < e.length;)
                                if ("listOrdered" === e[m][1].type || "listUnordered" === e[m][1].type) {
                                    if ("enter" === e[m][0]) f.push(m);
                                    else {
                                        let g = f.pop();
                                        m = r(e, g, m)
                                    }
                                }
                            for (m = -1; ++m < e.length;) {
                                let y = t[e[m][0]];
                                e5.call(y, e[m][1].type) && y[e[m][1].type].call(Object.assign({
                                    sliceSerialize: e[m][2].sliceSerialize
                                }, h), e[m][1])
                            }
                            if (a.length > 0) {
                                let v = a[a.length - 1],
                                    b = v[1] || te;
                                b.call(h, void 0, v[0])
                            }
                            for (n.position = {
                                    start: l(e.length > 0 ? e[0][1].start : {
                                        line: 1,
                                        column: 1,
                                        offset: 0
                                    }),
                                    end: l(e.length > 0 ? e[e.length - 2][1].end : {
                                        line: 1,
                                        column: 1,
                                        offset: 0
                                    })
                                }, m = -1; ++m < t.transforms.length;) n = t.transforms[m](n) || n;
                            return n
                        };

                        function r(e, t, n) {
                            let r = t - 1,
                                i = -1,
                                o = !1,
                                l, u, a, c;
                            for (; ++r <= n;) {
                                let s = e[r];
                                if ("listUnordered" === s[1].type || "listOrdered" === s[1].type || "blockQuote" === s[1].type ? ("enter" === s[0] ? i++ : i--, c = void 0) : "lineEndingBlank" === s[1].type ? "enter" === s[0] && (!l || c || i || a || (a = r), c = void 0) : "linePrefix" === s[1].type || "listItemValue" === s[1].type || "listItemMarker" === s[1].type || "listItemPrefix" === s[1].type || "listItemPrefixWhitespace" === s[1].type || (c = void 0), !i && "enter" === s[0] && "listItemPrefix" === s[1].type || -1 === i && "exit" === s[0] && ("listUnordered" === s[1].type || "listOrdered" === s[1].type)) {
                                    if (l) {
                                        let f = r;
                                        for (u = void 0; f--;) {
                                            let d = e[f];
                                            if ("lineEnding" === d[1].type || "lineEndingBlank" === d[1].type) {
                                                if ("exit" === d[0]) continue;
                                                u && (e[u][1].type = "lineEndingBlank", o = !0), d[1].type = "lineEnding", u = f
                                            } else if ("linePrefix" === d[1].type || "blockQuotePrefix" === d[1].type || "blockQuotePrefixWhitespace" === d[1].type || "blockQuoteMarker" === d[1].type || "listItemIndent" === d[1].type);
                                            else break
                                        }
                                        a && (!u || a < u) && (l._spread = !0), l.end = Object.assign({}, u ? e[u][1].start : s[1].end), e.splice(u || r, 0, ["exit", l, s[2]]), r++, n++
                                    }
                                    "listItemPrefix" === s[1].type && (l = {
                                        type: "listItem",
                                        _spread: !1,
                                        start: Object.assign({}, s[1].start)
                                    }, e.splice(r, 0, ["enter", l, s[2]]), r++, n++, a = void 0, c = !0)
                                }
                            }
                            return e[t][1]._spread = o, n
                        }

                        function i(e, t) {
                            n[e] = t
                        }

                        function o(e) {
                            return n[e]
                        }

                        function l(e) {
                            return {
                                line: e.line,
                                column: e.column,
                                offset: e.offset
                            }
                        }

                        function a(e, t) {
                            return function(n) {
                                s.call(this, e(n), n), t && t.call(this, n)
                            }
                        }

                        function c() {
                            this.stack.push({
                                type: "fragment",
                                children: []
                            })
                        }

                        function s(e, t, n) {
                            let r = this.stack[this.stack.length - 1];
                            return r.children.push(e), this.stack.push(e), this.tokenStack.push([t, n]), e.position = {
                                start: l(t.start)
                            }, e
                        }

                        function f(e) {
                            return function(t) {
                                e && e.call(this, t), d.call(this, t)
                            }
                        }

                        function d(e, t) {
                            let n = this.stack.pop(),
                                r = this.tokenStack.pop();
                            if (r) {
                                if (r[0].type !== e.type) {
                                    if (t) t.call(this, e, r[0]);
                                    else {
                                        let i = r[1] || te;
                                        i.call(this, e, r[0])
                                    }
                                }
                            } else throw Error("Cannot close `" + e.type + "` (" + u({
                                start: e.start,
                                end: e.end
                            }) + "): it’s not open");
                            return n.position.end = l(e.end), n
                        }

                        function p() {
                            return function(e, t) {
                                var {
                                    includeImageAlt: n = !0
                                } = {};
                                return I(e, n)
                            }(this.stack.pop())
                        }

                        function h(e) {
                            let t = this.stack[this.stack.length - 1],
                                n = t.children[t.children.length - 1];
                            n && "text" === n.type || ((n = {
                                type: "text",
                                value: ""
                            }).position = {
                                start: l(e.start)
                            }, t.children.push(n)), this.stack.push(n)
                        }

                        function m(e) {
                            let t = this.stack.pop();
                            t.value += this.sliceSerialize(e), t.position.end = l(e.end)
                        }

                        function g() {
                            var e, t;
                            n.atHardBreak = !0
                        }

                        function y(e) {
                            var t, r;
                            r = e.type, n.characterReferenceType = r
                        }

                        function v() {
                            return {
                                type: "code",
                                lang: null,
                                meta: null,
                                value: ""
                            }
                        }

                        function b() {
                            return {
                                type: "heading",
                                depth: void 0,
                                children: []
                            }
                        }

                        function x() {
                            return {
                                type: "break"
                            }
                        }

                        function k() {
                            return {
                                type: "html",
                                value: ""
                            }
                        }

                        function w() {
                            return {
                                type: "link",
                                title: null,
                                url: "",
                                children: []
                            }
                        }

                        function E(e) {
                            return {
                                type: "list",
                                ordered: "listOrdered" === e.type,
                                start: null,
                                spread: e._spread,
                                children: []
                            }
                        }
                    })(n)(function(e) {
                        for (; !ei(e););
                        return e
                    }((function(e = {}) {
                        let t = function(e) {
                                let t = {},
                                    n = -1;
                                for (; ++n < e.length;) N(t, e[n]);
                                return t
                            }([r].concat(e.extensions || [])),
                            n = {
                                defined: [],
                                lazy: {},
                                constructs: t,
                                content: i(ee),
                                document: i(et),
                                flow: i(ea),
                                string: i(es),
                                text: i(ef)
                            };
                        return n;

                        function i(e) {
                            return function(t) {
                                return function(e, t, n) {
                                    let r = Object.assign(n ? Object.assign({}, n) : {
                                            line: 1,
                                            column: 1,
                                            offset: 0
                                        }, {
                                            _index: 0,
                                            _bufferIndex: -1
                                        }),
                                        i = {},
                                        o = [],
                                        l = [],
                                        u = [],
                                        a = {
                                            consume: function(e) {
                                                J(e) ? (r.line++, r.column = 1, r.offset += -3 === e ? 2 : 1, y()) : -1 !== e && (r.column++, r.offset++), r._bufferIndex < 0 ? r._index++ : (r._bufferIndex++, r._bufferIndex === l[r._index].length && (r._bufferIndex = -1, r._index++)), c.previous = e
                                            },
                                            enter: function(e, t) {
                                                let n = t || {};
                                                return n.type = e, n.start = d(), c.events.push(["enter", n, c]), u.push(n), n
                                            },
                                            exit: function(e) {
                                                let t = u.pop();
                                                return t.end = d(), c.events.push(["exit", t, c]), t
                                            },
                                            attempt: m(function(e, t) {
                                                g(e, t.from)
                                            }),
                                            check: m(h),
                                            interrupt: m(h, {
                                                interrupt: !0
                                            })
                                        },
                                        c = {
                                            previous: null,
                                            code: null,
                                            containerState: {},
                                            events: [],
                                            parser: e,
                                            sliceStream: f,
                                            sliceSerialize: function(e, t) {
                                                return function(e, t) {
                                                    let n = -1,
                                                        r = [],
                                                        i;
                                                    for (; ++n < e.length;) {
                                                        let o = e[n],
                                                            l;
                                                        if ("string" == typeof o) l = o;
                                                        else switch (o) {
                                                            case -5:
                                                                l = "\r";
                                                                break;
                                                            case -4:
                                                                l = "\n";
                                                                break;
                                                            case -3:
                                                                l = "\r\n";
                                                                break;
                                                            case -2:
                                                                l = t ? " " : "	";
                                                                break;
                                                            case -1:
                                                                if (!t && i) continue;
                                                                l = " ";
                                                                break;
                                                            default:
                                                                l = String.fromCharCode(o)
                                                        }
                                                        i = -2 === o, r.push(l)
                                                    }
                                                    return r.join("")
                                                }(f(e), t)
                                            },
                                            now: d,
                                            defineSkip: function(e) {
                                                i[e.line] = e.column, y()
                                            },
                                            write: function(e) {
                                                return (l = z(l, e), function() {
                                                    let e;
                                                    for (; r._index < l.length;) {
                                                        let t = l[r._index];
                                                        if ("string" == typeof t)
                                                            for (e = r._index, r._bufferIndex < 0 && (r._bufferIndex = 0); r._index === e && r._bufferIndex < t.length;) p(t.charCodeAt(r._bufferIndex));
                                                        else p(t)
                                                    }
                                                }(), null !== l[l.length - 1]) ? [] : (g(t, 0), c.events = em(o, c.events, c), c.events)
                                            }
                                        },
                                        s = t.tokenize.call(c, a);
                                    return t.resolveAll && o.push(t), c;

                                    function f(e) {
                                        return function(e, t) {
                                            let n = t.start._index,
                                                r = t.start._bufferIndex,
                                                i = t.end._index,
                                                o = t.end._bufferIndex,
                                                l;
                                            return n === i ? l = [e[n].slice(r, o)] : (l = e.slice(n, i), r > -1 && (l[0] = l[0].slice(r)), o > 0 && l.push(e[i].slice(0, o))), l
                                        }(l, e)
                                    }

                                    function d() {
                                        return Object.assign({}, r)
                                    }

                                    function p(e) {
                                        s = s(e)
                                    }

                                    function h(e, t) {
                                        t.restore()
                                    }

                                    function m(e, t) {
                                        return function(n, i, o) {
                                            var l;
                                            let s, f, p, h;
                                            return Array.isArray(n) ? m(n) : "tokenize" in n ? m([n]) : (l = n, function(e) {
                                                let t = null !== e && l[e],
                                                    n = null !== e && l.null,
                                                    r = [...Array.isArray(t) ? t : t ? [t] : [], ...Array.isArray(n) ? n : n ? [n] : []];
                                                return m(r)(e)
                                            });

                                            function m(e) {
                                                return (s = e, f = 0, 0 === e.length) ? o : g(e[f])
                                            }

                                            function g(e) {
                                                return function(n) {
                                                    return (h = function() {
                                                        let e = d(),
                                                            t = c.previous,
                                                            n = c.currentConstruct,
                                                            i = c.events.length,
                                                            o = Array.from(u);
                                                        return {
                                                            restore: function() {
                                                                r = e, c.previous = t, c.currentConstruct = n, c.events.length = i, u = o, y()
                                                            },
                                                            from: i
                                                        }
                                                    }(), p = e, e.partial || (c.currentConstruct = e), e.name && c.parser.constructs.disable.null.includes(e.name)) ? b(n) : e.tokenize.call(t ? Object.assign(Object.create(c), t) : c, a, v, b)(n)
                                                }
                                            }

                                            function v(t) {
                                                return e(p, h), i
                                            }

                                            function b(e) {
                                                return (h.restore(), ++f < s.length) ? g(s[f]) : o
                                            }
                                        }
                                    }

                                    function g(e, t) {
                                        e.resolveAll && !o.includes(e) && o.push(e), e.resolve && D(c.events, t, c.events.length - t, e.resolve(c.events.slice(t), c)), e.resolveTo && (c.events = e.resolveTo(c.events, c))
                                    }

                                    function y() {
                                        r.line in i && r.column < 2 && (r.column = i[r.line], r.offset += i[r.line] - 1)
                                    }
                                }(n, e, t)
                            }
                        }
                    })(n).document().write((i = 1, o = "", l = !0, function(e, t, n) {
                        let r = [],
                            u, c, s, f, d;
                        for (e = o + e.toString(t), s = 0, o = "", l && (65279 === e.charCodeAt(0) && s++, l = void 0); s < e.length;) {
                            if (e3.lastIndex = s, f = (u = e3.exec(e)) && void 0 !== u.index ? u.index : e.length, d = e.charCodeAt(f), !u) {
                                o = e.slice(s);
                                break
                            }
                            if (10 === d && s === f && a) r.push(-3), a = void 0;
                            else switch (a && (r.push(-5), a = void 0), s < f && (r.push(e.slice(s, f)), i += f - s), d) {
                                case 0:
                                    r.push(65533), i++;
                                    break;
                                case 9:
                                    for (c = 4 * Math.ceil(i / 4), r.push(-2); i++ < c;) r.push(-1);
                                    break;
                                case 10:
                                    r.push(-4), i = 1;
                                    break;
                                default:
                                    a = !0, i = 1
                            }
                            s = f + 1
                        }
                        return n && (a && r.push(-5), o && r.push(o), r.push(null)), r
                    })(e, t, !0))))
                };

            function e8(e, t) {
                let n;
                for (n in t)
                    if (e5.call(t, n)) {
                        let r = "canContainEols" === n || "transforms" === n,
                            i = e5.call(e, n) ? e[n] : void 0,
                            o = i || (e[n] = r ? [] : {}),
                            l = t[n];
                        l && (r ? e[n] = [...o, ...l] : Object.assign(o, l))
                    }
            }

            function te(e, t) {
                if (e) throw Error("Cannot close `" + e.type + "` (" + u({
                    start: e.start,
                    end: e.end
                }) + "): a different token (`" + t.type + "`, " + u({
                    start: t.start,
                    end: t.end
                }) + ") is open");
                throw Error("Cannot close document, a token (`" + t.type + "`, " + u({
                    start: t.start,
                    end: t.end
                }) + ") is still open")
            }
            var tt = function(e) {
                    let t = t => {
                        let n = this.data("settings");
                        return e7(t, Object.assign({}, n, e, {
                            extensions: this.data("micromarkExtensions") || [],
                            mdastExtensions: this.data("fromMarkdownExtensions") || []
                        }))
                    };
                    Object.assign(this, {
                        Parser: t
                    })
                },
                tn = function(e, t, n) {
                    var r = {
                        type: String(e)
                    };
                    return null == n && ("string" == typeof t || Array.isArray(t)) ? n = t : Object.assign(r, t), Array.isArray(n) ? r.children = n : null != n && (r.value = String(n)), r
                };
            let tr = function(e) {
                var t, n;
                if (null == e) return to;
                if ("string" == typeof e) {
                    return t = e, ti(function(e) {
                        return e && e.type === t
                    })
                }
                if ("object" == typeof e) {
                    return Array.isArray(e) ? function(e) {
                        let t = [],
                            n = -1;
                        for (; ++n < e.length;) t[n] = tr(e[n]);
                        return ti(function(...e) {
                            let n = -1;
                            for (; ++n < t.length;)
                                if (t[n].call(this, ...e)) return !0;
                            return !1
                        })
                    }(e) : (n = e, ti(function(e) {
                        let t;
                        for (t in n)
                            if (e[t] !== n[t]) return !1;
                        return !0
                    }))
                }
                if ("function" == typeof e) return ti(e);
                throw Error("Expected function, string, or object as test")
            };

            function ti(e) {
                return function(...t) {
                    return Boolean(e.call(this, ...t))
                }
            }

            function to() {
                return !0
            }
            let tl = function(e, t, n, r) {
                    "function" == typeof t && "function" != typeof n && (r = n, n = t, t = null);
                    let i = tr(t),
                        o = r ? -1 : 1;
                    (function e(l, u, a) {
                        let c = "object" == typeof l && null !== l ? l : {},
                            s;
                        if ("string" == typeof c.type) {
                            var f;
                            s = "string" == typeof c.tagName ? c.tagName : "string" == typeof c.name ? c.name : void 0, Object.defineProperty(d, "name", {
                                value: "node (" + (f = c.type + (s ? "<" + s + ">" : "")) + ")"
                            })
                        }
                        return d;

                        function d() {
                            var c;
                            let s = [],
                                f, d, p;
                            if ((!t || i(l, u, a[a.length - 1] || null)) && !1 === (c = n(l, a), s = Array.isArray(c) ? c : "number" == typeof c ? [!0, c] : [c])[0]) return s;
                            if (l.children && "skip" !== s[0])
                                for (d = (r ? l.children.length : -1) + o, p = a.concat(l); d > -1 && d < l.children.length;) {
                                    if (!1 === (f = e(l.children[d], d, p)())[0]) return f;
                                    d = "number" == typeof f[1] ? f[1] : d + o
                                }
                            return s
                        }
                    })(e, null, [])()
                },
                tu = function(e, t, n, r) {
                    "function" == typeof t && "function" != typeof n && (r = n, n = t, t = null), tl(e, t, function(e, t) {
                        let r = t[t.length - 1];
                        return n(e, r ? r.children.indexOf(e) : null, r)
                    }, r)
                },
                ta = ts("start"),
                tc = ts("end");

            function ts(e) {
                return function(t) {
                    let n = t && t.position && t.position[e] || {};
                    return {
                        line: n.line || null,
                        column: n.column || null,
                        offset: n.offset > -1 ? n.offset : null
                    }
                }
            }
            let tf = {}.hasOwnProperty;

            function td(e) {
                return String(e || "").toUpperCase()
            }
            let tp = {}.hasOwnProperty;

            function th(e, t) {
                let n = t.data || {};
                return "value" in t && !(tp.call(n, "hName") || tp.call(n, "hProperties") || tp.call(n, "hChildren")) ? e.augment(t, tn("text", t.value)) : e(t, "div", ty(e, t))
            }

            function tm(e, t, n) {
                let r = t && t.type,
                    i;
                if (!r) throw Error("Expected node, got `" + t + "`");
                return ("function" == typeof(i = tp.call(e.handlers, r) ? e.handlers[r] : e.passThrough && e.passThrough.includes(r) ? tg : e.unknownHandler) ? i : th)(e, t, n)
            }

            function tg(e, t) {
                return "children" in t ? { ...t,
                    children: ty(e, t)
                } : t
            }

            function ty(e, t) {
                let n = [];
                if ("children" in t) {
                    let r = t.children,
                        i = -1;
                    for (; ++i < r.length;) {
                        let o = tm(e, r[i], t);
                        if (o) {
                            if (i && "break" === r[i - 1].type && (Array.isArray(o) || "text" !== o.type || (o.value = o.value.replace(/^\s+/, "")), !Array.isArray(o) && "element" === o.type)) {
                                let l = o.children[0];
                                l && "text" === l.type && (l.value = l.value.replace(/^\s+/, ""))
                            }
                            Array.isArray(o) ? n.push(...o) : n.push(o)
                        }
                    }
                }
                return n
            }

            function tv(e) {
                let t = [],
                    n = -1,
                    r = 0,
                    i = 0;
                for (; ++n < e.length;) {
                    let o = e.charCodeAt(n),
                        l = "";
                    if (37 === o && q(e.charCodeAt(n + 1)) && q(e.charCodeAt(n + 2))) i = 2;
                    else if (o < 128) /[!#$&-;=?-Z_a-z~]/.test(String.fromCharCode(o)) || (l = String.fromCharCode(o));
                    else if (o > 55295 && o < 57344) {
                        let u = e.charCodeAt(n + 1);
                        o < 56320 && u > 56319 && u < 57344 ? (l = String.fromCharCode(o, u), i = 1) : l = "�"
                    } else l = String.fromCharCode(o);
                    l && (t.push(e.slice(r, n), encodeURIComponent(l)), r = n + i + 1, l = ""), i && (n += i, i = 0)
                }
                return t.join("") + e.slice(r)
            }

            function tb(e, t) {
                let n = [],
                    r = -1;
                for (t && n.push(tn("text", "\n")); ++r < e.length;) r && n.push(tn("text", "\n")), n.push(e[r]);
                return t && e.length > 0 && n.push(tn("text", "\n")), n
            }

            function tx(e, t) {
                let n = String(t.identifier),
                    r = tv(n.toLowerCase()),
                    i = e.footnoteOrder.indexOf(n),
                    o; - 1 === i ? (e.footnoteOrder.push(n), e.footnoteCounts[n] = 1, o = e.footnoteOrder.length) : (e.footnoteCounts[n]++, o = i + 1);
                let l = e.footnoteCounts[n];
                return e(t, "sup", [e(t.position, "a", {
                    href: "#" + e.clobberPrefix + "fn-" + r,
                    id: e.clobberPrefix + "fnref-" + r + (l > 1 ? "-" + l : ""),
                    dataFootnoteRef: !0,
                    ariaDescribedBy: "footnote-label"
                }, [tn("text", String(o))])])
            }

            function tk(e, t) {
                let n = t.referenceType,
                    r = "]";
                if ("collapsed" === n ? r += "[]" : "full" === n && (r += "[" + (t.label || t.identifier) + "]"), "imageReference" === t.type) return tn("text", "![" + t.alt + r);
                let i = ty(e, t),
                    o = i[0];
                o && "text" === o.type ? o.value = "[" + o.value : i.unshift(tn("text", "["));
                let l = i[i.length - 1];
                return l && "text" === l.type ? l.value += r : i.push(tn("text", r)), i
            }

            function tw(e) {
                let t = e.spread;
                return null == t ? e.children.length > 1 : t
            }

            function tE(e, t, n) {
                let r = 0,
                    i = e.length;
                if (t) {
                    let o = e.codePointAt(r);
                    for (; 9 === o || 32 === o;) r++, o = e.codePointAt(r)
                }
                if (n) {
                    let l = e.codePointAt(i - 1);
                    for (; 9 === l || 32 === l;) i--, l = e.codePointAt(i - 1)
                }
                return i > r ? e.slice(r, i) : ""
            }
            let tS = {
                blockquote: function(e, t) {
                    return e(t, "blockquote", tb(ty(e, t), !0))
                },
                break: function(e, t) {
                    return [e(t, "br"), tn("text", "\n")]
                },
                code: function(e, t) {
                    let n = t.value ? t.value + "\n" : "",
                        r = t.lang && t.lang.match(/^[^ \t]+(?=[ \t]|$)/),
                        i = {};
                    r && (i.className = ["language-" + r]);
                    let o = e(t, "code", i, [tn("text", n)]);
                    return t.meta && (o.data = {
                        meta: t.meta
                    }), e(t.position, "pre", [o])
                },
                delete: function(e, t) {
                    return e(t, "del", ty(e, t))
                },
                emphasis: function(e, t) {
                    return e(t, "em", ty(e, t))
                },
                footnoteReference: tx,
                footnote: function(e, t) {
                    let n = e.footnoteById,
                        r = 1;
                    for (;
                        (r in n);) r++;
                    let i = String(r);
                    return n[i] = {
                        type: "footnoteDefinition",
                        identifier: i,
                        children: [{
                            type: "paragraph",
                            children: t.children
                        }],
                        position: t.position
                    }, tx(e, {
                        type: "footnoteReference",
                        identifier: i,
                        position: t.position
                    })
                },
                heading: function(e, t) {
                    return e(t, "h" + t.depth, ty(e, t))
                },
                html: function(e, t) {
                    return e.dangerous ? e.augment(t, tn("raw", t.value)) : null
                },
                imageReference: function(e, t) {
                    let n = e.definition(t.identifier);
                    if (!n) return tk(e, t);
                    let r = {
                        src: tv(n.url || ""),
                        alt: t.alt
                    };
                    return null !== n.title && void 0 !== n.title && (r.title = n.title), e(t, "img", r)
                },
                image: function(e, t) {
                    let n = {
                        src: tv(t.url),
                        alt: t.alt
                    };
                    return null !== t.title && void 0 !== t.title && (n.title = t.title), e(t, "img", n)
                },
                inlineCode: function(e, t) {
                    return e(t, "code", [tn("text", t.value.replace(/\r?\n|\r/g, " "))])
                },
                linkReference: function(e, t) {
                    let n = e.definition(t.identifier);
                    if (!n) return tk(e, t);
                    let r = {
                        href: tv(n.url || "")
                    };
                    return null !== n.title && void 0 !== n.title && (r.title = n.title), e(t, "a", r, ty(e, t))
                },
                link: function(e, t) {
                    let n = {
                        href: tv(t.url)
                    };
                    return null !== t.title && void 0 !== t.title && (n.title = t.title), e(t, "a", n, ty(e, t))
                },
                listItem: function(e, t, n) {
                    let r = ty(e, t),
                        i = n ? function(e) {
                            let t = e.spread,
                                n = e.children,
                                r = -1;
                            for (; !t && ++r < n.length;) t = tw(n[r]);
                            return Boolean(t)
                        }(n) : tw(t),
                        o = {},
                        l = [];
                    if ("boolean" == typeof t.checked) {
                        let u;
                        r[0] && "element" === r[0].type && "p" === r[0].tagName ? u = r[0] : (u = e(null, "p", []), r.unshift(u)), u.children.length > 0 && u.children.unshift(tn("text", " ")), u.children.unshift(e(null, "input", {
                            type: "checkbox",
                            checked: t.checked,
                            disabled: !0
                        })), o.className = ["task-list-item"]
                    }
                    let a = -1;
                    for (; ++a < r.length;) {
                        let c = r[a];
                        (i || 0 !== a || "element" !== c.type || "p" !== c.tagName) && l.push(tn("text", "\n")), "element" !== c.type || "p" !== c.tagName || i ? l.push(c) : l.push(...c.children)
                    }
                    let s = r[r.length - 1];
                    return !s || !i && "tagName" in s && "p" === s.tagName || l.push(tn("text", "\n")), e(t, "li", o, l)
                },
                list: function(e, t) {
                    let n = {},
                        r = t.ordered ? "ol" : "ul",
                        i = ty(e, t),
                        o = -1;
                    for ("number" == typeof t.start && 1 !== t.start && (n.start = t.start); ++o < i.length;) {
                        let l = i[o];
                        if ("element" === l.type && "li" === l.tagName && l.properties && Array.isArray(l.properties.className) && l.properties.className.includes("task-list-item")) {
                            n.className = ["contains-task-list"];
                            break
                        }
                    }
                    return e(t, r, n, tb(i, !0))
                },
                paragraph: function(e, t) {
                    return e(t, "p", ty(e, t))
                },
                root: function(e, t) {
                    return e.augment(t, tn("root", tb(ty(e, t))))
                },
                strong: function(e, t) {
                    return e(t, "strong", ty(e, t))
                },
                table: function(e, t) {
                    let n = t.children,
                        r = -1,
                        i = t.align || [],
                        o = [];
                    for (; ++r < n.length;) {
                        let l = n[r].children,
                            u = 0 === r ? "th" : "td",
                            a = [],
                            c = -1,
                            s = t.align ? i.length : l.length;
                        for (; ++c < s;) {
                            let f = l[c];
                            a.push(e(f, u, {
                                align: i[c]
                            }, f ? ty(e, f) : []))
                        }
                        o[r] = e(n[r], "tr", tb(a, !0))
                    }
                    return e(t, "table", tb([e(o[0].position, "thead", tb([o[0]], !0))].concat(o[1] ? e({
                        start: ta(o[1]),
                        end: tc(o[o.length - 1])
                    }, "tbody", tb(o.slice(1), !0)) : []), !0))
                },
                text: function(e, t) {
                    return e.augment(t, tn("text", function(e) {
                        let t = String(e),
                            n = /\r?\n|\r/g,
                            r = n.exec(t),
                            i = 0,
                            o = [];
                        for (; r;) o.push(tE(t.slice(i, r.index), i > 0, !0), r[0]), i = r.index + r[0].length, r = n.exec(t);
                        return o.push(tE(t.slice(i), i > 0, !1)), o.join("")
                    }(String(t.value))))
                },
                thematicBreak: function(e, t) {
                    return e(t, "hr")
                },
                toml: tC,
                yaml: tC,
                definition: tC,
                footnoteDefinition: tC
            };

            function tC() {
                return null
            }
            let tA = {}.hasOwnProperty;

            function tP(e, t) {
                let n = function(e, t) {
                        let n = t || {},
                            r = n.allowDangerousHtml || !1,
                            i = {};
                        return l.dangerous = r, l.clobberPrefix = void 0 === n.clobberPrefix || null === n.clobberPrefix ? "user-content-" : n.clobberPrefix, l.footnoteLabel = n.footnoteLabel || "Footnotes", l.footnoteLabelTagName = n.footnoteLabelTagName || "h2", l.footnoteLabelProperties = n.footnoteLabelProperties || {
                            className: ["sr-only"]
                        }, l.footnoteBackLabel = n.footnoteBackLabel || "Back to content", l.definition = function(e) {
                            let t = Object.create(null);
                            if (!e || !e.type) throw Error("mdast-util-definitions expected node");
                            return tu(e, "definition", e => {
                                    let n = td(e.identifier);
                                    n && !tf.call(t, n) && (t[n] = e)
                                }),
                                function(e) {
                                    let n = td(e);
                                    return n && tf.call(t, n) ? t[n] : null
                                }
                        }(e), l.footnoteById = i, l.footnoteOrder = [], l.footnoteCounts = {}, l.augment = o, l.handlers = { ...tS,
                            ...n.handlers
                        }, l.unknownHandler = n.unknownHandler, l.passThrough = n.passThrough, tu(e, "footnoteDefinition", e => {
                            let t = String(e.identifier).toUpperCase();
                            tA.call(i, t) || (i[t] = e)
                        }), l;

                        function o(e, t) {
                            if (e && "data" in e && e.data) {
                                let n = e.data;
                                n.hName && ("element" !== t.type && (t = {
                                    type: "element",
                                    tagName: "",
                                    properties: {},
                                    children: []
                                }), t.tagName = n.hName), "element" === t.type && n.hProperties && (t.properties = { ...t.properties,
                                    ...n.hProperties
                                }), "children" in t && t.children && n.hChildren && (t.children = n.hChildren)
                            }
                            if (e) {
                                var r;
                                let i = "type" in e ? e : {
                                    position: e
                                };
                                i && i.position && i.position.start && i.position.start.line && i.position.start.column && i.position.end && i.position.end.line && i.position.end.column && (t.position = {
                                    start: ta(i),
                                    end: tc(i)
                                })
                            }
                            return t
                        }

                        function l(e, t, n, r) {
                            return Array.isArray(n) && (r = n, n = {}), o(e, {
                                type: "element",
                                tagName: t,
                                properties: n || {},
                                children: r || []
                            })
                        }
                    }(e, t),
                    r = tm(n, e, null),
                    i = function(e) {
                        let t = -1,
                            n = [];
                        for (; ++t < e.footnoteOrder.length;) {
                            let r = e.footnoteById[e.footnoteOrder[t].toUpperCase()];
                            if (!r) continue;
                            let i = ty(e, r),
                                o = String(r.identifier),
                                l = tv(o.toLowerCase()),
                                u = 0,
                                a = [];
                            for (; ++u <= e.footnoteCounts[o];) {
                                let c = {
                                    type: "element",
                                    tagName: "a",
                                    properties: {
                                        href: "#" + e.clobberPrefix + "fnref-" + l + (u > 1 ? "-" + u : ""),
                                        dataFootnoteBackref: !0,
                                        className: ["data-footnote-backref"],
                                        ariaLabel: e.footnoteBackLabel
                                    },
                                    children: [{
                                        type: "text",
                                        value: "↩"
                                    }]
                                };
                                u > 1 && c.children.push({
                                    type: "element",
                                    tagName: "sup",
                                    children: [{
                                        type: "text",
                                        value: String(u)
                                    }]
                                }), a.length > 0 && a.push({
                                    type: "text",
                                    value: " "
                                }), a.push(c)
                            }
                            let s = i[i.length - 1];
                            if (s && "element" === s.type && "p" === s.tagName) {
                                let f = s.children[s.children.length - 1];
                                f && "text" === f.type ? f.value += " " : s.children.push({
                                    type: "text",
                                    value: " "
                                }), s.children.push(...a)
                            } else i.push(...a);
                            let d = {
                                type: "element",
                                tagName: "li",
                                properties: {
                                    id: e.clobberPrefix + "fn-" + l
                                },
                                children: tb(i, !0)
                            };
                            r.position && (d.position = r.position), n.push(d)
                        }
                        return 0 === n.length ? null : {
                            type: "element",
                            tagName: "section",
                            properties: {
                                dataFootnotes: !0,
                                className: ["footnotes"]
                            },
                            children: [{
                                type: "element",
                                tagName: e.footnoteLabelTagName,
                                properties: { ...JSON.parse(JSON.stringify(e.footnoteLabelProperties)),
                                    id: "footnote-label"
                                },
                                children: [tn("text", e.footnoteLabel)]
                            }, {
                                type: "text",
                                value: "\n"
                            }, {
                                type: "element",
                                tagName: "ol",
                                properties: {},
                                children: tb(n, !0)
                            }, {
                                type: "text",
                                value: "\n"
                            }]
                        }
                    }(n);
                return i && r.children.push(tn("text", "\n"), i), Array.isArray(r) ? {
                    type: "root",
                    children: r
                } : r
            }
            let tM = function(e, t) {
                var n, r, i;
                return e && "run" in e ? (n = e, r = t, (e, t, i) => {
                    n.run(tP(e, r), t, e => {
                        i(e)
                    })
                }) : (i = e || t, e => tP(e, i))
            };
            var tL = n(5697);
            class tT {
                constructor(e, t, n) {
                    this.property = e, this.normal = t, n && (this.space = n)
                }
            }

            function tO(e, t) {
                let n = {},
                    r = {},
                    i = -1;
                for (; ++i < e.length;) Object.assign(n, e[i].property), Object.assign(r, e[i].normal);
                return new tT(n, r, t)
            }

            function tF(e) {
                return e.toLowerCase()
            }
            tT.prototype.property = {}, tT.prototype.normal = {}, tT.prototype.space = null;
            class tI {
                constructor(e, t) {
                    this.property = e, this.attribute = t
                }
            }
            tI.prototype.space = null, tI.prototype.boolean = !1, tI.prototype.booleanish = !1, tI.prototype.overloadedBoolean = !1, tI.prototype.number = !1, tI.prototype.commaSeparated = !1, tI.prototype.spaceSeparated = !1, tI.prototype.commaOrSpaceSeparated = !1, tI.prototype.mustUseProperty = !1, tI.prototype.defined = !1;
            let tj = 0,
                tD = tH(),
                tz = tH(),
                tR = tH(),
                tN = tH(),
                tB = tH(),
                t_ = tH(),
                t$ = tH();

            function tH() {
                return 2 ** ++tj
            }
            let tq = Object.keys(i);
            class tV extends tI {
                constructor(e, t, n, r) {
                    let o = -1;
                    if (super(e, t), tU(this, "space", r), "number" == typeof n)
                        for (; ++o < tq.length;) {
                            let l = tq[o];
                            tU(this, tq[o], (n & i[l]) === i[l])
                        }
                }
            }

            function tU(e, t, n) {
                n && (e[t] = n)
            }
            tV.prototype.defined = !0;
            let tZ = {}.hasOwnProperty;

            function tW(e) {
                let t = {},
                    n = {},
                    r;
                for (r in e.properties)
                    if (tZ.call(e.properties, r)) {
                        let i = e.properties[r],
                            o = new tV(r, e.transform(e.attributes || {}, r), i, e.space);
                        e.mustUseProperty && e.mustUseProperty.includes(r) && (o.mustUseProperty = !0), t[r] = o, n[tF(r)] = r, n[tF(o.attribute)] = r
                    }
                return new tT(t, n, e.space)
            }
            let tJ = tW({
                    space: "xlink",
                    transform: (e, t) => "xlink:" + t.slice(5).toLowerCase(),
                    properties: {
                        xLinkActuate: null,
                        xLinkArcRole: null,
                        xLinkHref: null,
                        xLinkRole: null,
                        xLinkShow: null,
                        xLinkTitle: null,
                        xLinkType: null
                    }
                }),
                tK = tW({
                    space: "xml",
                    transform: (e, t) => "xml:" + t.slice(3).toLowerCase(),
                    properties: {
                        xmlLang: null,
                        xmlBase: null,
                        xmlSpace: null
                    }
                });

            function tG(e, t) {
                return t in e ? e[t] : t
            }

            function tQ(e, t) {
                return tG(e, t.toLowerCase())
            }
            let tY = tW({
                    space: "xmlns",
                    attributes: {
                        xmlnsxlink: "xmlns:xlink"
                    },
                    transform: tQ,
                    properties: {
                        xmlns: null,
                        xmlnsXLink: null
                    }
                }),
                tX = tW({
                    transform: (e, t) => "role" === t ? t : "aria-" + t.slice(4).toLowerCase(),
                    properties: {
                        ariaActiveDescendant: null,
                        ariaAtomic: tz,
                        ariaAutoComplete: null,
                        ariaBusy: tz,
                        ariaChecked: tz,
                        ariaColCount: tN,
                        ariaColIndex: tN,
                        ariaColSpan: tN,
                        ariaControls: tB,
                        ariaCurrent: null,
                        ariaDescribedBy: tB,
                        ariaDetails: null,
                        ariaDisabled: tz,
                        ariaDropEffect: tB,
                        ariaErrorMessage: null,
                        ariaExpanded: tz,
                        ariaFlowTo: tB,
                        ariaGrabbed: tz,
                        ariaHasPopup: null,
                        ariaHidden: tz,
                        ariaInvalid: null,
                        ariaKeyShortcuts: null,
                        ariaLabel: null,
                        ariaLabelledBy: tB,
                        ariaLevel: tN,
                        ariaLive: null,
                        ariaModal: tz,
                        ariaMultiLine: tz,
                        ariaMultiSelectable: tz,
                        ariaOrientation: null,
                        ariaOwns: tB,
                        ariaPlaceholder: null,
                        ariaPosInSet: tN,
                        ariaPressed: tz,
                        ariaReadOnly: tz,
                        ariaRelevant: null,
                        ariaRequired: tz,
                        ariaRoleDescription: tB,
                        ariaRowCount: tN,
                        ariaRowIndex: tN,
                        ariaRowSpan: tN,
                        ariaSelected: tz,
                        ariaSetSize: tN,
                        ariaSort: null,
                        ariaValueMax: tN,
                        ariaValueMin: tN,
                        ariaValueNow: tN,
                        ariaValueText: null,
                        role: null
                    }
                }),
                t0 = tW({
                    space: "html",
                    attributes: {
                        acceptcharset: "accept-charset",
                        classname: "class",
                        htmlfor: "for",
                        httpequiv: "http-equiv"
                    },
                    transform: tQ,
                    mustUseProperty: ["checked", "multiple", "muted", "selected"],
                    properties: {
                        abbr: null,
                        accept: t_,
                        acceptCharset: tB,
                        accessKey: tB,
                        action: null,
                        allow: null,
                        allowFullScreen: tD,
                        allowPaymentRequest: tD,
                        allowUserMedia: tD,
                        alt: null,
                        as: null,
                        async: tD,
                        autoCapitalize: null,
                        autoComplete: tB,
                        autoFocus: tD,
                        autoPlay: tD,
                        capture: tD,
                        charSet: null,
                        checked: tD,
                        cite: null,
                        className: tB,
                        cols: tN,
                        colSpan: null,
                        content: null,
                        contentEditable: tz,
                        controls: tD,
                        controlsList: tB,
                        coords: tN | t_,
                        crossOrigin: null,
                        data: null,
                        dateTime: null,
                        decoding: null,
                        default: tD,
                        defer: tD,
                        dir: null,
                        dirName: null,
                        disabled: tD,
                        download: tR,
                        draggable: tz,
                        encType: null,
                        enterKeyHint: null,
                        form: null,
                        formAction: null,
                        formEncType: null,
                        formMethod: null,
                        formNoValidate: tD,
                        formTarget: null,
                        headers: tB,
                        height: tN,
                        hidden: tD,
                        high: tN,
                        href: null,
                        hrefLang: null,
                        htmlFor: tB,
                        httpEquiv: tB,
                        id: null,
                        imageSizes: null,
                        imageSrcSet: null,
                        inputMode: null,
                        integrity: null,
                        is: null,
                        isMap: tD,
                        itemId: null,
                        itemProp: tB,
                        itemRef: tB,
                        itemScope: tD,
                        itemType: tB,
                        kind: null,
                        label: null,
                        lang: null,
                        language: null,
                        list: null,
                        loading: null,
                        loop: tD,
                        low: tN,
                        manifest: null,
                        max: null,
                        maxLength: tN,
                        media: null,
                        method: null,
                        min: null,
                        minLength: tN,
                        multiple: tD,
                        muted: tD,
                        name: null,
                        nonce: null,
                        noModule: tD,
                        noValidate: tD,
                        onAbort: null,
                        onAfterPrint: null,
                        onAuxClick: null,
                        onBeforeMatch: null,
                        onBeforePrint: null,
                        onBeforeUnload: null,
                        onBlur: null,
                        onCancel: null,
                        onCanPlay: null,
                        onCanPlayThrough: null,
                        onChange: null,
                        onClick: null,
                        onClose: null,
                        onContextLost: null,
                        onContextMenu: null,
                        onContextRestored: null,
                        onCopy: null,
                        onCueChange: null,
                        onCut: null,
                        onDblClick: null,
                        onDrag: null,
                        onDragEnd: null,
                        onDragEnter: null,
                        onDragExit: null,
                        onDragLeave: null,
                        onDragOver: null,
                        onDragStart: null,
                        onDrop: null,
                        onDurationChange: null,
                        onEmptied: null,
                        onEnded: null,
                        onError: null,
                        onFocus: null,
                        onFormData: null,
                        onHashChange: null,
                        onInput: null,
                        onInvalid: null,
                        onKeyDown: null,
                        onKeyPress: null,
                        onKeyUp: null,
                        onLanguageChange: null,
                        onLoad: null,
                        onLoadedData: null,
                        onLoadedMetadata: null,
                        onLoadEnd: null,
                        onLoadStart: null,
                        onMessage: null,
                        onMessageError: null,
                        onMouseDown: null,
                        onMouseEnter: null,
                        onMouseLeave: null,
                        onMouseMove: null,
                        onMouseOut: null,
                        onMouseOver: null,
                        onMouseUp: null,
                        onOffline: null,
                        onOnline: null,
                        onPageHide: null,
                        onPageShow: null,
                        onPaste: null,
                        onPause: null,
                        onPlay: null,
                        onPlaying: null,
                        onPopState: null,
                        onProgress: null,
                        onRateChange: null,
                        onRejectionHandled: null,
                        onReset: null,
                        onResize: null,
                        onScroll: null,
                        onScrollEnd: null,
                        onSecurityPolicyViolation: null,
                        onSeeked: null,
                        onSeeking: null,
                        onSelect: null,
                        onSlotChange: null,
                        onStalled: null,
                        onStorage: null,
                        onSubmit: null,
                        onSuspend: null,
                        onTimeUpdate: null,
                        onToggle: null,
                        onUnhandledRejection: null,
                        onUnload: null,
                        onVolumeChange: null,
                        onWaiting: null,
                        onWheel: null,
                        open: tD,
                        optimum: tN,
                        pattern: null,
                        ping: tB,
                        placeholder: null,
                        playsInline: tD,
                        poster: null,
                        preload: null,
                        readOnly: tD,
                        referrerPolicy: null,
                        rel: tB,
                        required: tD,
                        reversed: tD,
                        rows: tN,
                        rowSpan: tN,
                        sandbox: tB,
                        scope: null,
                        scoped: tD,
                        seamless: tD,
                        selected: tD,
                        shape: null,
                        size: tN,
                        sizes: null,
                        slot: null,
                        span: tN,
                        spellCheck: tz,
                        src: null,
                        srcDoc: null,
                        srcLang: null,
                        srcSet: null,
                        start: tN,
                        step: null,
                        style: null,
                        tabIndex: tN,
                        target: null,
                        title: null,
                        translate: null,
                        type: null,
                        typeMustMatch: tD,
                        useMap: null,
                        value: tz,
                        width: tN,
                        wrap: null,
                        align: null,
                        aLink: null,
                        archive: tB,
                        axis: null,
                        background: null,
                        bgColor: null,
                        border: tN,
                        borderColor: null,
                        bottomMargin: tN,
                        cellPadding: null,
                        cellSpacing: null,
                        char: null,
                        charOff: null,
                        classId: null,
                        clear: null,
                        code: null,
                        codeBase: null,
                        codeType: null,
                        color: null,
                        compact: tD,
                        declare: tD,
                        event: null,
                        face: null,
                        frame: null,
                        frameBorder: null,
                        hSpace: tN,
                        leftMargin: tN,
                        link: null,
                        longDesc: null,
                        lowSrc: null,
                        marginHeight: tN,
                        marginWidth: tN,
                        noResize: tD,
                        noHref: tD,
                        noShade: tD,
                        noWrap: tD,
                        object: null,
                        profile: null,
                        prompt: null,
                        rev: null,
                        rightMargin: tN,
                        rules: null,
                        scheme: null,
                        scrolling: tz,
                        standby: null,
                        summary: null,
                        text: null,
                        topMargin: tN,
                        valueType: null,
                        version: null,
                        vAlign: null,
                        vLink: null,
                        vSpace: tN,
                        allowTransparency: null,
                        autoCorrect: null,
                        autoSave: null,
                        disablePictureInPicture: tD,
                        disableRemotePlayback: tD,
                        prefix: null,
                        property: null,
                        results: tN,
                        security: null,
                        unselectable: null
                    }
                }),
                t1 = tW({
                    space: "svg",
                    attributes: {
                        accentHeight: "accent-height",
                        alignmentBaseline: "alignment-baseline",
                        arabicForm: "arabic-form",
                        baselineShift: "baseline-shift",
                        capHeight: "cap-height",
                        className: "class",
                        clipPath: "clip-path",
                        clipRule: "clip-rule",
                        colorInterpolation: "color-interpolation",
                        colorInterpolationFilters: "color-interpolation-filters",
                        colorProfile: "color-profile",
                        colorRendering: "color-rendering",
                        crossOrigin: "crossorigin",
                        dataType: "datatype",
                        dominantBaseline: "dominant-baseline",
                        enableBackground: "enable-background",
                        fillOpacity: "fill-opacity",
                        fillRule: "fill-rule",
                        floodColor: "flood-color",
                        floodOpacity: "flood-opacity",
                        fontFamily: "font-family",
                        fontSize: "font-size",
                        fontSizeAdjust: "font-size-adjust",
                        fontStretch: "font-stretch",
                        fontStyle: "font-style",
                        fontVariant: "font-variant",
                        fontWeight: "font-weight",
                        glyphName: "glyph-name",
                        glyphOrientationHorizontal: "glyph-orientation-horizontal",
                        glyphOrientationVertical: "glyph-orientation-vertical",
                        hrefLang: "hreflang",
                        horizAdvX: "horiz-adv-x",
                        horizOriginX: "horiz-origin-x",
                        horizOriginY: "horiz-origin-y",
                        imageRendering: "image-rendering",
                        letterSpacing: "letter-spacing",
                        lightingColor: "lighting-color",
                        markerEnd: "marker-end",
                        markerMid: "marker-mid",
                        markerStart: "marker-start",
                        navDown: "nav-down",
                        navDownLeft: "nav-down-left",
                        navDownRight: "nav-down-right",
                        navLeft: "nav-left",
                        navNext: "nav-next",
                        navPrev: "nav-prev",
                        navRight: "nav-right",
                        navUp: "nav-up",
                        navUpLeft: "nav-up-left",
                        navUpRight: "nav-up-right",
                        onAbort: "onabort",
                        onActivate: "onactivate",
                        onAfterPrint: "onafterprint",
                        onBeforePrint: "onbeforeprint",
                        onBegin: "onbegin",
                        onCancel: "oncancel",
                        onCanPlay: "oncanplay",
                        onCanPlayThrough: "oncanplaythrough",
                        onChange: "onchange",
                        onClick: "onclick",
                        onClose: "onclose",
                        onCopy: "oncopy",
                        onCueChange: "oncuechange",
                        onCut: "oncut",
                        onDblClick: "ondblclick",
                        onDrag: "ondrag",
                        onDragEnd: "ondragend",
                        onDragEnter: "ondragenter",
                        onDragExit: "ondragexit",
                        onDragLeave: "ondragleave",
                        onDragOver: "ondragover",
                        onDragStart: "ondragstart",
                        onDrop: "ondrop",
                        onDurationChange: "ondurationchange",
                        onEmptied: "onemptied",
                        onEnd: "onend",
                        onEnded: "onended",
                        onError: "onerror",
                        onFocus: "onfocus",
                        onFocusIn: "onfocusin",
                        onFocusOut: "onfocusout",
                        onHashChange: "onhashchange",
                        onInput: "oninput",
                        onInvalid: "oninvalid",
                        onKeyDown: "onkeydown",
                        onKeyPress: "onkeypress",
                        onKeyUp: "onkeyup",
                        onLoad: "onload",
                        onLoadedData: "onloadeddata",
                        onLoadedMetadata: "onloadedmetadata",
                        onLoadStart: "onloadstart",
                        onMessage: "onmessage",
                        onMouseDown: "onmousedown",
                        onMouseEnter: "onmouseenter",
                        onMouseLeave: "onmouseleave",
                        onMouseMove: "onmousemove",
                        onMouseOut: "onmouseout",
                        onMouseOver: "onmouseover",
                        onMouseUp: "onmouseup",
                        onMouseWheel: "onmousewheel",
                        onOffline: "onoffline",
                        onOnline: "ononline",
                        onPageHide: "onpagehide",
                        onPageShow: "onpageshow",
                        onPaste: "onpaste",
                        onPause: "onpause",
                        onPlay: "onplay",
                        onPlaying: "onplaying",
                        onPopState: "onpopstate",
                        onProgress: "onprogress",
                        onRateChange: "onratechange",
                        onRepeat: "onrepeat",
                        onReset: "onreset",
                        onResize: "onresize",
                        onScroll: "onscroll",
                        onSeeked: "onseeked",
                        onSeeking: "onseeking",
                        onSelect: "onselect",
                        onShow: "onshow",
                        onStalled: "onstalled",
                        onStorage: "onstorage",
                        onSubmit: "onsubmit",
                        onSuspend: "onsuspend",
                        onTimeUpdate: "ontimeupdate",
                        onToggle: "ontoggle",
                        onUnload: "onunload",
                        onVolumeChange: "onvolumechange",
                        onWaiting: "onwaiting",
                        onZoom: "onzoom",
                        overlinePosition: "overline-position",
                        overlineThickness: "overline-thickness",
                        paintOrder: "paint-order",
                        panose1: "panose-1",
                        pointerEvents: "pointer-events",
                        referrerPolicy: "referrerpolicy",
                        renderingIntent: "rendering-intent",
                        shapeRendering: "shape-rendering",
                        stopColor: "stop-color",
                        stopOpacity: "stop-opacity",
                        strikethroughPosition: "strikethrough-position",
                        strikethroughThickness: "strikethrough-thickness",
                        strokeDashArray: "stroke-dasharray",
                        strokeDashOffset: "stroke-dashoffset",
                        strokeLineCap: "stroke-linecap",
                        strokeLineJoin: "stroke-linejoin",
                        strokeMiterLimit: "stroke-miterlimit",
                        strokeOpacity: "stroke-opacity",
                        strokeWidth: "stroke-width",
                        tabIndex: "tabindex",
                        textAnchor: "text-anchor",
                        textDecoration: "text-decoration",
                        textRendering: "text-rendering",
                        typeOf: "typeof",
                        underlinePosition: "underline-position",
                        underlineThickness: "underline-thickness",
                        unicodeBidi: "unicode-bidi",
                        unicodeRange: "unicode-range",
                        unitsPerEm: "units-per-em",
                        vAlphabetic: "v-alphabetic",
                        vHanging: "v-hanging",
                        vIdeographic: "v-ideographic",
                        vMathematical: "v-mathematical",
                        vectorEffect: "vector-effect",
                        vertAdvY: "vert-adv-y",
                        vertOriginX: "vert-origin-x",
                        vertOriginY: "vert-origin-y",
                        wordSpacing: "word-spacing",
                        writingMode: "writing-mode",
                        xHeight: "x-height",
                        playbackOrder: "playbackorder",
                        timelineBegin: "timelinebegin"
                    },
                    transform: tG,
                    properties: {
                        about: t$,
                        accentHeight: tN,
                        accumulate: null,
                        additive: null,
                        alignmentBaseline: null,
                        alphabetic: tN,
                        amplitude: tN,
                        arabicForm: null,
                        ascent: tN,
                        attributeName: null,
                        attributeType: null,
                        azimuth: tN,
                        bandwidth: null,
                        baselineShift: null,
                        baseFrequency: null,
                        baseProfile: null,
                        bbox: null,
                        begin: null,
                        bias: tN,
                        by: null,
                        calcMode: null,
                        capHeight: tN,
                        className: tB,
                        clip: null,
                        clipPath: null,
                        clipPathUnits: null,
                        clipRule: null,
                        color: null,
                        colorInterpolation: null,
                        colorInterpolationFilters: null,
                        colorProfile: null,
                        colorRendering: null,
                        content: null,
                        contentScriptType: null,
                        contentStyleType: null,
                        crossOrigin: null,
                        cursor: null,
                        cx: null,
                        cy: null,
                        d: null,
                        dataType: null,
                        defaultAction: null,
                        descent: tN,
                        diffuseConstant: tN,
                        direction: null,
                        display: null,
                        dur: null,
                        divisor: tN,
                        dominantBaseline: null,
                        download: tD,
                        dx: null,
                        dy: null,
                        edgeMode: null,
                        editable: null,
                        elevation: tN,
                        enableBackground: null,
                        end: null,
                        event: null,
                        exponent: tN,
                        externalResourcesRequired: null,
                        fill: null,
                        fillOpacity: tN,
                        fillRule: null,
                        filter: null,
                        filterRes: null,
                        filterUnits: null,
                        floodColor: null,
                        floodOpacity: null,
                        focusable: null,
                        focusHighlight: null,
                        fontFamily: null,
                        fontSize: null,
                        fontSizeAdjust: null,
                        fontStretch: null,
                        fontStyle: null,
                        fontVariant: null,
                        fontWeight: null,
                        format: null,
                        fr: null,
                        from: null,
                        fx: null,
                        fy: null,
                        g1: t_,
                        g2: t_,
                        glyphName: t_,
                        glyphOrientationHorizontal: null,
                        glyphOrientationVertical: null,
                        glyphRef: null,
                        gradientTransform: null,
                        gradientUnits: null,
                        handler: null,
                        hanging: tN,
                        hatchContentUnits: null,
                        hatchUnits: null,
                        height: null,
                        href: null,
                        hrefLang: null,
                        horizAdvX: tN,
                        horizOriginX: tN,
                        horizOriginY: tN,
                        id: null,
                        ideographic: tN,
                        imageRendering: null,
                        initialVisibility: null,
                        in: null,
                        in2: null,
                        intercept: tN,
                        k: tN,
                        k1: tN,
                        k2: tN,
                        k3: tN,
                        k4: tN,
                        kernelMatrix: t$,
                        kernelUnitLength: null,
                        keyPoints: null,
                        keySplines: null,
                        keyTimes: null,
                        kerning: null,
                        lang: null,
                        lengthAdjust: null,
                        letterSpacing: null,
                        lightingColor: null,
                        limitingConeAngle: tN,
                        local: null,
                        markerEnd: null,
                        markerMid: null,
                        markerStart: null,
                        markerHeight: null,
                        markerUnits: null,
                        markerWidth: null,
                        mask: null,
                        maskContentUnits: null,
                        maskUnits: null,
                        mathematical: null,
                        max: null,
                        media: null,
                        mediaCharacterEncoding: null,
                        mediaContentEncodings: null,
                        mediaSize: tN,
                        mediaTime: null,
                        method: null,
                        min: null,
                        mode: null,
                        name: null,
                        navDown: null,
                        navDownLeft: null,
                        navDownRight: null,
                        navLeft: null,
                        navNext: null,
                        navPrev: null,
                        navRight: null,
                        navUp: null,
                        navUpLeft: null,
                        navUpRight: null,
                        numOctaves: null,
                        observer: null,
                        offset: null,
                        onAbort: null,
                        onActivate: null,
                        onAfterPrint: null,
                        onBeforePrint: null,
                        onBegin: null,
                        onCancel: null,
                        onCanPlay: null,
                        onCanPlayThrough: null,
                        onChange: null,
                        onClick: null,
                        onClose: null,
                        onCopy: null,
                        onCueChange: null,
                        onCut: null,
                        onDblClick: null,
                        onDrag: null,
                        onDragEnd: null,
                        onDragEnter: null,
                        onDragExit: null,
                        onDragLeave: null,
                        onDragOver: null,
                        onDragStart: null,
                        onDrop: null,
                        onDurationChange: null,
                        onEmptied: null,
                        onEnd: null,
                        onEnded: null,
                        onError: null,
                        onFocus: null,
                        onFocusIn: null,
                        onFocusOut: null,
                        onHashChange: null,
                        onInput: null,
                        onInvalid: null,
                        onKeyDown: null,
                        onKeyPress: null,
                        onKeyUp: null,
                        onLoad: null,
                        onLoadedData: null,
                        onLoadedMetadata: null,
                        onLoadStart: null,
                        onMessage: null,
                        onMouseDown: null,
                        onMouseEnter: null,
                        onMouseLeave: null,
                        onMouseMove: null,
                        onMouseOut: null,
                        onMouseOver: null,
                        onMouseUp: null,
                        onMouseWheel: null,
                        onOffline: null,
                        onOnline: null,
                        onPageHide: null,
                        onPageShow: null,
                        onPaste: null,
                        onPause: null,
                        onPlay: null,
                        onPlaying: null,
                        onPopState: null,
                        onProgress: null,
                        onRateChange: null,
                        onRepeat: null,
                        onReset: null,
                        onResize: null,
                        onScroll: null,
                        onSeeked: null,
                        onSeeking: null,
                        onSelect: null,
                        onShow: null,
                        onStalled: null,
                        onStorage: null,
                        onSubmit: null,
                        onSuspend: null,
                        onTimeUpdate: null,
                        onToggle: null,
                        onUnload: null,
                        onVolumeChange: null,
                        onWaiting: null,
                        onZoom: null,
                        opacity: null,
                        operator: null,
                        order: null,
                        orient: null,
                        orientation: null,
                        origin: null,
                        overflow: null,
                        overlay: null,
                        overlinePosition: tN,
                        overlineThickness: tN,
                        paintOrder: null,
                        panose1: null,
                        path: null,
                        pathLength: tN,
                        patternContentUnits: null,
                        patternTransform: null,
                        patternUnits: null,
                        phase: null,
                        ping: tB,
                        pitch: null,
                        playbackOrder: null,
                        pointerEvents: null,
                        points: null,
                        pointsAtX: tN,
                        pointsAtY: tN,
                        pointsAtZ: tN,
                        preserveAlpha: null,
                        preserveAspectRatio: null,
                        primitiveUnits: null,
                        propagate: null,
                        property: t$,
                        r: null,
                        radius: null,
                        referrerPolicy: null,
                        refX: null,
                        refY: null,
                        rel: t$,
                        rev: t$,
                        renderingIntent: null,
                        repeatCount: null,
                        repeatDur: null,
                        requiredExtensions: t$,
                        requiredFeatures: t$,
                        requiredFonts: t$,
                        requiredFormats: t$,
                        resource: null,
                        restart: null,
                        result: null,
                        rotate: null,
                        rx: null,
                        ry: null,
                        scale: null,
                        seed: null,
                        shapeRendering: null,
                        side: null,
                        slope: null,
                        snapshotTime: null,
                        specularConstant: tN,
                        specularExponent: tN,
                        spreadMethod: null,
                        spacing: null,
                        startOffset: null,
                        stdDeviation: null,
                        stemh: null,
                        stemv: null,
                        stitchTiles: null,
                        stopColor: null,
                        stopOpacity: null,
                        strikethroughPosition: tN,
                        strikethroughThickness: tN,
                        string: null,
                        stroke: null,
                        strokeDashArray: t$,
                        strokeDashOffset: null,
                        strokeLineCap: null,
                        strokeLineJoin: null,
                        strokeMiterLimit: tN,
                        strokeOpacity: tN,
                        strokeWidth: null,
                        style: null,
                        surfaceScale: tN,
                        syncBehavior: null,
                        syncBehaviorDefault: null,
                        syncMaster: null,
                        syncTolerance: null,
                        syncToleranceDefault: null,
                        systemLanguage: t$,
                        tabIndex: tN,
                        tableValues: null,
                        target: null,
                        targetX: tN,
                        targetY: tN,
                        textAnchor: null,
                        textDecoration: null,
                        textRendering: null,
                        textLength: null,
                        timelineBegin: null,
                        title: null,
                        transformBehavior: null,
                        type: null,
                        typeOf: t$,
                        to: null,
                        transform: null,
                        u1: null,
                        u2: null,
                        underlinePosition: tN,
                        underlineThickness: tN,
                        unicode: null,
                        unicodeBidi: null,
                        unicodeRange: null,
                        unitsPerEm: tN,
                        values: null,
                        vAlphabetic: tN,
                        vMathematical: tN,
                        vectorEffect: null,
                        vHanging: tN,
                        vIdeographic: tN,
                        version: null,
                        vertAdvY: tN,
                        vertOriginX: tN,
                        vertOriginY: tN,
                        viewBox: null,
                        viewTarget: null,
                        visibility: null,
                        width: null,
                        widths: null,
                        wordSpacing: null,
                        writingMode: null,
                        x: null,
                        x1: null,
                        x2: null,
                        xChannelSelector: null,
                        xHeight: tN,
                        y: null,
                        y1: null,
                        y2: null,
                        yChannelSelector: null,
                        z: null,
                        zoomAndPan: null
                    }
                }),
                t6 = tO([tK, tJ, tY, tX, t0], "html"),
                t3 = tO([tK, tJ, tY, tX, t1], "svg");

            function t2(e) {
                if (e.allowedElements && e.disallowedElements) throw TypeError("Only one of `allowedElements` and `disallowedElements` should be defined");
                if (e.allowedElements || e.disallowedElements || e.allowElement) return t => {
                    tu(t, "element", (t, n, r) => {
                        let i;
                        if (e.allowedElements ? i = !e.allowedElements.includes(t.tagName) : e.disallowedElements && (i = e.disallowedElements.includes(t.tagName)), !i && e.allowElement && "number" == typeof n && (i = !e.allowElement(t, n, r)), i && "number" == typeof n) return e.unwrapDisallowed && t.children ? r.children.splice(n, 1, ...t.children) : r.children.splice(n, 1), n
                    })
                }
            }
            let t9 = ["http", "https", "mailto", "tel"];
            var t4 = n(9864);

            function t5(e) {
                var t = e && "object" == typeof e && "text" === e.type ? e.value || "" : e;
                return "string" == typeof t && "" === t.replace(/[ \t\n\f\r]/g, "")
            }
            let t7 = /^data[-\w.:]+$/i,
                t8 = /-[a-z]/g,
                ne = /[A-Z]/g;

            function nt(e) {
                return "-" + e.toLowerCase()
            }

            function nn(e) {
                return e.charAt(1).toUpperCase()
            }
            let nr = {
                classId: "classID",
                dataType: "datatype",
                itemId: "itemID",
                strokeDashArray: "strokeDasharray",
                strokeDashOffset: "strokeDashoffset",
                strokeLineCap: "strokeLinecap",
                strokeLineJoin: "strokeLinejoin",
                strokeMiterLimit: "strokeMiterlimit",
                typeOf: "typeof",
                xLinkActuate: "xlinkActuate",
                xLinkArcRole: "xlinkArcrole",
                xLinkHref: "xlinkHref",
                xLinkRole: "xlinkRole",
                xLinkShow: "xlinkShow",
                xLinkTitle: "xlinkTitle",
                xLinkType: "xlinkType",
                xmlnsXLink: "xmlnsXlink"
            };
            var ni = n(7848);
            let no = {}.hasOwnProperty,
                nl = new Set(["table", "thead", "tbody", "tfoot", "tr"]);

            function nu(e, t) {
                let n = [],
                    r = -1,
                    i;
                for (; ++r < t.children.length;) "element" === (i = t.children[r]).type ? n.push(na(e, i, r, t)) : "text" === i.type ? "element" === t.type && nl.has(t.tagName) && t5(i) || n.push(i.value) : "raw" !== i.type || e.options.skipHtml || n.push(i.value);
                return n
            }

            function na(e, t, n, r) {
                var i;
                let l = e.options,
                    u = e.schema,
                    a = t.tagName,
                    c = {},
                    s = u,
                    f;
                if ("html" === u.space && "svg" === a && (s = t3, e.schema = s), t.properties)
                    for (f in t.properties) no.call(t.properties, f) && ns(c, f, t.properties[f], e);
                ("ol" === a || "ul" === a) && e.listDepth++;
                let d = nu(e, t);
                ("ol" === a || "ul" === a) && e.listDepth--, e.schema = u;
                let p = t.position || {
                        start: {
                            line: null,
                            column: null,
                            offset: null
                        },
                        end: {
                            line: null,
                            column: null,
                            offset: null
                        }
                    },
                    h = l.components && no.call(l.components, a) ? l.components[a] : a,
                    m = "string" == typeof h || h === o.Fragment;
                if (!t4.isValidElementType(h)) throw TypeError(`Component for name \`${a}\` not defined or is not renderable`);
                if (c.key = [a, p.start.line, p.start.column, n].join("-"), "a" === a && l.linkTarget && (c.target = "function" == typeof l.linkTarget ? l.linkTarget(String(c.href || ""), t.children, "string" == typeof c.title ? c.title : null) : l.linkTarget), "a" === a && l.transformLinkUri && (c.href = l.transformLinkUri(String(c.href || ""), t.children, "string" == typeof c.title ? c.title : null)), m || "code" !== a || "element" !== r.type || "pre" === r.tagName || (c.inline = !0), m || "h1" !== a && "h2" !== a && "h3" !== a && "h4" !== a && "h5" !== a && "h6" !== a || (c.level = Number.parseInt(a.charAt(1), 10)), "img" === a && l.transformImageUri && (c.src = l.transformImageUri(String(c.src || ""), String(c.alt || ""), "string" == typeof c.title ? c.title : null)), !m && "li" === a && "element" === r.type) {
                    let g = function(e) {
                        let t = -1;
                        for (; ++t < e.children.length;) {
                            let n = e.children[t];
                            if ("element" === n.type && "input" === n.tagName) return n
                        }
                        return null
                    }(t);
                    c.checked = g && g.properties ? Boolean(g.properties.checked) : null, c.index = nc(r, t), c.ordered = "ol" === r.tagName
                }
                return m || "ol" !== a && "ul" !== a || (c.ordered = "ol" === a, c.depth = e.listDepth), "td" !== a && "th" !== a || (c.align && (c.style || (c.style = {}), c.style.textAlign = c.align, delete c.align), m || (c.isHeader = "th" === a)), m || "tr" !== a || "element" !== r.type || (c.isHeader = Boolean("thead" === r.tagName)), l.sourcePos && (c["data-sourcepos"] = (i = p, [i.start.line, ":", i.start.column, "-", i.end.line, ":", i.end.column].map(e => String(e)).join(""))), !m && l.rawSourcePos && (c.sourcePosition = t.position), !m && l.includeElementIndex && (c.index = nc(r, t), c.siblingCount = nc(r)), m || (c.node = t), d.length > 0 ? o.createElement(h, c, d) : o.createElement(h, c)
            }

            function nc(e, t) {
                let n = -1,
                    r = 0;
                for (; ++n < e.children.length && e.children[n] !== t;) "element" === e.children[n].type && r++;
                return r
            }

            function ns(e, t, n, r) {
                let i = function(e, t) {
                        let n = tF(t),
                            r = t,
                            i = tI;
                        if (n in e.normal) return e.property[e.normal[n]];
                        if (n.length > 4 && "data" === n.slice(0, 4) && t7.test(t)) {
                            if ("-" === t.charAt(4)) {
                                let o = t.slice(5).replace(t8, nn);
                                r = "data" + o.charAt(0).toUpperCase() + o.slice(1)
                            } else {
                                let l = t.slice(4);
                                if (!t8.test(l)) {
                                    let u = l.replace(ne, nt);
                                    "-" !== u.charAt(0) && (u = "-" + u), t = "data" + u
                                }
                            }
                            i = tV
                        }
                        return new i(r, t)
                    }(r.schema, t),
                    o = n;
                if (null != o && o == o) {
                    if (Array.isArray(o)) {
                        var l;
                        o = i.commaSeparated ? function(e, t) {
                            let n = {},
                                r = "" === e[e.length - 1] ? [...e, ""] : e;
                            return r.join((n.padRight ? " " : "") + "," + (!1 === n.padLeft ? "" : " ")).trim()
                        }(o) : (l = o).join(" ").trim()
                    }
                    "style" === i.property && "string" == typeof o && (o = function(e) {
                        let t = {};
                        try {
                            ni(e, function(e, n) {
                                let r = "-ms-" === e.slice(0, 4) ? `ms-${e.slice(4)}` : e;
                                t[r.replace(/-([a-z])/g, nf)] = n
                            })
                        } catch {}
                        return t
                    }(o)), i.space && i.property ? e[no.call(nr, i.property) ? nr[i.property] : i.property] = o : i.attribute && (e[i.attribute] = o)
                }
            }

            function nf(e, t) {
                return t.toUpperCase()
            }
            let nd = {}.hasOwnProperty,
                np = {
                    plugins: {
                        to: "plugins",
                        id: "change-plugins-to-remarkplugins"
                    },
                    renderers: {
                        to: "components",
                        id: "change-renderers-to-components"
                    },
                    astPlugins: {
                        id: "remove-buggy-html-in-markdown-parser"
                    },
                    allowDangerousHtml: {
                        id: "remove-buggy-html-in-markdown-parser"
                    },
                    escapeHtml: {
                        id: "remove-buggy-html-in-markdown-parser"
                    },
                    source: {
                        to: "children",
                        id: "change-source-to-children"
                    },
                    allowNode: {
                        to: "allowElement",
                        id: "replace-allownode-allowedtypes-and-disallowedtypes"
                    },
                    allowedTypes: {
                        to: "allowedElements",
                        id: "replace-allownode-allowedtypes-and-disallowedtypes"
                    },
                    disallowedTypes: {
                        to: "disallowedElements",
                        id: "replace-allownode-allowedtypes-and-disallowedtypes"
                    },
                    includeNodeIndex: {
                        to: "includeElementIndex",
                        id: "change-includenodeindex-to-includeelementindex"
                    }
                };

            function nh(e) {
                for (let t in np)
                    if (nd.call(np, t) && nd.call(e, t)) {
                        let n = np[t];
                        console.warn(`[react-markdown] Warning: please ${n.to?`use \`${n.to}\` instead of`:"remove"} \`${t}\` (see <https://github.com/remarkjs/react-markdown/blob/main/changelog.md#${n.id}> for more info)`), delete np[t]
                    }
                let r = S().use(tt).use(e.remarkPlugins || []).use(tM, { ...e.remarkRehypeOptions,
                        allowDangerousHtml: !0
                    }).use(e.rehypePlugins || []).use(t2, e),
                    i = new y;
                "string" == typeof e.children ? i.value = e.children : void 0 !== e.children && null !== e.children && console.warn(`[react-markdown] Warning: please pass a string as \`children\` (not: \`${e.children}\`)`);
                let l = r.runSync(r.parse(i), i);
                if ("root" !== l.type) throw TypeError("Expected a `root` node");
                let u = o.createElement(o.Fragment, {}, nu({
                    options: e,
                    schema: t6,
                    listDepth: 0
                }, l));
                return e.className && (u = o.createElement("div", {
                    className: e.className
                }, u)), u
            }
            nh.defaultProps = {
                transformLinkUri: function(e) {
                    let t = (e || "").trim(),
                        n = t.charAt(0);
                    if ("#" === n || "/" === n) return t;
                    let r = t.indexOf(":");
                    if (-1 === r) return t;
                    let i = -1;
                    for (; ++i < t9.length;) {
                        let o = t9[i];
                        if (r === o.length && t.slice(0, o.length).toLowerCase() === o) return t
                    }
                    return -1 !== (i = t.indexOf("?")) && r > i || -1 !== (i = t.indexOf("#")) && r > i ? t : "javascript:void(0)"
                }
            }, nh.propTypes = {
                children: tL.string,
                className: tL.string,
                allowElement: tL.func,
                allowedElements: tL.arrayOf(tL.string),
                disallowedElements: tL.arrayOf(tL.string),
                unwrapDisallowed: tL.bool,
                remarkPlugins: tL.arrayOf(tL.oneOfType([tL.object, tL.func, tL.arrayOf(tL.oneOfType([tL.bool, tL.string, tL.object, tL.func, tL.arrayOf(tL.any)]))])),
                rehypePlugins: tL.arrayOf(tL.oneOfType([tL.object, tL.func, tL.arrayOf(tL.oneOfType([tL.bool, tL.string, tL.object, tL.func, tL.arrayOf(tL.any)]))])),
                sourcePos: tL.bool,
                rawSourcePos: tL.bool,
                skipHtml: tL.bool,
                includeElementIndex: tL.bool,
                transformLinkUri: tL.oneOfType([tL.func, tL.bool]),
                linkTarget: tL.oneOfType([tL.func, tL.string]),
                transformImageUri: tL.func,
                components: tL.object
            }
        },
        3984: function(e, t, n) {
            "use strict";
            n.d(t, {
                $P: function() {
                    return u
                },
                ve: function() {
                    return c
                },
                w_: function() {
                    return l
                }
            });
            var r = n(2805),
                i = n(9071),
                o = n(8860),
                l = class {
                    constructor(e) {
                        this.I = e, this.m = null, this.h = null
                    }
                    setTarget(e) {
                        this.m = e
                    }
                    getPlayer(e) {
                        return this.h || (e ? ? this.m) ? .dispatchEvent(new r.yb("find-media-player", {
                            detail: e => void(this.h = e),
                            bubbles: !0,
                            composed: !0
                        })), this.h
                    }
                    setPlayer(e) {
                        this.h = e
                    }
                    startLoading(e) {
                        this.d("media-start-loading", e)
                    }
                    play(e) {
                        this.d("media-play-request", e)
                    }
                    pause(e) {
                        this.d("media-pause-request", e)
                    }
                    mute(e) {
                        this.d("media-mute-request", e)
                    }
                    unmute(e) {
                        this.d("media-unmute-request", e)
                    }
                    enterFullscreen(e, t) {
                        this.d("media-enter-fullscreen-request", t, e)
                    }
                    exitFullscreen(e, t) {
                        this.d("media-exit-fullscreen-request", t, e)
                    }
                    seeking(e, t) {
                        this.d("media-seeking-request", t, e)
                    }
                    seek(e, t) {
                        this.d("media-seek-request", t, e)
                    }
                    changeVolume(e, t) {
                        this.d("media-volume-change-request", t, e)
                    }
                    resumeUserIdle(e) {
                        this.d("media-resume-user-idle-request", e)
                    }
                    pauseUserIdle(e) {
                        this.d("media-pause-user-idle-request", e)
                    }
                    showPoster(e) {
                        this.d("media-show-poster-request", e)
                    }
                    hidePoster(e) {
                        this.d("media-hide-poster-request", e)
                    }
                    togglePaused(e) {
                        let t = this.getPlayer(e ? .target);
                        t && (t.state.paused ? this.play(e) : this.pause(e))
                    }
                    toggleMuted(e) {
                        let t = this.getPlayer(e ? .target);
                        t && (t.state.muted ? this.unmute(e) : this.mute(e))
                    }
                    toggleFullscreen(e, t) {
                        let n = this.getPlayer(t ? .target);
                        n && (n.state.fullscreen ? this.exitFullscreen(e, t) : this.enterFullscreen(e, t))
                    }
                    d(e, t, n) {
                        let i = new r.yb(e, {
                                bubbles: !0,
                                composed: !0,
                                detail: n,
                                trigger: t
                            }),
                            o = t ? .target ? ? this.m;
                        o ? .dispatchEvent(i)
                    }
                    J(e) {}
                };

            function u(e, t = "preconnect") {
                let n = document.querySelector(`link[href="${e}"]`);
                if (!(0, i.Ft)(n)) return !0;
                let r = document.createElement("link");
                return r.rel = t, r.href = e, r.crossOrigin = "true", document.head.append(r), !0
            }
            var a = {};

            function c(e) {
                if (a[e]) return a[e].promise;
                let t = (0, o.deferredPromise)(),
                    n = document.querySelector(`script[src="${e}"]`);
                if (!(0, i.Ft)(n)) return t.resolve(), t.promise;
                let r = document.createElement("script");
                return r.src = e, r.onload = () => {
                    t.resolve(), delete a[e]
                }, r.onerror = () => {
                    t.reject(), delete a[e]
                }, setTimeout(() => document.head.append(r), 0), t.promise
            }
        },
        6443: function(e, t, n) {
            "use strict";
            n.d(t, {
                G: function() {
                    return o
                },
                _: function() {
                    return i
                }
            });
            var r = n(9071),
                i = (0, r.kr)();

            function o() {
                return (0, r.qp)(i)
            }
        },
        6291: function(e, t, n) {
            "use strict";

            function r(e, t = 2) {
                return Number(e.toFixed(t))
            }

            function i(e) {
                return String(e).split(".")[1] ? .length ? ? 0
            }

            function o(e, t, n) {
                return Math.max(e, Math.min(n, t))
            }
            n.d(t, {
                IV: function() {
                    return o
                },
                NM: function() {
                    return r
                },
                YZ: function() {
                    return i
                }
            })
        },
        7066: function(e, t, n) {
            "use strict";
            n.d(t, {
                n: function() {
                    return r
                }
            });
            var r = function(e, t, n) {
                var r = null,
                    i = null,
                    o = n && n.leading,
                    l = n && n.trailing;
                null == o && (o = !0), null == l && (l = !o), !0 == o && (l = !1);
                var u = function() {
                        r && (clearTimeout(r), r = null)
                    },
                    a = function() {
                        var e = i;
                        u(), e && e()
                    },
                    c = function() {
                        var n = o && !r,
                            u = this,
                            a = arguments;
                        if (i = function() {
                                return e.apply(u, a)
                            }, r || (r = setTimeout(function() {
                                if (r = null, l) return i()
                            }, t)), n) return n = !1, i()
                    };
                return c.cancel = u, c.flush = a, c
            }
        },
        4692: function(e, t, n) {
            "use strict";
            n.d(t, {
                Go: function() {
                    return o
                },
                Ig: function() {
                    return c
                },
                j2: function() {
                    return f
                },
                jn: function() {
                    return u
                },
                kq: function() {
                    return s
                },
                rf: function() {
                    return a
                },
                sc: function() {
                    return l
                },
                wE: function() {
                    return i
                }
            });
            var r = n(9071),
                i = /\.(m4a|m4b|mp4a|mpga|mp2|mp2a|mp3|m2a|m3a|wav|weba|aac|oga|spx)($|\?)/i,
                o = new Set(["audio/mpeg", "audio/ogg", "audio/3gp", "audio/mp4", "audio/webm", "audio/flac"]),
                l = /\.(mp4|og[gv]|webm|mov|m4v)(#t=[,\d+]+)?($|\?)/i,
                u = new Set(["video/mp4", "video/webm", "video/3gp", "video/ogg", "video/avi", "video/mpeg"]),
                a = /\.(m3u8)($|\?)/i,
                c = new Set(["application/vnd.apple.mpegurl", "audio/mpegurl", "audio/x-mpegurl", "application/x-mpegurl", "video/x-mpegurl", "video/mpegurl", "application/mpegurl"]);

            function s({
                src: e,
                type: t
            }) {
                return (0, r.HD)(e) && a.test(e) || c.has(t)
            }

            function f(e) {
                return !(0, r.o8)(window.MediaStream) && e instanceof window.MediaStream
            }
        },
        2262: function(e, t, n) {
            "use strict";
            n.d(t, {
                O6: function() {
                    return a
                },
                cj: function() {
                    return o
                },
                gz: function() {
                    return u
                },
                s$: function() {
                    return l
                },
                tF: function() {
                    return c
                }
            });
            var r = n(9071),
                i = navigator ? .userAgent.toLowerCase(),
                o = /iphone|ipad|ipod|ios|crios|fxios/i.test(i),
                l = !!window.safari || o;

            function u() {
                return !(0, r.o8)(screen.orientation) && (0, r.mf)(screen.orientation.lock) && (0, r.mf)(screen.orientation.unlock)
            }

            function a() {
                let e = document.createElement("video");
                return e.canPlayType("application/vnd.apple.mpegurl").length > 0
            }

            function c() {
                let e = window ? .MediaSource ? ? window ? .WebKitMediaSource;
                if ((0, r.o8)(e)) return !1;
                let t = e && (0, r.mf)(e.isTypeSupported) && e.isTypeSupported('video/mp4; codecs="avc1.42E01E,mp4a.40.2"'),
                    n = window ? .SourceBuffer ? ? window ? .WebKitSourceBuffer,
                    i = (0, r.o8)(n) || !(0, r.o8)(n.prototype) && (0, r.mf)(n.prototype.appendBuffer) && (0, r.mf)(n.prototype.remove);
                return !!t && !!i
            }
        },
        1937: function(e, t, n) {
            "use strict";
            n.d(t, {
                DR: function() {
                    return B
                },
                Gn: function() {
                    return y
                },
                a4: function() {
                    return Y
                },
                vT: function() {
                    return Q
                }
            });
            var r = n(4692),
                i = n(3984),
                o = n(7066),
                l = n(2262),
                u = n(6291),
                a = n(6443),
                c = n(9071),
                s = n(2805),
                f = n(8860),
                d = n(6765),
                p = n(629);

            function h(e, t, n, r) {
                return ! function(e, t, n) {
                    if (!(0, c.hj)(t) || t < 0 || t > n) throw Error(`Failed to execute '${e}' on 'TimeRanges': The index provided (${t}) is non-numeric or out of bounds (0-${n}).`)
                }(e, r, n.length - 1), n[r][t]
            }

            function m(e) {
                if ((0, c.o8)(e) || 0 === e.length) {
                    let t = () => {
                        throw Error("This TimeRanges object is empty")
                    };
                    return {
                        length: 0,
                        start: t,
                        end: t
                    }
                }
                return {
                    length: e.length,
                    start: h.bind(null, "start", 0, e),
                    end: h.bind(null, "end", 1, e)
                }
            }

            function g(e, t) {
                return (0, c.kJ)(e) ? m(e) : (0, c.o8)(e) || (0, c.o8)(t) ? m() : m([
                    [e, t]
                ])
            }
            var y = (0, c.MT)({
                    autoplay: !1,
                    autoplayError: void 0,
                    buffered: g(),
                    duration: 0,
                    canLoad: !1,
                    canPlay: !1,
                    canFullscreen: !1,
                    controls: !1,
                    poster: "",
                    currentTime: 0,
                    ended: !1,
                    error: void 0,
                    fullscreen: !1,
                    userIdle: !1,
                    loop: !1,
                    live: !1,
                    logLevel: "silent",
                    media: "unknown",
                    muted: !1,
                    paused: !0,
                    played: g(),
                    playing: !1,
                    playsinline: !1,
                    preload: "metadata",
                    seekable: g(),
                    seeking: !1,
                    source: {
                        src: "",
                        type: ""
                    },
                    sources: [],
                    started: !1,
                    view: "video",
                    volume: 1,
                    waiting: !1,
                    get currentSrc() {
                        return this.source
                    },
                    get bufferedAmount() {
                        let v = this.buffered;
                        return 0 === v.length ? 0 : v.end(v.length - 1)
                    },
                    get seekableAmount() {
                        let b = this.seekable;
                        return 0 === b.length ? 0 : b.end(b.length - 1)
                    },
                    attemptingAutoplay: !1,
                    canLoadPoster: null
                }),
                x = new Set(["autoplay", "canFullscreen", "canLoad", "controls", "loop", "logLevel", "muted", "playsinline", "preload", "poster", "source", "sources", "view", "volume", "canLoadPoster"]);

            function k(e) {
                y.reset(e, e => !x.has(e)), (0, d.Ky)()
            }
            var w = class {
                    constructor() {
                        this.i = !1, this.n = (0, f.deferredPromise)(), this.a = new Map
                    }
                    get B() {
                        return this.a.size
                    }
                    get K() {
                        return this.i
                    }
                    async L() {
                        this.i || await this.n.promise
                    }
                    b(e, t) {
                        if (this.i) {
                            t();
                            return
                        }
                        this.a.delete(e), this.a.set(e, t)
                    }
                    o(e) {
                        this.a.get(e) ? .(), this.a.delete(e)
                    }
                    p() {
                        this.t(), this.i = !0, this.a.size > 0 && this.t()
                    }
                    u() {
                        this.i = !1
                    }
                    v() {
                        this.u(), this.a.clear(), this.w()
                    }
                    t() {
                        for (let e of this.a.keys()) this.o(e);
                        this.w()
                    }
                    w() {
                        this.n.resolve(), this.n = (0, f.deferredPromise)()
                    }
                },
                E = {
                    fullscreenEnabled: 0,
                    fullscreenElement: 1,
                    requestFullscreen: 2,
                    exitFullscreen: 3,
                    fullscreenchange: 4,
                    fullscreenerror: 5,
                    fullscreen: 6
                },
                S = ["webkitFullscreenEnabled", "webkitFullscreenElement", "webkitRequestFullscreen", "webkitExitFullscreen", "webkitfullscreenchange", "webkitfullscreenerror", "-webkit-full-screen"],
                C = ["mozFullScreenEnabled", "mozFullScreenElement", "mozRequestFullScreen", "mozCancelFullScreen", "mozfullscreenchange", "mozfullscreenerror", "-moz-full-screen"],
                A = ["msFullscreenEnabled", "msFullscreenElement", "msRequestFullscreen", "msExitFullscreen", "MSFullscreenChange", "MSFullscreenError", "-ms-fullscreen"],
                P = "undefined" != typeof window && void 0 !== window.document ? window.document : {},
                M = "fullscreenEnabled" in P && Object.keys(E) || S[0] in P && S || C[0] in P && C || A[0] in P && A || [],
                L = {
                    requestFullscreen: function(e) {
                        return e[M[E.requestFullscreen]]()
                    },
                    requestFullscreenFunction: function(e) {
                        return e[M[E.requestFullscreen]]
                    },
                    get exitFullscreen() {
                        return P[M[E.exitFullscreen]].bind(P)
                    },
                    get fullscreenPseudoClass() {
                        return ":" + M[E.fullscreen]
                    },
                    addEventListener: function(e, t, n) {
                        return P.addEventListener(M[E[e]], t, n)
                    },
                    removeEventListener: function(e, t, n) {
                        return P.removeEventListener(M[E[e]], t, n)
                    },
                    get fullscreenEnabled() {
                        return Boolean(P[M[E.fullscreenEnabled]])
                    },
                    set fullscreenEnabled(val) {},
                    get fullscreenElement() {
                        return P[M[E.fullscreenElement]]
                    },
                    set fullscreenElement(val) {},
                    get onfullscreenchange() {
                        return P[("on" + M[E.fullscreenchange]).toLowerCase()]
                    },
                    set onfullscreenchange(handler) {
                        return P[("on" + M[E.fullscreenchange]).toLowerCase()] = handler
                    },
                    get onfullscreenerror() {
                        return P[("on" + M[E.fullscreenerror]).toLowerCase()]
                    },
                    set onfullscreenerror(handler) {
                        return P[("on" + M[E.fullscreenerror]).toLowerCase()] = handler
                    }
                };

            function T() {
                return L.fullscreenEnabled
            }

            function O(e) {
                if (L.fullscreenElement === e) return !0;
                try {
                    return e.matches(L.fullscreenPseudoClass)
                } catch (t) {
                    return !1
                }
            }
            async function F(e) {
                if (!(!e || O(e))) return j(), L.requestFullscreen(e)
            }
            async function I(e) {
                if (e && O(e)) return j(), L.exitFullscreen()
            }

            function j() {
                if (!T()) throw Error("[vidstack] no fullscreen API")
            }
            var D = (0, l.gz)();

            function z() {
                if (D) throw Error("[vidstack] no orientation API")
            }

            function R() {
                return window.screen ? .orientation ? .type
            }
            var N = class {
                constructor() {
                    this.a = new Map
                }
                b(e, t) {
                    this.a.has(e) || this.a.set(e, new Set), this.a.get(e).add(t)
                }
                o(e, t) {
                    let n = this.a.get(e);
                    if (n)
                        for (let r of n) t(r);
                    this.a.delete(e)
                }
                C(e) {
                    this.a.delete(e)
                }
                B(e) {
                    return this.a.get(e) ? .size ? ? 0
                }
                v() {
                    this.a.clear()
                }
            };

            function B(e) {
                return e instanceof Error ? e : Error(JSON.stringify(e))
            }
            var _ = ["pointerup", "pointermove", "focus", "keydown", "playing"];

            function $() {
                throw Error("[vidstack] media not ready")
            }
            var H = class {
                    constructor() {
                        this.a = new N, this.k = (0, d.td)(!1), this.e = (0, d.td)(!1), this.f = (0, d.td)(!1)
                    }
                },
                q = new Set(["autoplay", "autoplay-fail", "can-load", "sources-change", "source-change", "load-start", "abort", "error", "loaded-metadata", "loaded-data", "can-play", "play", "play-fail", "pause", "playing", "seeking", "seeked", "waiting"]),
                V = (0, p.mT)('<!$><audio preload="none"></audio>'),
                U = class {
                    canPlay({
                        src: e,
                        type: t
                    }) {
                        return (0, c.HD)(e) ? r.wE.test(e) || r.Go.has(t) || e.startsWith("blob:") && "audio/object" === t : "audio/object" === t
                    }
                    mediaType() {
                        return "audio"
                    }
                    async load() {
                        return new(await n.e(924).then(n.bind(n, 8924))).AudioProvider(this.A)
                    }
                    render(e) {
                        let t = () => e.controls;
                        return (() => {
                            let [e, n] = (0, p.bG)(V);
                            return (0, p.t4)(() => (0, p.S1)(e, "controls", t())), (0, p.lj)(e, e => void(this.A = e)), e
                        })()
                    }
                },
                Z = (0, p.mT)('<!$><video preload="none"></video>'),
                W = class {
                    canPlay(e) {
                        return (0, c.HD)(e.src) ? r.sc.test(e.src) || r.jn.has(e.type) || e.src.startsWith("blob:") && "video/object" === e.type || (0, r.kq)(e) && (0, l.O6)() : "video/object" === e.type
                    }
                    mediaType() {
                        return "video"
                    }
                    async load(e) {
                        return new(await n.e(51).then(n.bind(n, 7051))).VideoProvider(this.q, e)
                    }
                    render(e) {
                        let t = () => e.controls,
                            n = () => e.poster && !0 === e.canLoadPoster ? e.poster : null;
                        return (() => {
                            let [e, r] = (0, p.bG)(Z);
                            return (0, p.t4)(() => (0, p.S1)(e, "controls", t())), (0, p.t4)(() => (0, p.S1)(e, "poster", n())), (0, p.lj)(e, e => void(this.q = e)), e
                        })()
                    }
                },
                J = class extends W {
                    preconnect() {
                        (0, i.$P)("https://cdn.jsdelivr.net", "preconnect")
                    }
                    canPlay({
                        src: e,
                        type: t
                    }) {
                        return J.supported && (0, c.HD)(e) && (r.rf.test(e) || r.Ig.has(t))
                    }
                    async load(e) {
                        return new(await n.e(378).then(n.bind(n, 3378))).HLSProvider(this.q, e)
                    }
                },
                K = J;
            K.supported = (0, l.tF)();
            var G = ["autoplay", "autoplayError", "canFullscreen", "canLoad", "canPlay", "ended", "error", "fullscreen", "loop", "media", "muted", "paused", "playing", "playsinline", "seeking", "started", "userIdle", "view", "waiting"],
                Q = Symbol(0),
                Y = (0, p.MW)({
                    tagName: "media-player",
                    props: {
                        autoplay: {
                            initial: !1
                        },
                        aspectRatio: {
                            initial: null,
                            type: {
                                from(e) {
                                    if (!e) return null;
                                    let [t, n] = e.split("/").map(Number);
                                    return t / n
                                }
                            }
                        },
                        controls: {
                            initial: !1
                        },
                        currentTime: {
                            initial: 0
                        },
                        fullscreenOrientation: {},
                        load: {
                            initial: "visible"
                        },
                        logLevel: {
                            initial: "silent"
                        },
                        loop: {
                            initial: !1
                        },
                        muted: {
                            initial: !1
                        },
                        paused: {
                            initial: !0
                        },
                        playsinline: {
                            initial: !1
                        },
                        poster: {
                            initial: ""
                        },
                        preload: {
                            initial: "metadata"
                        },
                        src: {
                            initial: ""
                        },
                        userIdleDelay: {
                            initial: 2e3
                        },
                        view: {
                            initial: "video"
                        },
                        volume: {
                            initial: 1
                        }
                    },
                    construct() {
                        this[Q] = (0, d.td)([]);
                        let e = this.addEventListener;
                        this.addEventListener = function(t, n, r) {
                            return t.startsWith("hls-") && this[Q].set(e => [...e, t]), e.call(this, t, n, r)
                        }
                    },
                    setup({
                        host: e,
                        props: t,
                        accessors: r
                    }) {
                        let h = (0, d.bR)(),
                            m = function(e) {
                                var t, r, l;
                                let h = {
                                    $player: (0, d.td)(null),
                                    $loader: (0, d.td)(null),
                                    $provider: (0, d.td)(null),
                                    $store: y.create()
                                };
                                (0, c.qN)(a._, h), h.remote = new i.w_(void 0);
                                let m = new H,
                                    g = function({
                                        $player: e,
                                        $loader: t,
                                        $provider: n,
                                        $store: r,
                                        logger: i
                                    }, l) {
                                        var u, a, d, h, m, g, y, v;
                                        let b = (0, f.useDisposalBin)(),
                                            x = new Map,
                                            w = !0,
                                            E, S = !1,
                                            C;
                                        (0, p.Qt)(() => {
                                            e() ? .setAttribute("aria-busy", "true")
                                        }), (0, c.cE)(() => {
                                            let t = e();
                                            t && ((0, s.yl)(t, "fullscreen-change", T), (0, s.yl)(t, "fullscreen-error", O))
                                        }), (0, c.cE)(() => {
                                            n() || (P(), k(r), b.empty(), l.a.v(), w = !0)
                                        });
                                        let A = {
                                            "provider-loader-change": function(e) {
                                                t.set(e.detail)
                                            },
                                            "provider-change": function(e) {
                                                n.set(e.detail)
                                            },
                                            autoplay: function(e) {
                                                (0, s.ZM)(e, x.get("play")), (0, s.ZM)(e, x.get("can-play")), r.autoplayError = void 0
                                            },
                                            "autoplay-fail": function(e) {
                                                (0, s.ZM)(e, x.get("play-fail")), (0, s.ZM)(e, x.get("can-play")), r.autoplayError = e.detail, P()
                                            },
                                            "can-load": function(e) {
                                                r.canLoad = !0, x.set("can-load", e), F("load", e)
                                            },
                                            "can-play-through": function(e) {
                                                r.canPlay = !0, r.duration = e.detail.duration, (0, s.ZM)(e, x.get("can-play"))
                                            },
                                            "can-play": function(t) {
                                                t.trigger ? .type !== "loadedmetadata" && (0, s.ZM)(t, x.get("loaded-metadata")), r.canPlay = !0, r.duration = t.detail.duration, e() ? .setAttribute("aria-busy", "false")
                                            },
                                            "duration-change": function(e) {
                                                let t = e.detail;
                                                r.duration = isNaN(t) ? 0 : t
                                            },
                                            "load-start": function(e) {
                                                (0, s.ZM)(e, x.get("source-change"))
                                            },
                                            "loaded-data": function(e) {
                                                (0, s.ZM)(e, x.get("load-start"))
                                            },
                                            "loaded-metadata": function(e) {
                                                (0, s.ZM)(e, x.get("load-start"))
                                            },
                                            "media-change": function(e) {
                                                (0, s.ZM)(e, x.get("source-change")), r.media = e.detail, r.live = e.detail.includes("live")
                                            },
                                            "play-fail": function(e) {
                                                (0, s.ZM)(e, x.get("play")), F("play", e), r.paused = !0, r.playing = !1, P()
                                            },
                                            "source-change": function(t) {
                                                if ((0, s.ZM)(t, x.get("sources-change")), r.source = t.detail, e() ? .setAttribute("aria-busy", "true"), w) {
                                                    w = !1;
                                                    return
                                                }
                                                P(), k(r), x.set(t.type, t)
                                            },
                                            "sources-change": function(e) {
                                                r.sources = e.detail
                                            },
                                            "time-update": function(e) {
                                                let {
                                                    currentTime: t,
                                                    played: n
                                                } = e.detail;
                                                r.currentTime = t, r.played = n, r.waiting = !1
                                            },
                                            "volume-change": function(e) {
                                                r.volume = e.detail.volume, r.muted = e.detail.muted || 0 === e.detail.volume, F("volume", e)
                                            },
                                            "fullscreen-change": T,
                                            "fullscreen-error": O,
                                            abort: function(e) {
                                                (0, s.ZM)(e, x.get("source-change")), (0, s.ZM)(e, x.get("can-load"))
                                            },
                                            ended: function(e) {
                                                if (l.e()) {
                                                    e.stopImmediatePropagation();
                                                    return
                                                }
                                                r.paused = !0, r.playing = !1, r.seeking = !1, r.ended = !0, P()
                                            },
                                            error: function(e) {
                                                r.error = e.detail, (0, s.ZM)(e, x.get("abort"))
                                            },
                                            pause: function(e) {
                                                if (l.e()) {
                                                    e.stopImmediatePropagation();
                                                    return
                                                }(0, s.ZM)(e, x.get("seeked")), F("pause", e), r.paused = !0, r.playing = !1, r.seeking = !1, P()
                                            },
                                            play: function(t) {
                                                if (t.autoplay = r.attemptingAutoplay, l.e() || !r.paused) {
                                                    t.stopImmediatePropagation();
                                                    return
                                                }(0, s.ZM)(t, x.get("waiting")), F("play", t), r.paused = !1, r.autoplayError = void 0, (r.ended || l.f()) && (l.f.set(!1), r.ended = !1, I((0, s.yM)(e, "replay", {
                                                    trigger: t
                                                })))
                                            },
                                            playing: function(e) {
                                                let t = x.get("play");
                                                if (t ? ((0, s.ZM)(e, x.get("waiting")), (0, s.ZM)(e, t)) : (0, s.ZM)(e, x.get("seeked")), setTimeout(() => P(), 0), r.paused = !1, r.playing = !0, r.seeking = !1, r.ended = !1, l.e()) {
                                                    e.stopImmediatePropagation(), l.e.set(!1);
                                                    return
                                                }
                                                M(e)
                                            },
                                            progress: function(e) {
                                                let {
                                                    buffered: t,
                                                    seekable: n
                                                } = e.detail;
                                                r.buffered = t, r.seekable = n
                                            },
                                            seeked: function(e) {
                                                l.k() ? (r.seeking = !0, e.stopImmediatePropagation()) : r.seeking && ((0, s.ZM)(e, x.get("waiting")), (0, s.ZM)(e, x.get("seeking")), r.paused && L(), r.seeking = !1, e.detail !== r.duration && (r.ended = !1), r.currentTime = e.detail, F("seeked", e), M(e))
                                            },
                                            seeking: (0, o.n)(function(e) {
                                                r.seeking = !0, r.currentTime = e.detail, F("seeking", e)
                                            }, 150, {
                                                leading: !0
                                            }),
                                            waiting: function(e) {
                                                S || l.k() || (e.stopImmediatePropagation(), C = e, E())
                                            }
                                        };

                                        function P() {
                                            L(), l.f.set(!1), l.e.set(!1), S = !1, C = void 0, x.clear()
                                        }

                                        function M(t) {
                                            r.started || (r.started = !0, I((0, s.yM)(e, "started", {
                                                trigger: t
                                            })))
                                        }

                                        function L() {
                                            E ? .cancel(), r.waiting = !1
                                        }

                                        function T(e) {
                                            r.fullscreen = e.detail, F("fullscreen", e)
                                        }

                                        function O(e) {
                                            F("fullscreen", e)
                                        }

                                        function F(e, t) {
                                            l.a.o(e, e => {
                                                t.request = e, (0, s.ZM)(t, e)
                                            })
                                        }

                                        function I(t) {
                                            A[t.type] ? .(t), q.has(t.type) && x.set(t.type, t), e() ? .dispatchEvent(t)
                                        }
                                        return u = () => {
                                            if (!C) return;
                                            S = !0, r.waiting = !0, r.playing = !1;
                                            let t = (0, s.yM)(e, "waiting", {
                                                trigger: C
                                            });
                                            x.set("waiting", t), e() ? .dispatchEvent(t), C = void 0, S = !1
                                        }, a = 300, h = null, m = null, g = function() {
                                            h && (clearTimeout(h), m = null, h = null)
                                        }, y = function() {
                                            var e = m;
                                            g(), e && e()
                                        }, v = function() {
                                            if (!a) return u.apply(this, arguments);
                                            var e = this,
                                                t = arguments,
                                                n = void 0;
                                            if (g(), m = function() {
                                                    u.apply(e, t)
                                                }, h = setTimeout(function() {
                                                    if (h = null, !n) {
                                                        var e = m;
                                                        return m = null, e()
                                                    }
                                                }, a), n) return m()
                                        }, E = (v.cancel = g, v.flush = y, v), {
                                            handle: I
                                        }
                                    }(h, m),
                                    v = function({
                                        $player: e,
                                        $store: t,
                                        $provider: n,
                                        logger: r
                                    }, i, o, l) {
                                        let u = function(e, t) {
                                                let n, r = 2e3,
                                                    i, o = (0, d.td)(!1),
                                                    l = (0, d.td)(!1),
                                                    u = (0, d.Fl)(() => l() || t.paused);

                                                function a(e) {
                                                    (0, d.fj)(u) || (o() && (i = e), o.set(!1), window.clearTimeout(n), n = window.setTimeout(() => o.set(!(0, d.fj)(u)), r))
                                                }
                                                return (0, c.cE)(() => {
                                                    let r = e();
                                                    if (r) {
                                                        for (let l of _)(0, s.yl)(r, l, a);
                                                        return (0, c.cE)(() => {
                                                            window.clearTimeout(n);
                                                            let e = o();
                                                            t.userIdle = e, (0, s.Nu)(r, "user-idle-change", {
                                                                detail: e,
                                                                trigger: i
                                                            }), i = void 0
                                                        }), () => o.set(!1)
                                                    }
                                                }), {
                                                    idle: {
                                                        get idling() {
                                                            return o()
                                                        },
                                                        get paused() {
                                                            return l()
                                                        },
                                                        set paused(paused) {
                                                            l.set(paused)
                                                        },
                                                        get delay() {
                                                            return r
                                                        },
                                                        set delay(newDelay) {
                                                            r = newDelay
                                                        }
                                                    }
                                                }
                                            }(e, t),
                                            a = function(e) {
                                                let t = (0, d.td)(R()),
                                                    n = (0, d.td)(!1),
                                                    r;
                                                async function i(e) {
                                                    (0, d.fj)(n) || (z(), await screen.orientation.lock(e), n.set(!0), r = e)
                                                }
                                                async function o() {
                                                    (0, d.fj)(n) && (z(), r = void 0, await screen.orientation.unlock(), n.set(!1))
                                                }
                                                return D && (0, c.cE)(() => {
                                                    let i = e();
                                                    if (i) return (0, s.yl)(screen.orientation, "change", e => {
                                                        let n = R();
                                                        t.set(n), (0, s.Nu)(i, "orientation-change", {
                                                            detail: {
                                                                orientation: n,
                                                                lock: r
                                                            },
                                                            trigger: e
                                                        })
                                                    }), async () => {
                                                        D && n() && await o()
                                                    }
                                                }), {
                                                    get orientation() {
                                                        return t()
                                                    },
                                                    get locked() {
                                                        return n()
                                                    },
                                                    get supported() {
                                                        return D
                                                    },
                                                    lock: i,
                                                    unlock: o
                                                }
                                            }(e),
                                            p = function(e) {
                                                let t = (0, d.td)(!1),
                                                    n = () => I((0, d.fj)(e)),
                                                    r = !1;
                                                return (0, c.cE)(() => {
                                                    let i = e();
                                                    if (i) return (0, s.yl)(L, "fullscreenchange", async e => {
                                                        let n = O(i);
                                                        n !== t() && (n || (r = !1), t.set(n), (0, s.Nu)(i, "fullscreen-change", {
                                                            detail: n,
                                                            trigger: e
                                                        }))
                                                    }), (0, s.yl)(L, "fullscreenerror", e => {
                                                        r && ((0, s.Nu)(i, "fullscreen-error", {
                                                            detail: null,
                                                            trigger: e
                                                        }), r = !1)
                                                    }), async () => {
                                                        T() && await n()
                                                    }
                                                }), {
                                                    get active() {
                                                        return t()
                                                    },
                                                    get supported() {
                                                        return T()
                                                    },
                                                    async enter() {
                                                        try {
                                                            return r = !0, await F((0, d.fj)(e))
                                                        } catch (t) {
                                                            throw r = !1, t
                                                        }
                                                    },
                                                    exit: n
                                                }
                                            }(e);
                                        (0, c.cE)(() => {
                                            u.idle.delay = l.$userIdleDelay()
                                        }), (0, c.cE)(() => {
                                            let e = p.supported || n() ? .fullscreen ? .supported || !1;
                                            t.canLoad && (0, d.fj)(() => t.canFullscreen) === e || (t.canFullscreen = e)
                                        });
                                        let h = {
                                            "media-start-loading": function(n) {
                                                t.canLoad || (o.a.b("load", n), i.handle((0, s.yM)(e, "can-load")))
                                            },
                                            "media-mute-request": function(e) {
                                                t.muted || (o.a.b("volume", e), n().muted = !0)
                                            },
                                            "media-unmute-request": function(e) {
                                                t.muted && (o.a.b("volume", e), n().muted = !1, 0 === t.volume && (o.a.b("volume", e), n().volume = .25))
                                            },
                                            "media-play-request": m,
                                            "media-pause-request": g,
                                            "media-seeking-request": function(e) {
                                                o.a.b("seeking", e), t.seeking = !0, o.k.set(!0)
                                            },
                                            "media-seek-request": function(e) {
                                                let r = e.detail;
                                                t.ended && o.f.set(!0), o.a.b("seeked", e), o.k.set(!1), n().currentTime = r === t.duration ? r - .1 : r
                                            },
                                            "media-volume-change-request": function(e) {
                                                let r = e.detail;
                                                t.volume !== r && (o.a.b("volume", e), n().volume = r, r > 0 && t.muted && (o.a.b("volume", e), n().muted = !1))
                                            },
                                            "media-enter-fullscreen-request": y,
                                            "media-exit-fullscreen-request": v,
                                            "media-resume-user-idle-request": function(e) {
                                                o.a.b("userIdle", e), u.idle.paused = !1
                                            },
                                            "media-pause-user-idle-request": function(e) {
                                                o.a.b("userIdle", e), u.idle.paused = !0
                                            },
                                            "media-show-poster-request": function(e) {
                                                t.canLoadPoster = !0
                                            },
                                            "media-hide-poster-request": function(e) {
                                                t.canLoadPoster = !1
                                            },
                                            "media-loop-request": function(e) {
                                                window.requestAnimationFrame(async () => {
                                                    try {
                                                        o.e.set(!0), o.f.set(!0), await x()
                                                    } catch (e) {
                                                        o.e.set(!1), o.f.set(!1)
                                                    }
                                                })
                                            }
                                        };
                                        async function m(r) {
                                            if (t.paused) try {
                                                o.a.b("play", r), await n().play()
                                            } catch (u) {
                                                let l = (0, s.yM)(e, "play-fail", {
                                                    detail: B(u)
                                                });
                                                i.handle(l)
                                            }
                                        }
                                        async function g(e) {
                                            if (!t.paused) try {
                                                o.a.b("pause", e), await n().pause()
                                            } catch (r) {
                                                o.a.C("pause")
                                            }
                                        }
                                        async function y(t) {
                                            try {
                                                o.a.b("fullscreen", t), await w(t.detail)
                                            } catch (r) {
                                                let n = (0, s.yM)(e, "fullscreen-error", {
                                                    detail: B(r)
                                                });
                                                i.handle(n)
                                            }
                                        }
                                        async function v(t) {
                                            try {
                                                o.a.b("fullscreen", t), await E(t.detail)
                                            } catch (r) {
                                                let n = (0, s.yM)(e, "fullscreen-error", {
                                                    detail: B(r)
                                                });
                                                i.handle(n)
                                            }
                                        }

                                        function b(e, t) {
                                            if (!t ? .supported) throw Error("[vidstack] no fullscreen support")
                                        }
                                        async function x() {
                                            if (t.paused) try {
                                                let r = (0, d.fj)(n);
                                                return r && e() ? .state.canPlay || $(), (t.ended || 0 === t.currentTime) && (r.currentTime = 0), r.play()
                                            } catch (l) {
                                                let o = (0, s.yM)(e, "play-fail", {
                                                    detail: B(l)
                                                });
                                                throw o.autoplay = t.attemptingAutoplay, i.handle(o), l
                                            }
                                        }
                                        async function k() {
                                            if (t.paused) return;
                                            let r = (0, d.fj)(n);
                                            return r && e() ? .state.canPlay || $(), r.pause()
                                        }
                                        async function w(e = "prefer-media") {
                                            let t = (0, d.fj)(n),
                                                r = "prefer-media" === e && p.supported || "media" === e ? p : t ? .fullscreen;
                                            if (b(e, r), r.active) return;
                                            let i = (0, d.fj)(l.$fullscreenOrientation);
                                            return a.supported && !(0, c.o8)(i) && await a.lock(i), r.enter()
                                        }
                                        async function E(e = "prefer-media") {
                                            let t = (0, d.fj)(n),
                                                r = "prefer-media" === e && p.supported || "media" === e ? p : t ? .fullscreen;
                                            if (b(e, r), r.active) return a.locked && await a.unlock(), r.exit()
                                        }
                                        return (0, c.cE)(() => {
                                            let t = e();
                                            if (t)
                                                for (let r of (0, f.keysOf)(h)) {
                                                    let i = h[r];
                                                    (0, s.yl)(t, r, e => {
                                                        e.stopPropagation(), (0, d.fj)(n) && i(e)
                                                    })
                                                }
                                        }), {
                                            D: u,
                                            E: a,
                                            y: x,
                                            x: k,
                                            F: w,
                                            G: E
                                        }
                                    }(h, g, m, e),
                                    b = function({
                                        $player: e,
                                        $store: t,
                                        logger: n
                                    }, r) {
                                        let i = (e, ...t) => {
                                            r(new s.yb(e, t ? .[0]))
                                        };
                                        async function o({
                                            duration: e
                                        }, n) {
                                            !(0, d.fj)(() => t.canPlay) && (i("can-play", {
                                                detail: {
                                                    duration: e
                                                },
                                                trigger: n
                                            }), (0, d.Ky)(), t.canPlay && t.autoplay && !t.started && await l())
                                        }
                                        async function l() {
                                            t.attemptingAutoplay = !0;
                                            try {
                                                await e().play(), i("autoplay", {
                                                    detail: {
                                                        muted: t.muted
                                                    }
                                                })
                                            } catch (n) {
                                                i("autoplay-fail", {
                                                    detail: {
                                                        muted: t.muted,
                                                        error: n
                                                    }
                                                })
                                            } finally {
                                                t.attemptingAutoplay = !1
                                            }
                                        }
                                        return {
                                            dispatch: i,
                                            ready: o
                                        }
                                    }(h, g.handle),
                                    x = function({
                                        $provider: e,
                                        $store: t
                                    }, n, {
                                        $paused: r,
                                        $volume: i,
                                        $muted: o,
                                        $currentTime: l,
                                        $playsinline: a
                                    }) {
                                        let s = new w;

                                        function f(e) {
                                            e ? s.b("paused", n.x) : s.b("paused", n.y)
                                        }

                                        function d(t) {
                                            let n = (0, u.IV)(0, t, 1);
                                            s.b("volume", () => e().volume = n)
                                        }

                                        function p(t) {
                                            s.b("muted", () => e().muted = t)
                                        }

                                        function h(t) {
                                            s.b("currentTime", () => {
                                                let n = e();
                                                t !== n.currentTime && (n.currentTime = t)
                                            })
                                        }

                                        function m(t) {
                                            s.b("playsinline", () => e().playsinline = t)
                                        }(0, c.cE)(() => {
                                            t.canPlay && e() ? s.p() : s.u()
                                        }), (0, c.cE)(() => p(o())), (0, c.cE)(() => f(r())), (0, c.cE)(() => d(i())), (0, c.cE)(() => h(l())), (0, c.cE)(() => m(a()));
                                        let g = {},
                                            y = {
                                                paused: f,
                                                muted: p,
                                                volume: d,
                                                currentTime: h,
                                                playsinline: m
                                            };
                                        for (let v of Object.keys(y)) Object.defineProperty(g, v, {
                                            get: () => t[v],
                                            set: y[v]
                                        });
                                        return g
                                    }(h, v, e);
                                for (let E of (h.delegate = b, Object.keys(e))) {
                                    let S = E.slice(1);
                                    S in h.$store && (h.$store[S] = e[E]())
                                }

                                function C() {
                                    b.dispatch("can-load")
                                }
                                return h.$store.muted = e.$muted() || 0 === e.$volume(), ! function({
                                    $player: e,
                                    $store: t
                                }, {
                                    $autoplay: n,
                                    $poster: r,
                                    $loop: i,
                                    $controls: o,
                                    $playsinline: l,
                                    $view: u,
                                    $logLevel: a
                                }) {
                                    (0, c.cE)(() => {
                                        let a = e();
                                        a && ((0, c.cE)(() => {
                                            let e = n();
                                            t.autoplay = e, (0, s.Nu)(a, "autoplay-change", {
                                                detail: e
                                            })
                                        }), (0, c.cE)(() => {
                                            let e = r();
                                            t.poster = e, (0, s.Nu)(a, "poster-change", {
                                                detail: e
                                            })
                                        }), (0, c.cE)(() => {
                                            let e = i();
                                            t.loop = e, (0, s.Nu)(a, "loop-change", {
                                                detail: e
                                            })
                                        }), (0, c.cE)(() => {
                                            let e = o();
                                            t.controls = e, (0, s.Nu)(a, "controls-change", {
                                                detail: e
                                            })
                                        }), (0, c.cE)(() => {
                                            let e = l();
                                            t.playsinline = e, (0, s.Nu)(a, "playsinline-change", {
                                                detail: e
                                            })
                                        }), (0, c.cE)(() => {
                                            let e = u();
                                            t.view = e, (0, s.Nu)(a, "view-change", {
                                                detail: e
                                            })
                                        }))
                                    })
                                }(h, e), t = h.$player, r = e.$load, (0, p.br)(async () => {
                                    let e = r();
                                    if ("eager" === e) requestAnimationFrame(C);
                                    else if ("idle" === e) {
                                        let {
                                            waitIdlePeriod: i
                                        } = await Promise.resolve().then(n.bind(n, 8860));
                                        i(C)
                                    } else "visible" === e && (0, d.Jz)(async e => {
                                        let n = function(e, t = {}) {
                                            let n = (0, d.td)(!1),
                                                {
                                                    skipInitial: r,
                                                    callback: i,
                                                    ...o
                                                } = t,
                                                l;
                                            return (0, c.cE)(() => {
                                                let t = e();
                                                if (!t) {
                                                    n.set(!1);
                                                    return
                                                }
                                                let u = !0,
                                                    a = new IntersectionObserver(e => {
                                                        if (u && r) {
                                                            u = !1;
                                                            return
                                                        }
                                                        i ? .(e, a), n.set(e[0].isIntersecting)
                                                    }, o);
                                                return a.observe(t), l = () => {
                                                    a.disconnect(), l = void 0
                                                }
                                            }), {
                                                get intersecting() {
                                                    return n()
                                                },
                                                disconnect() {
                                                    l ? .()
                                                }
                                            }
                                        }(t);
                                        (0, c.cE)(() => {
                                            n.intersecting && (C(), e())
                                        })
                                    })
                                }), {
                                    z: h,
                                    p: C,
                                    g: v,
                                    H: x
                                }
                            }(t),
                            g = m.z,
                            v = g.$store;
                        (0, p.Qt)(() => {
                            g.$player.set(e.el), g.remote.setTarget(e.el), g.remote.setPlayer(e.el), (0, s.yl)(e.el, "find-media-player", ({
                                detail: t
                            }) => t(e.el))
                        }), (0, p.br)(() => {
                            (0, s.Nu)(e.el, "media-player-connect", {
                                detail: e.el,
                                bubbles: !0,
                                composed: !0
                            }), window.requestAnimationFrame(() => {
                                (0, c.Ft)(v.canLoadPoster) && (v.canLoadPoster = !0)
                            })
                        }),
                        function(e, t) {
                            let {
                                $loader: n,
                                $store: r,
                                delegate: o
                            } = t, l = [new U, new W, new K];
                            (0, c.cE)(() => {
                                var t;
                                o.dispatch("sources-change", {
                                    detail: (t = e(), ((0, c.kJ)(t) ? t : [!(0, c.HD)(t) && "src" in t ? t : {
                                        src: t
                                    }]).map(({
                                        src: e,
                                        type: t
                                    }) => ({
                                        src: e,
                                        type: t ? ? (!(0, c.HD)(e) || e.startsWith("blob:") ? "video/object" : "?")
                                    })))
                                })
                            }), (0, c.cE)(() => {
                                let e = r.sources,
                                    i = (0, d.fj)(() => r.source),
                                    u = {
                                        src: "",
                                        type: ""
                                    },
                                    a = null;
                                for (let c of e) {
                                    let s = l.find(e => e.canPlay(c));
                                    s && (u = c, a = s)
                                }(u.src !== i.src || u.type !== i.type) && (o.dispatch("source-change", {
                                    detail: u
                                }), o.dispatch("media-change", {
                                    detail: a ? .mediaType(u) || "unknown"
                                })), a !== (0, d.fj)(n) && (o.dispatch("provider-change", {
                                    detail: null
                                }), a && (0, d.fj)(() => a.preconnect ? .(t)), o.dispatch("provider-loader-change", {
                                    detail: a
                                })), (0, d.Ky)()
                            }), (0, c.cE)(() => {
                                let e = t.$provider();
                                if (e) {
                                    if (t.$store.canLoad) {
                                        (0, d.fj)(() => e.setup({ ...t,
                                            player: t.$player()
                                        }));
                                        return
                                    }(0, d.fj)(() => e.preconnect ? .(t))
                                }
                            }), (0, c.cE)(() => {
                                let e = t.$provider(),
                                    n = t.$store.source;
                                if (t.$store.canLoad) {
                                    (0, d.fj)(() => e ? .loadSource(n, (0, d.fj)(() => t.$store.preload)));
                                    return
                                }
                                try {
                                    (0, c.HD)(n.src) && (0, i.$P)(new URL(n.src).origin, "preconnect")
                                } catch (r) {}
                            })
                        }(t.$src, m.z);
                        let b = {
                            "aspect-ratio": t.$aspectRatio,
                            "ios-controls": () => l.cj && v.media.includes("video") && v.controls && (!t.$playsinline() || v.fullscreen)
                        };
                        for (let x of G) b[(0, s.Kh)(x)] = () => v[x];
                        return e.setAttributes(b), e.setCSSVars({
                            "--media-aspect-ratio": t.$aspectRatio,
                            "--media-buffered-amount": () => v.bufferedAmount,
                            "--media-current-time": () => v.currentTime,
                            "--media-duration": () => v.duration,
                            "--media-seekable-amount": () => v.seekableAmount
                        }), (0, d.uG)(() => {
                            (0, s.Nu)(e.el, "destroy")
                        }), (0, f.mergeProperties)({
                            get user() {
                                return m.g.D
                            },
                            get orientation() {
                                return m.g.E
                            },
                            get provider() {
                                return g.$provider()
                            },
                            get $store() {
                                return v
                            },
                            state: new Proxy(v, {
                                set: c.ZT
                            }),
                            subscribe: e => (0, d.Yn)(() => (0, c.cE)(() => e(v)), h),
                            startLoading: m.p,
                            play: m.g.y,
                            pause: m.g.x,
                            enterFullscreen: m.g.F,
                            exitFullscreen: m.g.G
                        }, r(), m.H)
                    }
                })
        }
    }
]);