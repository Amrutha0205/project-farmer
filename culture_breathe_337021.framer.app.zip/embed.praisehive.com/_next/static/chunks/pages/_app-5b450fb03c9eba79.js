(self.webpackChunk_N_E = self.webpackChunk_N_E || []).push([
    [888], {
        6840: function(t, e, n) {
            (window.__NEXT_P = window.__NEXT_P || []).push(["/_app", function() {
                return n(1202)
            }])
        },
        1202: function(t, e, n) {
            "use strict";
            n.r(e), n.d(e, {
                default: function() {
                    return c
                }
            });
            var r = n(1799),
                o = n(5893);
            n(906);
            var a = n(9008),
                i = n.n(a),
                s = function(t) {
                    var e = t.title,
                        n = t.description,
                        r = t.url,
                        a = t.image,
                        s = t.type,
                        c = "PraiseHive - Widgets",
                        m = "Collect and showcase testimonials from your satisfied customers. Increase your conversion rate with trust. Start now for free.",
                        u = "https://praisehive.com",
                        p = "https://praisehive.com/assets/open-graph.png";
                    return (0, o.jsxs)(i(), {
                        children: [(0, o.jsx)("title", {
                            children: e || c
                        }), (0, o.jsx)("meta", {
                            name: "title",
                            content: e || c
                        }), (0, o.jsx)("meta", {
                            name: "description",
                            content: n || m
                        }), (0, o.jsx)("meta", {
                            name: "theme-color",
                            content: "#9333EA"
                        }), (0, o.jsx)("meta", {
                            property: "og:type",
                            content: s || "website"
                        }), (0, o.jsx)("meta", {
                            property: "og:title",
                            content: e || c
                        }), (0, o.jsx)("meta", {
                            property: "og:description",
                            content: n || m
                        }), (0, o.jsx)("meta", {
                            property: "og:site_name",
                            content: "PraiseHive"
                        }), (0, o.jsx)("meta", {
                            property: "og:url",
                            content: r || u
                        }), (0, o.jsx)("meta", {
                            property: "og:locale",
                            content: "en"
                        }), (0, o.jsx)("meta", {
                            property: "og:image",
                            content: a || p
                        }), (0, o.jsx)("meta", {
                            name: "twitter:card",
                            content: "summary_large_image"
                        }), (0, o.jsx)("meta", {
                            name: "twitter:title",
                            content: e || c
                        }), (0, o.jsx)("meta", {
                            name: "twitter:description",
                            content: n || m
                        }), (0, o.jsx)("meta", {
                            name: "twitter:site",
                            content: "@PraiseHive"
                        }), (0, o.jsx)("meta", {
                            name: "twitter:creator",
                            content: "@GwendalBrossard"
                        }), (0, o.jsx)("meta", {
                            name: "twitter:image",
                            content: a || p
                        }), (0, o.jsx)("link", {
                            rel: "canonical",
                            href: r || u
                        })]
                    })
                };

            function c(t) {
                var e = t.Component,
                    n = t.pageProps;
                return (0, o.jsxs)(o.Fragment, {
                    children: [(0, o.jsx)(s, {}), (0, o.jsx)(e, (0, r.Z)({}, n)), (0, o.jsx)(o.Fragment, {
                        children: (0, o.jsx)("script", {
                            src: "https://beamanalytics.b-cdn.net/beam.min.js",
                            "data-token": "6c306383-9b89-4569-a00a-3b721ea0d602",
                            async: !0
                        })
                    })]
                })
            }
        },
        906: function() {},
        9008: function(t, e, n) {
            t.exports = n(5443)
        },
        1799: function(t, e, n) {
            "use strict";

            function r(t, e, n) {
                return e in t ? Object.defineProperty(t, e, {
                    value: n,
                    enumerable: !0,
                    configurable: !0,
                    writable: !0
                }) : t[e] = n, t
            }

            function o(t) {
                for (var e = 1; e < arguments.length; e++) {
                    var n = null != arguments[e] ? arguments[e] : {},
                        o = Object.keys(n);
                    "function" == typeof Object.getOwnPropertySymbols && (o = o.concat(Object.getOwnPropertySymbols(n).filter(function(t) {
                        return Object.getOwnPropertyDescriptor(n, t).enumerable
                    }))), o.forEach(function(e) {
                        r(t, e, n[e])
                    })
                }
                return t
            }
            n.d(e, {
                Z: function() {
                    return o
                }
            })
        }
    },
    function(t) {
        var e = function(e) {
            return t(t.s = e)
        };
        t.O(0, [774, 179], function() {
            return e(6840), e(387)
        }), _N_E = t.O()
    }
]);