(self.webpackChunk_N_E = self.webpackChunk_N_E || []).push([
    [112], {
        6877: function(e, t, n) {
            (window.__NEXT_P = window.__NEXT_P || []).push(["/[id]", function() {
                return n(3938)
            }])
        },
        3938: function(e, t, n) {
            "use strict";
            n.r(t), n.d(t, {
                __N_SSP: function() {
                    return s
                }
            });
            var o = n(5893),
                i = n(7294);
            n(2179);
            var r = n(893),
                a = n(5152),
                u = n.n(a)()(function() {
                    return Promise.all([n.e(658), n.e(523)]).then(n.bind(n, 4523))
                }, {
                    loadableGenerated: {
                        webpack: function() {
                            return [4523]
                        }
                    },
                    ssr: !1
                }),
                c = function(e) {
                    var t = e.data,
                        n = (0, r.K)(function(e) {
                            return e.setWidget
                        });
                    return 0 === t.getWidget.testimonials.length ? (0, o.jsx)("p", {
                        className: "text-gray-500 italic text-center p-10",
                        children: "No testimonial found. Please check your settings."
                    }) : ((0, i.useEffect)(function() {
                        n(t.getWidget)
                    }), (0, o.jsx)(u, {}))
                },
                s = !0;
            t.default = c
        },
        2179: function(e) {
            "use strict";
            /*! iFrame Resizer (iframeSizer.contentWindow.min.js) - v4.3.4 - 2023-02-18
             * Desc: Include this file in any page being loaded into an iframe
             * to force the iframe to resize to the content size.
             * Requires: iframeResizer.min.js on host page.
             * Copyright: (c) 2023 David J. Bradshaw - dave@bradshaw.net
             * License: MIT
             */
            ! function(t) {
                var n = function() {},
                    o = function(e, t, n, o) {
                        e.addEventListener(t, n, !!ey && (o || {}))
                    },
                    i = function(e) {
                        return e.charAt(0).toUpperCase() + e.slice(1)
                    },
                    r = function(e) {
                        return G + "[" + $ + "] " + e
                    },
                    a = function(e) {
                        Y && "object" == typeof window.console && console.log(r(e))
                    },
                    u = function(e) {
                        "object" == typeof window.console && console.warn(r(e))
                    },
                    c = function() {
                        var e, n, i;

                        function r(e) {
                            return "true" === e
                        }

                        function c(e, t) {
                            return "function" == typeof e && (a("Setup custom " + t + "CalcMethod"), ep[t] = e, e = "custom"), e
                        }

                        function l(e) {
                            A(0, 0, e.type, e.screenY + ":" + e.screenX)
                        }

                        function m(e, t) {
                            a("Add event listener: " + t), o(window.document, e, l)
                        }
                        $ = (e = U.slice(Z).split(":"))[0], R = t === e[1] ? R : Number(e[1]), _ = t === e[2] ? _ : r(e[2]), Y = t === e[3] ? Y : r(e[3]), K = t === e[4] ? K : Number(e[4]), x = t === e[6] ? x : r(e[6]), P = e[7], B = t === e[8] ? B : e[8], z = e[9], F = e[10], er = t === e[11] ? er : Number(e[11]), X.enable = t !== e[12] && r(e[12]), et = t === e[13] ? et : e[13], el = t === e[14] ? el : e[14], Q = t === e[15] ? Q : r(e[15]), a("Initialising iFrame (" + window.location.href + ")"), "iFrameResizer" in window && Object === window.iFrameResizer.constructor && (a("Reading data from page: " + JSON.stringify(e = window.iFrameResizer)), Object.keys(e).forEach(s, e), em = "onMessage" in e ? e.onMessage : em, eh = "onReady" in e ? e.onReady : eh, ei = "targetOrigin" in e ? e.targetOrigin : ei, B = "heightCalculationMethod" in e ? e.heightCalculationMethod : B, el = "widthCalculationMethod" in e ? e.widthCalculationMethod : el, B = c(B, "height"), el = c(el, "width")), a("TargetOrigin for parent set to: " + ei), d("margin", (-1 !== (i = P = t === P ? R + "px" : P).indexOf("-") && (u("Negative CSS value ignored for margin"), i = ""), i)), d("background", z), d("padding", F), (e = document.createElement("div")).style.clear = "both", e.style.display = "block", e.style.height = "0", document.body.appendChild(e), h(), g(), document.documentElement.style.height = "", document.body.style.height = "", a('HTML & body height set to "auto"'), a("Enable public methods"), ef.parentIFrame = {
                            autoResize: function(e) {
                                return !0 === e && !1 === x ? (x = !0, p()) : !1 === e && !0 === x && (x = !1, f("remove"), null !== L && L.disconnect(), clearInterval(V)), A(0, 0, "autoResize", JSON.stringify(x)), x
                            },
                            close: function() {
                                A(0, 0, "close")
                            },
                            getId: function() {
                                return $
                            },
                            getPageInfo: function(e) {
                                "function" == typeof e ? (eg = e, A(0, 0, "pageInfo")) : (eg = function() {}, A(0, 0, "pageInfoStop"))
                            },
                            moveToAnchor: function(e) {
                                X.findTarget(e)
                            },
                            reset: function() {
                                k("parentIFrame.reset")
                            },
                            scrollTo: function(e, t) {
                                A(t, e, "scrollTo")
                            },
                            scrollToOffset: function(e, t) {
                                A(t, e, "scrollToOffset")
                            },
                            sendMessage: function(e, t) {
                                A(0, 0, "message", JSON.stringify(e), t)
                            },
                            setHeightCalculationMethod: function(e) {
                                B = e, h()
                            },
                            setWidthCalculationMethod: function(e) {
                                el = e, g()
                            },
                            setTargetOrigin: function(e) {
                                a("Set targetOrigin: " + e), ei = e
                            },
                            size: function(e, t) {
                                M("size", "parentIFrame.size(" + (e || "") + (t ? "," + t : "") + ")", e, t)
                            }
                        }, !0 === Q && (m("mouseenter", "Mouse Enter"), m("mouseleave", "Mouse Leave")), p(), X = function() {
                            function e(e) {
                                var n, o, e = e.split("#")[1] || e,
                                    i = decodeURIComponent(e),
                                    i = document.getElementById(i) || document.getElementsByName(i)[0];
                                t === i ? (a("In page link (#" + e + ") not found in iFrame, so sending to parent"), A(0, 0, "inPageLink", "#" + e)) : (n = n.getBoundingClientRect(), o = {
                                    x: window.pageXOffset === t ? document.documentElement.scrollLeft : window.pageXOffset,
                                    y: window.pageYOffset === t ? document.documentElement.scrollTop : window.pageYOffset
                                }, i = {
                                    x: parseInt(n.left, 10) + parseInt(o.x, 10),
                                    y: parseInt(n.top, 10) + parseInt(o.y, 10)
                                }, a("Moving to in page link (#" + e + ") at x: " + i.x + " y: " + i.y), A(i.y, i.x, "scrollToOffset"))
                            }

                            function n() {
                                var t = window.location.hash,
                                    n = window.location.href;
                                "" !== t && "#" !== t && e(n)
                            }
                            return X.enable ? Array.prototype.forEach && document.querySelectorAll ? (a("Setting up location.hash handlers"), Array.prototype.forEach.call(document.querySelectorAll('a[href^="#"]'), function(t) {
                                "#" !== t.getAttribute("href") && o(t, "click", function(t) {
                                    t.preventDefault(), e(this.getAttribute("href"))
                                })
                            }), o(window, "hashchange", n), setTimeout(n, D)) : u("In page linking not fully supported in this browser! (See README.md for IE8 workaround)") : a("In page linking not enabled"), {
                                findTarget: e
                            }
                        }(), M("init", "Init message from host page"), eh()
                    },
                    s = function(e) {
                        var t = e.split("Callback");
                        2 === t.length && (this[t = "on" + t[0].charAt(0).toUpperCase() + t[0].slice(1)] = this[e], delete this[e], u("Deprecated: '" + e + "' has been renamed '" + t + "'. The old method will be removed in the next major version."))
                    },
                    d = function(e, n) {
                        t !== n && "" !== n && "null" !== n && a("Body " + e + ' set to "' + (document.body.style[e] = n) + '"')
                    },
                    l = function(e) {
                        var t = {
                            add: function(t) {
                                function n() {
                                    M(e.eventName, e.eventType)
                                }
                                ev[t] = n, o(window, t, n, {
                                    passive: !0
                                })
                            },
                            remove: function(e) {
                                var t = ev[e];
                                delete ev[e], window.removeEventListener(e, t, !1)
                            }
                        };
                        e.eventNames && Array.prototype.map ? (e.eventName = e.eventNames[0], e.eventNames.map(t[e.method])) : t[e.method](e.eventName), a(i(e.method) + " event listener: " + e.eventType)
                    },
                    f = function(e) {
                        l({
                            method: e,
                            eventType: "Animation Start",
                            eventNames: ["animationstart", "webkitAnimationStart"]
                        }), l({
                            method: e,
                            eventType: "Animation Iteration",
                            eventNames: ["animationiteration", "webkitAnimationIteration"]
                        }), l({
                            method: e,
                            eventType: "Animation End",
                            eventNames: ["animationend", "webkitAnimationEnd"]
                        }), l({
                            method: e,
                            eventType: "Input",
                            eventName: "input"
                        }), l({
                            method: e,
                            eventType: "Mouse Up",
                            eventName: "mouseup"
                        }), l({
                            method: e,
                            eventType: "Mouse Down",
                            eventName: "mousedown"
                        }), l({
                            method: e,
                            eventType: "Orientation Change",
                            eventName: "orientationchange"
                        }), l({
                            method: e,
                            eventType: "Print",
                            eventNames: ["afterprint", "beforeprint"]
                        }), l({
                            method: e,
                            eventType: "Ready State Change",
                            eventName: "readystatechange"
                        }), l({
                            method: e,
                            eventType: "Touch Start",
                            eventName: "touchstart"
                        }), l({
                            method: e,
                            eventType: "Touch End",
                            eventName: "touchend"
                        }), l({
                            method: e,
                            eventType: "Touch Cancel",
                            eventName: "touchcancel"
                        }), l({
                            method: e,
                            eventType: "Transition Start",
                            eventNames: ["transitionstart", "webkitTransitionStart", "MSTransitionStart", "oTransitionStart", "otransitionstart"]
                        }), l({
                            method: e,
                            eventType: "Transition Iteration",
                            eventNames: ["transitioniteration", "webkitTransitionIteration", "MSTransitionIteration", "oTransitionIteration", "otransitioniteration"]
                        }), l({
                            method: e,
                            eventType: "Transition End",
                            eventNames: ["transitionend", "webkitTransitionEnd", "MSTransitionEnd", "oTransitionEnd", "otransitionend"]
                        }), "child" === et && l({
                            method: e,
                            eventType: "IFrame Resized",
                            eventName: "resize"
                        })
                    },
                    m = function(e, t, n, o) {
                        return t !== e && (e in n || (u(e + " is not a valid option for " + o + "CalculationMethod."), e = t), a(o + ' calculation method set to "' + e + '"')), e
                    },
                    h = function() {
                        B = m(B, H, eI, "height")
                    },
                    g = function() {
                        el = m(el, ed, ek, "width")
                    },
                    p = function() {
                        var e;
                        !0 === x ? (f("add"), e = K < 0, window.MutationObserver || window.WebKitMutationObserver ? e ? v() : L = function() {
                            function e(e) {
                                function t(e) {
                                    !1 === e.complete && (a("Attach listeners to " + e.src), e.addEventListener("load", o, !1), e.addEventListener("error", i, !1), u.push(e))
                                }
                                "attributes" === e.type && "src" === e.attributeName ? t(e.target) : "childList" === e.type && Array.prototype.forEach.call(e.target.querySelectorAll("img"), t)
                            }

                            function t(e) {
                                a("Remove listeners from " + e.src), e.removeEventListener("load", o, !1), e.removeEventListener("error", i, !1), u.splice(u.indexOf(e), 1)
                            }

                            function n(e, n, o) {
                                t(e.target), M(n, o + ": " + e.target.src)
                            }

                            function o(e) {
                                n(e, "imageLoad", "Image loaded")
                            }

                            function i(e) {
                                n(e, "imageLoadFailed", "Image load failed")
                            }
                            var r, u = [],
                                c = window.MutationObserver || window.WebKitMutationObserver,
                                s = (r = document.querySelector("body"), s = new c(function t(n) {
                                    M("mutationObserver", "mutationObserver: " + n[0].target + " " + n[0].type), n.forEach(e)
                                }), a("Create body MutationObserver"), s.observe(r, {
                                    attributes: !0,
                                    attributeOldValue: !1,
                                    characterData: !0,
                                    characterDataOldValue: !1,
                                    childList: !0,
                                    subtree: !0
                                }), s);
                            return {
                                disconnect: function() {
                                    "disconnect" in s && (a("Disconnect body MutationObserver"), s.disconnect(), u.forEach(t))
                                }
                            }
                        }() : (a("MutationObserver not supported in this browser!"), v())) : a("Auto Resize disabled")
                    },
                    v = function() {
                        0 !== K && (a("setInterval: " + K + "ms"), V = setInterval(function() {
                            M("interval", "setInterval: " + K)
                        }, Math.abs(K)))
                    },
                    y = function(e, t) {
                        return t = t || document.body, parseInt(t = null === (t = document.defaultView.getComputedStyle(t, null)) ? 0 : t[e], 10)
                    },
                    w = function(e, t) {
                        for (var n, o = t.length, r = 0, u = i(e), c = Date.now(), s = 0; s < o; s++) r < (n = t[s].getBoundingClientRect()[e] + y("margin" + u, t[s])) && (r = n);
                        return c = Date.now() - c, a("Parsed " + o + " HTML elements"), a("Element position calculated in " + c + "ms"), ec / 2 < c && a("Event throttle increased to " + (ec = 2 * c) + "ms"), r
                    },
                    b = function(e) {
                        return [e.bodyOffset(), e.bodyScroll(), e.documentElementOffset(), e.documentElementScroll()]
                    },
                    T = function(e, t) {
                        var n = document.querySelectorAll("[" + t + "]");
                        return 0 === n.length && (u("No tagged elements (" + t + ") found on page"), document.querySelectorAll("body *")), w(e, n)
                    },
                    E = function() {
                        return document.querySelectorAll("body *")
                    },
                    O = function(e, n, o, i) {
                        function r(e, t) {
                            return !(Math.abs(e - t) <= er)
                        }
                        o = t === o ? eI[B]() : o, i = t === i ? ek[el]() : i, r(q, o) || _ && r(es, i) || "init" === e ? (N(), A(q = o, es = i, e)) : e in {
                            init: 1,
                            interval: 1,
                            size: 1
                        } || !(B in ee || _ && el in ee) ? e in {
                            interval: 1
                        } || a("No change in size detected") : k(n)
                    },
                    S = function() {
                        eN = Date.now(), eM = null, eS = eT.apply(eE, eO), eM || (eE = eO = null)
                    },
                    M = function(e, t, n, o) {
                        ea && e in W ? a("Trigger event cancelled: " + e) : (e in {
                            reset: 1,
                            resetPage: 1,
                            init: 1
                        } || a("Trigger event: " + t), ("init" === e ? O : eA)(e, t, n, o))
                    },
                    N = function() {
                        ea || (ea = !0, a("Trigger event lock on")), clearTimeout(eu), eu = setTimeout(function() {
                            ea = !1, a("Trigger event lock off"), a("--")
                        }, D)
                    },
                    I = function(e) {
                        A(q = eI[B](), es = ek[el](), e)
                    },
                    k = function(e) {
                        var t = B;
                        B = H, a("Reset trigger event: " + e), N(), I("reset"), B = t
                    },
                    A = function(e, n, o, i, r) {
                        !0 === en && (t === r ? r = ei : a("Message targetOrigin: " + r), a("Sending message to host page (" + (e = $ + ":" + e + ":" + n + ":" + o + (t === i ? "" : ":" + i)) + ")"), eo.postMessage(G + e, r))
                    },
                    C = function() {
                        "loading" !== document.readyState && window.parent.postMessage("[iFrameResizerChild]Ready", "*")
                    },
                    x = !0,
                    z = "",
                    R = 0,
                    P = "",
                    L = null,
                    F = "",
                    _ = !1,
                    W = {
                        resize: 1,
                        click: 1
                    },
                    D = 128,
                    j = !0,
                    q = 1,
                    H = "bodyOffset",
                    B = H,
                    J = !0,
                    U = "",
                    X = {},
                    K = 32,
                    V = null,
                    Y = !1,
                    Q = !1,
                    G = "[iFrameSizer]",
                    Z = G.length,
                    $ = "",
                    ee = {
                        max: 1,
                        min: 1,
                        bodyScroll: 1,
                        documentElementScroll: 1
                    },
                    et = "child",
                    en = !0,
                    eo = window.parent,
                    ei = "*",
                    er = 0,
                    ea = !1,
                    eu = null,
                    ec = 16,
                    es = 1,
                    ed = "scroll",
                    el = ed,
                    ef = window,
                    em = function() {
                        u("onMessage function not defined")
                    },
                    eh = function() {},
                    eg = function() {},
                    ep = {
                        height: function() {
                            return u("Custom height calculation function not defined"), document.documentElement.offsetHeight
                        },
                        width: function() {
                            return u("Custom width calculation function not defined"), document.body.scrollWidth
                        }
                    },
                    ev = {},
                    ey = !1;
                try {
                    var ew = Object.create({}, {
                        passive: {
                            get: function() {
                                ey = !0
                            }
                        }
                    });
                    window.addEventListener("test", n, ew), window.removeEventListener("test", n, ew)
                } catch (eb) {}
                var eT, eE, eO, eS, eM, eN, eI = {
                        bodyOffset: function() {
                            return document.body.offsetHeight + y("marginTop") + y("marginBottom")
                        },
                        offset: function() {
                            return eI.bodyOffset()
                        },
                        bodyScroll: function() {
                            return document.body.scrollHeight
                        },
                        custom: function() {
                            return ep.height()
                        },
                        documentElementOffset: function() {
                            return document.documentElement.offsetHeight
                        },
                        documentElementScroll: function() {
                            return document.documentElement.scrollHeight
                        },
                        max: function() {
                            return Math.max.apply(null, b(eI))
                        },
                        min: function() {
                            return Math.min.apply(null, b(eI))
                        },
                        grow: function() {
                            return eI.max()
                        },
                        lowestElement: function() {
                            return Math.max(eI.bodyOffset() || eI.documentElementOffset(), w("bottom", E()))
                        },
                        taggedElement: function() {
                            return T("bottom", "data-iframe-height")
                        }
                    },
                    ek = {
                        bodyScroll: function() {
                            return document.body.scrollWidth
                        },
                        bodyOffset: function() {
                            return document.body.offsetWidth
                        },
                        custom: function() {
                            return ep.width()
                        },
                        documentElementScroll: function() {
                            return document.documentElement.scrollWidth
                        },
                        documentElementOffset: function() {
                            return document.documentElement.offsetWidth
                        },
                        scroll: function() {
                            return Math.max(ek.bodyScroll(), ek.documentElementScroll())
                        },
                        max: function() {
                            return Math.max.apply(null, b(ek))
                        },
                        min: function() {
                            return Math.min.apply(null, b(ek))
                        },
                        rightMostElement: function() {
                            return w("right", E())
                        },
                        taggedElement: function() {
                            return T("right", "data-iframe-width")
                        }
                    },
                    eA = (eT = O, eM = null, eN = 0, function() {
                        var e = Date.now(),
                            t = ec - (e - (eN = eN || e));
                        return eE = this, eO = arguments, t <= 0 || ec < t ? (eM && (clearTimeout(eM), eM = null), eN = e, eS = eT.apply(eE, eO), eM || (eE = eO = null)) : eM = eM || setTimeout(S, t), eS
                    });
                o(window, "message", function(n) {
                    var o, i = function() {
                            return n.data.split("]")[1].split(":")[0]
                        },
                        r = function() {
                            return n.data.slice(n.data.indexOf(":") + 1)
                        },
                        s = function() {
                            return n.data.split(":")[2] in {
                                true: 1,
                                false: 1
                            }
                        },
                        d = {
                            init: function() {
                                U = n.data, eo = n.source, c(), j = !1, setTimeout(function() {
                                    J = !1
                                }, D)
                            },
                            reset: function() {
                                J ? a("Page reset ignored by init") : (a("Page size reset by host page"), I("resetPage"))
                            },
                            resize: function() {
                                M("resizeParent", "Parent window requested size check")
                            },
                            moveToAnchor: function() {
                                X.findTarget(r())
                            },
                            inPageLink: function() {
                                this.moveToAnchor()
                            },
                            pageInfo: function() {
                                var e = r();
                                a("PageInfoFromParent called from parent: " + e), eg(JSON.parse(e)), a(" --")
                            },
                            message: function() {
                                var e = r();
                                a("onMessage called from parent: " + e), em(JSON.parse(e)), a(" --")
                            }
                        };
                    G === ("" + n.data).slice(0, Z) && (!1 === j ? (o = i()) in d ? d[o]() : !e.exports && "iFrameResize" in window || window.jQuery !== t && "iFrameResize" in window.jQuery.prototype || s() || u("Unexpected message (" + n.data + ")") : s() ? d.init() : a('Ignored message of type "' + i() + '". Received before initialization.'))
                }), o(window, "readystatechange", C), C()
            }()
        },
        893: function(e, t, n) {
            "use strict";
            n.d(t, {
                K: function() {
                    return o
                }
            });
            var o = (0, n(4529).ZP)(function(e) {
                return {
                    widget: {},
                    setWidget: function(t) {
                        return e(function(e) {
                            return {
                                widget: t
                            }
                        })
                    }
                }
            })
        }
    },
    function(e) {
        e.O(0, [964, 774, 888, 179], function() {
            return e(e.s = 6877)
        }), _N_E = e.O()
    }
]);