"use strict";
(self.webpackChunk_N_E = self.webpackChunk_N_E || []).push([
    [523], {
        4523: function(e, t, r) {
            r.r(t), r.d(t, {
                default: function() {
                    return eB
                }
            });
            var l = r(5893),
                a = {
                    src: "/_next/static/media/logo.39fc3757.svg",
                    height: 194,
                    width: 937
                },
                o = r(5675),
                n = r.n(o),
                s = function(e) {
                    var t = e.size,
                        r = void 0 === t ? "md" : t,
                        o = {
                            sm: {
                                height: 21,
                                width: 101.6
                            },
                            md: {
                                height: 24,
                                width: 105.89
                            }
                        };
                    return (0, l.jsxs)("a", {
                        href: "https://praisehive.com?source=widget_powered_by",
                        target: "_blank",
                        rel: "noopener noreferrer",
                        className: "flex mx-auto w-fit items-center justify-center gap-1 ".concat({
                            sm: "mt-4",
                            md: "mt-8"
                        }[r]),
                        children: [(0, l.jsx)("span", {
                            className: "text-xs font-medium text-gray-900",
                            children: "Powered by"
                        }), (0, l.jsx)(n(), {
                            height: o[r].height,
                            width: o[r].width,
                            src: a.src,
                            alt: "PraiseHive Logo"
                        })]
                    })
                },
                i = r(7294),
                c = r(893),
                d = r(603),
                u = r(5585),
                x = r(2074),
                h = function(e) {
                    var t = e.selected,
                        r = e.onClick,
                        a = (0, c.K)(function(e) {
                            return e.widget
                        }),
                        o = a.layout,
                        n = a.style[o].pagination.color_current,
                        s = a.style[o].pagination.color_not_current;
                    return (0, l.jsx)("button", {
                        className: "transition rounded-full h-[10px] w-[10px]",
                        style: {
                            background: t ? n : s
                        },
                        type: "button",
                        "aria-label": "Item",
                        onClick: r
                    })
                },
                f = {
                    src: "/_next/static/media/default-user.e9f0b142.png",
                    height: 250,
                    width: 250,
                    blurDataURL: "data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAAgAAAAICAMAAADz0U65AAAAhFBMVEXQ1d3P1d3P1dzQ1NzP1N3P1NzQ1d3P1d3Q1d3P1d3P1dzP1NzP1dzP1NzP1d3P1N3P1d3P1N3P1d3P1N3P1dzP1d3P1d3P1d3P1dzP1d3P1dzP1d3P1NzQ1d3P1d3P1d3P1N3P1d3Q1d3P1d3P1d3P1dzP1NzQ1d3Q1dzP1d3Q1NzP1Nw42tL9AAAAJ3RSTlMAAAAAAAAWFigoLy8xMlRUWFh0dJaeqa2tvb3CwsfHyMjT8vf6/v4LpWPfAAAASElEQVR42gVABRKAIBBcTOzuJBQ5/v8/B+CHtSdn4PKpm1cmWKllrKMFikbfH0lBf0YIQxq766uydxuKO2ZBdOUIs3kYptT7AdbHBbVnq3qvAAAAAElFTkSuQmCC",
                    blurWidth: 8,
                    blurHeight: 8
                },
                m = r(3985),
                v = function(e) {
                    var t = e.onClick,
                        r = e.enabled,
                        a = (0, c.K)(function(e) {
                            return e.widget
                        }),
                        o = a.layout,
                        n = a.style[o].arrows.color;
                    return (0, l.jsx)("button", {
                        onClick: t,
                        disabled: !r,
                        "aria-label": "Next",
                        className: "flex items-center justify-center rounded-full h-10 w-10 transition text-gray-500 disabled:opacity-50",
                        style: {
                            stroke: n
                        },
                        children: (0, l.jsx)("svg", {
                            className: "w-8",
                            viewBox: "0 0 40 20",
                            fill: "none",
                            xmlns: "http://www.w3.org/2000/svg",
                            children: (0, l.jsx)("path", {
                                d: "M3.19443 9.99995H36.8055M36.8055 9.99995L30 16.8055M36.8055 9.99995L30 3.1944",
                                strokeWidth: "1.66667",
                                strokeLinecap: "round",
                                strokeLinejoin: "round"
                            })
                        })
                    })
                },
                g = function(e) {
                    var t = e.onClick,
                        r = e.enabled,
                        a = (0, c.K)(function(e) {
                            return e.widget
                        }),
                        o = a.layout,
                        n = a.style[o].arrows.color;
                    return (0, l.jsx)("button", {
                        onClick: t,
                        disabled: !r,
                        "aria-label": "Previous",
                        className: "flex items-center justify-center rounded-full h-10 w-10 transition text-gray-500 disabled:opacity-50",
                        style: {
                            stroke: n
                        },
                        children: (0, l.jsx)("svg", {
                            className: "w-8",
                            viewBox: "0 0 40 20",
                            fill: "none",
                            xmlns: "http://www.w3.org/2000/svg",
                            children: (0, l.jsx)("path", {
                                d: "M36.8055 9.99995H3.19443M3.19443 9.99995L9.99998 16.8055M3.19443 9.99995L9.99998 3.1944",
                                strokeWidth: "1.66667",
                                strokeLinecap: "round",
                                strokeLinejoin: "round"
                            })
                        })
                    })
                },
                p = r(4695),
                b = function(e) {
                    var t = e.onClick,
                        r = e.enabled,
                        a = (0, c.K)(function(e) {
                            return e.widget
                        }),
                        o = a.layout,
                        n = a.style[o].arrows.color;
                    return (0, l.jsx)("button", {
                        onClick: t,
                        disabled: !r,
                        "aria-label": "Next",
                        className: "flex items-center justify-center rounded-full h-10 w-10 transition text-gray-500 disabled:opacity-50",
                        style: {
                            color: n
                        },
                        children: (0, l.jsx)(p.Z, {
                            className: "h-6 w-6"
                        })
                    })
                },
                y = r(2249),
                j = function(e) {
                    var t = e.onClick,
                        r = e.enabled,
                        a = (0, c.K)(function(e) {
                            return e.widget
                        }),
                        o = a.layout,
                        n = a.style[o].arrows.color;
                    return (0, l.jsx)("button", {
                        onClick: t,
                        disabled: !r,
                        "aria-label": "Previous",
                        className: "flex items-center justify-center rounded-full h-10 w-10 transition text-gray-500 disabled:opacity-50",
                        style: {
                            color: n
                        },
                        children: (0, l.jsx)(y.Z, {
                            className: "h-6 w-6"
                        })
                    })
                },
                w = r(2728),
                _ = function(e) {
                    var t = e.onClick,
                        r = e.enabled,
                        a = (0, c.K)(function(e) {
                            return e.widget
                        }),
                        o = a.layout,
                        n = a.style[o].arrows.color;
                    return (0, l.jsx)("button", {
                        onClick: t,
                        disabled: !r,
                        "aria-label": "Next",
                        className: "flex items-center justify-center rounded-full h-10 w-10 transition text-gray-500 disabled:opacity-50",
                        style: {
                            color: n
                        },
                        children: (0, l.jsx)(w.Z, {
                            className: "h-6 w-6"
                        })
                    })
                },
                N = r(4742),
                k = function(e) {
                    var t = e.onClick,
                        r = e.enabled,
                        a = (0, c.K)(function(e) {
                            return e.widget
                        }),
                        o = a.layout,
                        n = a.style[o].arrows.color;
                    return (0, l.jsx)("button", {
                        onClick: t,
                        disabled: !r,
                        "aria-label": "Previous",
                        className: "flex items-center justify-center rounded-full h-10 w-10 transition text-gray-500 disabled:opacity-50",
                        style: {
                            color: n
                        },
                        children: (0, l.jsx)(N.Z, {
                            className: "h-6 w-6"
                        })
                    })
                },
                C = function(e) {
                    var t = e.direction,
                        r = e.onClick,
                        a = e.enabled,
                        o = (0, c.K)(function(e) {
                            return e.widget
                        });
                    return ({
                        arrow_short: {
                            next: (0, l.jsx)(b, {
                                onClick: r,
                                enabled: a
                            }),
                            prev: (0, l.jsx)(j, {
                                onClick: r,
                                enabled: a
                            })
                        },
                        arrow_chevron: {
                            next: (0, l.jsx)(_, {
                                onClick: r,
                                enabled: a
                            }),
                            prev: (0, l.jsx)(k, {
                                onClick: r,
                                enabled: a
                            })
                        },
                        arrow_long: {
                            next: (0, l.jsx)(v, {
                                onClick: r,
                                enabled: a
                            }),
                            prev: (0, l.jsx)(g, {
                                onClick: r,
                                enabled: a
                            })
                        }
                    })[o.style.carousel.arrows.type][t]
                },
                A = r(1664),
                P = r.n(A),
                S = {
                    src: "/_next/static/media/thumbnail-not-found.a78a3f87.png",
                    height: 576,
                    width: 1024,
                    blurDataURL: "data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAAgAAAAFCAMAAABPT11nAAAAOVBMVEXS19/Q1d3P1NzO09vN0tvN0trM0drM0dnL0NjJztfIzdXFytPAxc6+xM27wMq4vsi0usSzucOwtsAoRkU7AAAAL0lEQVR42g3FyQEAIAgDsFJFvEH3H1bzCUjRRCEE/cT4mepoiRnz7uUeE7RCq5YfFNQBF7d8jLYAAAAASUVORK5CYII=",
                    blurWidth: 8,
                    blurHeight: 5
                },
                F = {
                    display: "avatars_default_horizontal",
                    rating: {
                        enabled: !0,
                        type: "star",
                        color_empty: "#f2f4f7",
                        color_filled: "#fec84b",
                        average: {
                            enabled: !0,
                            color_text: "#101828"
                        }
                    },
                    avatars: {
                        count: 6,
                        border: {
                            width: 2,
                            color: "#ffffff"
                        }
                    },
                    text: {
                        enabled: !0,
                        color_text: "#475467",
                        custom_text: ""
                    }
                },
                B = {
                    display: "carousel_simple_centered",
                    arrows: {
                        enabled: !0,
                        type: "arrow_chevron",
                        color: "#344054"
                    },
                    pagination: {
                        enabled: !0,
                        type: "dot",
                        color_current: "#3538cd",
                        color_not_current: "#f2f4f7"
                    },
                    rating: {
                        enabled: !0,
                        type: "star",
                        color_empty: "#f2f4f7",
                        color_filled: "#fec84b"
                    },
                    author: {
                        color_name: "#101828",
                        color_description: "#475467"
                    },
                    background: {
                        enabled: !1,
                        color_primary: "#ffffff",
                        color_secondary: "#ffffff"
                    },
                    text: {
                        color_text: "#101828",
                        color_text_highlight: "#fef08a"
                    },
                    source: {
                        enabled: !0
                    }
                },
                K = function(e) {
                    var t, r = e.layout,
                        l = e.style;
                    return (null === (t = l[r]) || void 0 === t ? void 0 : t.rating) ? l[r].rating.enabled : E[r].rating.enabled
                },
                z = function(e) {
                    var t, r = e.layout,
                        l = e.style;
                    return (null === (t = l[r]) || void 0 === t ? void 0 : t.source) ? l[r].source.enabled : E[r].source.enabled
                },
                E = {
                    carousel: B,
                    masonry: {
                        display: "masonry_default",
                        rating: {
                            enabled: !0,
                            type: "star",
                            color_empty: "#f2f4f7",
                            color_filled: "#fec84b"
                        },
                        author: {
                            color_name: "#101828",
                            color_description: "#667085"
                        },
                        background: {
                            enabled: !0,
                            color_primary: "#ffffff",
                            color_secondary: "#ffffff"
                        },
                        text: {
                            color_text: "#667085",
                            color_text_highlight: "#fef08a"
                        },
                        border: {
                            enabled: !0,
                            color: "#eaecf0"
                        },
                        source: {
                            enabled: !0
                        }
                    },
                    avatars: F
                },
                R = "#fef08a",
                Z = r(819),
                I = function(e) {
                    var t, r, a = e.rating,
                        o = e.size,
                        n = void 0 === o ? "sm" : o,
                        s = (0, c.K)(function(e) {
                            return e.widget
                        }),
                        i = s.layout,
                        d = (null === (t = s.style[i].rating) || void 0 === t ? void 0 : t.color_empty) || E[i].rating.color_empty,
                        u = (null === (r = s.style[i].rating) || void 0 === r ? void 0 : r.color_filled) || E[i].rating.color_filled,
                        x = {
                            sm: "h-5 w-5",
                            md: "h-6 w-6"
                        };
                    return (0, l.jsx)(l.Fragment, {
                        children: [0, 1, 2, 3, 4].map(function(e) {
                            return (0, l.jsx)(Z.Z, {
                                className: "".concat(x[n], " flex-shrink-0"),
                                style: {
                                    color: a > e ? u : d
                                },
                                "aria-hidden": "true"
                            }, e)
                        })
                    })
                },
                L = r(4539),
                M = function(e) {
                    var t, r, a, o, n, s, d, u, x, h, f = e.testimonial,
                        m = (0, i.useState)(!1),
                        v = m[0],
                        g = m[1],
                        p = K((0, c.K)(function(e) {
                            return e.widget
                        })),
                        b = (0, i.useRef)(null),
                        y = (0, L.Zz)(b).paused,
                        j = "https://image.mux.com/".concat(null === (r = null === (t = f.video) || void 0 === t ? void 0 : t.data.playback_ids[0]) || void 0 === r ? void 0 : r.id),
                        w = "animated.webp?width=640&fps=30",
                        _ = v ? "".concat(j, "/").concat(w) : "".concat(j, "/thumbnail.jpg"),
                        N = (null === (a = f.video) || void 0 === a ? void 0 : a.data.playback_ids) ? _ : S.src;
                    (0, i.useEffect)(function() {
                        var e;
                        (e = new Image).src = "".concat(j, "/").concat(w), e.onload = function() {
                            return g(!0)
                        }, e.onerror = function(e) {
                            return console.error(e)
                        }
                    }, []);
                    var k = (null === (o = f.video) || void 0 === o ? void 0 : o.data.playback_ids) ? "https://stream.mux.com/".concat(null === (d = null === (n = f.video) || void 0 === n ? void 0 : null === (s = n.data) || void 0 === s ? void 0 : s.playback_ids[0]) || void 0 === d ? void 0 : d.id, ".m3u8") : "",
                        C = (null === (u = f.video) || void 0 === u ? void 0 : null === (x = u.data) || void 0 === x ? void 0 : null === (h = x.aspect_ratio) || void 0 === h ? void 0 : h.replace(":", "/")) || "16/9";
                    return (0, l.jsx)("div", {
                        className: "rounded-xl relative h-[280px] bg-transparent overflow-hidden [&>vds-media]:flex ",
                        style: {
                            aspectRatio: C
                        },
                        children: (0, l.jsxs)(L.Sy, {
                            src: k,
                            poster: N,
                            ref: b,
                            userIdleDelay: 1e3,
                            controls: !y,
                            children: [(0, l.jsx)(L.Z2, {
                                className: " [&>shadow-root>video]:h-[280px] [&>shadow-root>video]:w-full"
                            }), y && (0, l.jsx)("div", {
                                className: "absolute top-0 left-0 transition h-full w-full rounded-xl opacity-100 media-user-idle:opacity-0",
                                children: (0, l.jsxs)("div", {
                                    className: "relative w-full h-full",
                                    children: [(0, l.jsx)("div", {
                                        className: "w-full h-full rounded-xl bg-black bg-opacity-20"
                                    }), (0, l.jsx)("div", {
                                        className: "absolute top-1/2 left-1/2 transform -translate-x-1/2 -translate-y-1/2",
                                        children: (0, l.jsx)(L.UU, {
                                            className: "flex",
                                            "aria-label": "Play",
                                            children: (0, l.jsxs)("svg", {
                                                className: "w-9 h-9 sm:w-12 sm:h-12 paused:block hidden",
                                                viewBox: "0 0 56 56",
                                                fill: "none",
                                                xmlns: "http://www.w3.org/2000/svg",
                                                children: [(0, l.jsx)("g", {
                                                    filter: "url(#filter0_b_1282_24782)",
                                                    children: (0, l.jsx)("path", {
                                                        fillRule: "evenodd",
                                                        clipRule: "evenodd",
                                                        d: "M28 56C43.464 56 56 43.464 56 28C56 12.536 43.464 0 28 0C12.536 0 0 12.536 0 28C0 43.464 12.536 56 28 56ZM23.625 38.2705L39.375 29.4672C40.5417 28.8151 40.5417 27.1849 39.375 26.5328L23.625 17.7295C22.4583 17.0774 21 17.8925 21 19.1967V36.8033C21 38.1075 22.4583 38.9226 23.625 38.2705Z",
                                                        fill: "white",
                                                        fillOpacity: "0.3"
                                                    })
                                                }), (0, l.jsx)("defs", {
                                                    children: (0, l.jsxs)("filter", {
                                                        id: "filter0_b_1282_24782",
                                                        x: "-16",
                                                        y: "-16",
                                                        width: "88",
                                                        height: "88",
                                                        filterUnits: "userSpaceOnUse",
                                                        colorInterpolationFilters: "sRGB",
                                                        children: [(0, l.jsx)("feFlood", {
                                                            floodOpacity: "0",
                                                            result: "BackgroundImageFix"
                                                        }), (0, l.jsx)("feGaussianBlur", { in: "BackgroundImageFix",
                                                            stdDeviation: "8"
                                                        }), (0, l.jsx)("feComposite", {
                                                            in2: "SourceAlpha",
                                                            operator: "in",
                                                            result: "effect1_backgroundBlur_1282_24782"
                                                        }), (0, l.jsx)("feBlend", {
                                                            mode: "normal",
                                                            in: "SourceGraphic",
                                                            in2: "effect1_backgroundBlur_1282_24782",
                                                            result: "shape"
                                                        })]
                                                    })
                                                })]
                                            })
                                        })
                                    }), (0, l.jsx)("div", {
                                        className: "absolute left-1/2 transform -translate-x-1/2 bottom-4",
                                        children: (0, l.jsxs)("div", {
                                            className: "flex flex-col text-white text-center truncate",
                                            children: [(0, l.jsx)("p", {
                                                className: "text-lg font-semibold truncate",
                                                children: f.author_name
                                            }), (0, l.jsx)("p", {
                                                className: "text-md truncate",
                                                children: f.author_description
                                            }), f.rating && p && (0, l.jsx)("div", {
                                                className: "flex justify-center gap-1 mt-2",
                                                children: (0, l.jsx)(I, {
                                                    rating: f.rating
                                                })
                                            })]
                                        })
                                    })]
                                })
                            })]
                        })
                    })
                },
                U = r(9107),
                H = {
                    src: "/_next/static/media/icon.12c4bb6f.svg",
                    height: 256,
                    width: 256
                },
                Q = {
                    src: "/_next/static/media/capterra.daf48521.svg",
                    height: 32,
                    width: 32
                },
                O = {
                    src: "/_next/static/media/facebook.a79d236a.svg",
                    height: 32,
                    width: 32
                },
                D = {
                    src: "/_next/static/media/g2.c13db281.svg",
                    height: 32,
                    width: 32
                },
                V = {
                    src: "/_next/static/media/google.7da6af1e.svg",
                    height: 32,
                    width: 32
                },
                W = {
                    src: "/_next/static/media/linkedin.215c1001.svg",
                    height: 32,
                    width: 32
                },
                q = {
                    src: "/_next/static/media/product-hunt.873ae555.svg",
                    height: 32,
                    width: 32
                },
                T = {
                    src: "/_next/static/media/reddit.efbfea6c.svg",
                    height: 32,
                    width: 32
                },
                G = {
                    src: "/_next/static/media/trustpilot.abba0fcb.svg",
                    height: 32,
                    width: 32
                },
                J = {
                    src: "/_next/static/media/twitter.4621864c.svg",
                    height: 32,
                    width: 32
                },
                Y = {
                    src: "/_next/static/media/yelp.b798c422.svg",
                    height: 32,
                    width: 32
                },
                X = function(e) {
                    switch (e.source) {
                        case "capterra":
                            return {
                                svg: Q,
                                background: "#e4e8e7"
                            };
                        case "facebook":
                            return {
                                svg: O,
                                background: "#cee6fb"
                            };
                        case "g2":
                            return {
                                svg: D,
                                background: "#ffdad4"
                            };
                        case "google":
                            return {
                                svg: V,
                                background: "#eae7df"
                            };
                        case "linkedin":
                            return {
                                svg: W,
                                background: "#cee0f2"
                            };
                        case "product_hunt":
                            return {
                                svg: q,
                                background: "#f7dcd5"
                            };
                        case "reddit":
                            return {
                                svg: T,
                                background: "#fedad2"
                            };
                        case "testimonial_text":
                        case "testimonial_video":
                            return {
                                svg: H,
                                background: "#d9dbfa"
                            };
                        case "trustpilot":
                            return {
                                svg: G,
                                background: "#000032"
                            };
                        case "twitter":
                            return {
                                svg: J,
                                background: "#daeef8"
                            };
                        case "yelp":
                            return {
                                svg: Y,
                                background: "#f2d3d5"
                            };
                        default:
                            throw Error("Source not recognized")
                    }
                },
                $ = function() {
                    for (var e = arguments.length, t = Array(e), r = 0; r < e; r++) t[r] = arguments[r];
                    return t.filter(Boolean).join(" ")
                },
                ee = function(e) {
                    var t = e.testimonial,
                        r = (0, c.K)(function(e) {
                            return e.widget
                        }),
                        a = K(r),
                        o = z(r),
                        s = r.style[r.layout].text.color_text_highlight || R;
                    return (0, l.jsxs)("div", {
                        className: "flex flex-col px-4 items-center justify-center",
                        style: {
                            flex: "0 0 100%"
                        },
                        children: ["testimonial_video" === t.source && (0, l.jsx)(M, {
                            testimonial: t
                        }), "testimonial_video" !== t.source && (0, l.jsxs)(l.Fragment, {
                            children: [(0, l.jsx)("div", {
                                className: "text-2xl font-medium text-center mb-8 md:text-4xl",
                                style: {
                                    color: r.style[r.layout].text.color_text
                                },
                                children: (0, l.jsx)(m.D, {
                                    components: {
                                        a: function(e) {
                                            return (0, l.jsx)("a", {
                                                href: e.href,
                                                target: "_blank",
                                                rel: "noopener noreferrer",
                                                children: e.children
                                            })
                                        },
                                        strong: function(e) {
                                            return (0, l.jsx)("strong", {
                                                className: "inline box-decoration-clone rounded py-[0.5px] lg:rounded-md",
                                                style: {
                                                    boxShadow: "4px 0 0 ".concat(s, ", -4px 0 0 ").concat(s),
                                                    background: s
                                                },
                                                children: e.children
                                            })
                                        }
                                    },
                                    children: t.text
                                })
                            }), (0, l.jsxs)("div", {
                                className: "relative h-16 w-16",
                                children: [(0, l.jsx)(n(), {
                                    height: 64,
                                    width: 64,
                                    src: t.author_picture_url || f.src,
                                    alt: t.author_name,
                                    className: "rounded-full object-cover flex flex-shrink-0"
                                }), o && (0, l.jsx)(P(), {
                                    passHref: !0,
                                    href: t.source_url || "https://praisehive.com",
                                    children: (0, l.jsx)("a", {
                                        target: "_blank",
                                        rel: "noopener noreferrer nofollow",
                                        className: "absolute flex items-center justify-center w-[22px] h-[22px] -bottom-0.5 -right-0.5 border-2 rounded-full ",
                                        style: {
                                            background: X(t).background,
                                            borderColor: r.style[r.layout].background.color_primary
                                        },
                                        children: (0, l.jsx)(n(), {
                                            height: 14,
                                            width: 14,
                                            src: X(t).svg.src,
                                            alt: t.source
                                        })
                                    })
                                })]
                            }), (0, l.jsx)("p", {
                                className: "text-lg font-semibold text-center mt-4 mb-1",
                                style: {
                                    color: r.style[r.layout].author.color_name
                                },
                                children: t.author_name
                            }), (0, l.jsx)("a", {
                                href: t.author_custom_url || void 0,
                                target: "_blank",
                                rel: "noopener noreferrer",
                                className: "text-md text-center",
                                style: {
                                    color: r.style[r.layout].author.color_description
                                },
                                children: t.author_description
                            }), t.rating && a && (0, l.jsx)("div", {
                                className: "flex gap-1 mt-4",
                                children: (0, l.jsx)(I, {
                                    rating: t.rating
                                })
                            })]
                        })]
                    })
                },
                et = (0, x.Z)({
                    delay: 1e4
                }),
                er = function() {
                    var e = (0, c.K)(function(e) {
                            return e.widget
                        }),
                        t = e.style.carousel,
                        r = (null == t ? void 0 : t.background) ? t.background.enabled : B.background.enabled,
                        a = r ? t.background.color_primary : "transparent",
                        o = (0, i.useState)(!1),
                        n = o[0],
                        s = o[1],
                        x = e.style,
                        f = (0, d.Z)((0, u.Z)({
                            skipSnaps: !1,
                            loop: !0
                        }, n ? [(0, U.Z)(), et] : []), 2),
                        m = f[0],
                        v = f[1];
                    (0, i.useEffect)(function() {
                        v && !n && s(!0)
                    }, [v]);
                    var g = (0, i.useState)(!1),
                        p = g[0],
                        b = g[1],
                        y = (0, i.useState)(!1),
                        j = y[0],
                        w = y[1],
                        _ = (0, i.useState)(0),
                        N = _[0],
                        k = _[1],
                        A = (0, i.useState)([]),
                        P = A[0],
                        S = A[1],
                        F = (0, i.useCallback)(function() {
                            return v && v.scrollPrev()
                        }, [v]),
                        K = (0, i.useCallback)(function() {
                            return v && v.scrollNext()
                        }, [v]),
                        z = (0, i.useCallback)(function(e) {
                            return v && v.scrollTo(e)
                        }, [v]),
                        E = (0, i.useCallback)(function() {
                            v && (k(v.selectedScrollSnap()), b(v.canScrollPrev()), w(v.canScrollNext()))
                        }, [v, k]);
                    return (0, i.useEffect)(function() {
                        v && (E(), S(v.scrollSnapList()), v.on("select", E))
                    }, [v, S, E]), (0, l.jsxs)("div", {
                        className: $(r ? "py-10 px-6 md:p-16" : "", "w-full relative rounded-2xl"),
                        style: {
                            backgroundColor: a
                        },
                        children: [(0, l.jsxs)("div", {
                            className: "flex ",
                            children: [x.carousel.arrows.enabled && (0, l.jsx)("div", {
                                className: "hidden sm:flex items-center cursor-pointer",
                                onClick: F,
                                children: (0, l.jsx)(C, {
                                    direction: "prev",
                                    onClick: function() {},
                                    enabled: p
                                })
                            }), (0, l.jsx)("div", {
                                className: "overflow-hidden",
                                ref: m,
                                children: (0, l.jsx)("div", {
                                    className: "flex items-start",
                                    children: e.testimonials.map(function(e) {
                                        return (0, l.jsx)(ee, {
                                            testimonial: e
                                        }, e.id)
                                    })
                                })
                            }), x.carousel.arrows.enabled && (0, l.jsx)("div", {
                                className: "hidden sm:flex items-center cursor-pointer",
                                onClick: K,
                                children: (0, l.jsx)(C, {
                                    direction: "next",
                                    onClick: function() {},
                                    enabled: j
                                })
                            })]
                        }), x.carousel.pagination.enabled && (0, l.jsx)("div", {
                            className: "flex w-full justify-center gap-4 mt-10",
                            children: P.map(function(e, t) {
                                return (0, l.jsx)(h, {
                                    selected: t === N,
                                    onClick: function() {
                                        return z(t)
                                    }
                                }, t)
                            })
                        })]
                    })
                },
                el = function(e) {
                    var t, r, a, o, n, s, c, d, u, x, h = e.testimonial,
                        f = (0, i.useState)(!1),
                        m = f[0],
                        v = f[1],
                        g = (0, i.useRef)(null),
                        p = (0, L.Zz)(g).paused,
                        b = "https://image.mux.com/".concat(null === (r = null === (t = h.video) || void 0 === t ? void 0 : t.data.playback_ids[0]) || void 0 === r ? void 0 : r.id),
                        y = "animated.webp?width=640&fps=30",
                        j = m ? "".concat(b, "/").concat(y) : "".concat(b, "/thumbnail.jpg"),
                        w = (null === (a = h.video) || void 0 === a ? void 0 : a.data.playback_ids) ? j : S.src;
                    (0, i.useEffect)(function() {
                        var e;
                        (e = new Image).src = "".concat(b, "/").concat(y), e.onload = function() {
                            return v(!0)
                        }, e.onerror = function(e) {
                            return console.error(e)
                        }
                    }, []);
                    var _ = (null === (o = h.video) || void 0 === o ? void 0 : o.data.playback_ids) ? "https://stream.mux.com/".concat(null === (c = null === (n = h.video) || void 0 === n ? void 0 : null === (s = n.data) || void 0 === s ? void 0 : s.playback_ids[0]) || void 0 === c ? void 0 : c.id, ".m3u8") : "",
                        N = (null === (d = h.video) || void 0 === d ? void 0 : null === (u = d.data) || void 0 === u ? void 0 : null === (x = u.aspect_ratio) || void 0 === x ? void 0 : x.replace(":", "/")) || "16/9";
                    return (0, l.jsx)("div", {
                        className: "relative rounded-2xl w-48 h-48 object-cover lg:w-80 lg:h-80  overflow-hidden",
                        style: {
                            aspectRatio: N
                        },
                        children: (0, l.jsxs)(L.Sy, {
                            src: _,
                            poster: w,
                            ref: g,
                            userIdleDelay: 1e3,
                            controls: !p,
                            children: [(0, l.jsx)(L.Z2, {
                                className: "[&>shadow-root>video]:rounded-2xl [&>shadow-root>video]:w-48 [&>shadow-root>video]:h-48 [&>shadow-root>video]:lg:w-80 [&>shadow-root>video]:lg:h-80 [&>shadow-root>video]:object-cover"
                            }), p && (0, l.jsx)("div", {
                                className: "absolute top-0 left-0 transition h-full w-full rounded-2xl opacity-100 media-user-idle:opacity-0",
                                children: (0, l.jsxs)("div", {
                                    className: "relative w-full h-full",
                                    children: [(0, l.jsx)("div", {
                                        className: "w-full h-full rounded-2xl bg-black bg-opacity-20"
                                    }), (0, l.jsx)("div", {
                                        className: "absolute top-1/2 left-1/2 transform -translate-x-1/2 -translate-y-1/2",
                                        children: (0, l.jsx)(L.UU, {
                                            className: "flex",
                                            "aria-label": "Play",
                                            children: (0, l.jsxs)("svg", {
                                                className: "w-9 h-9 sm:w-12 sm:h-12 paused:block hidden",
                                                viewBox: "0 0 56 56",
                                                fill: "none",
                                                xmlns: "http://www.w3.org/2000/svg",
                                                children: [(0, l.jsx)("g", {
                                                    filter: "url(#filter0_b_1282_24782)",
                                                    children: (0, l.jsx)("path", {
                                                        fillRule: "evenodd",
                                                        clipRule: "evenodd",
                                                        d: "M28 56C43.464 56 56 43.464 56 28C56 12.536 43.464 0 28 0C12.536 0 0 12.536 0 28C0 43.464 12.536 56 28 56ZM23.625 38.2705L39.375 29.4672C40.5417 28.8151 40.5417 27.1849 39.375 26.5328L23.625 17.7295C22.4583 17.0774 21 17.8925 21 19.1967V36.8033C21 38.1075 22.4583 38.9226 23.625 38.2705Z",
                                                        fill: "white",
                                                        fillOpacity: "0.3"
                                                    })
                                                }), (0, l.jsx)("defs", {
                                                    children: (0, l.jsxs)("filter", {
                                                        id: "filter0_b_1282_24782",
                                                        x: "-16",
                                                        y: "-16",
                                                        width: "88",
                                                        height: "88",
                                                        filterUnits: "userSpaceOnUse",
                                                        colorInterpolationFilters: "sRGB",
                                                        children: [(0, l.jsx)("feFlood", {
                                                            floodOpacity: "0",
                                                            result: "BackgroundImageFix"
                                                        }), (0, l.jsx)("feGaussianBlur", { in: "BackgroundImageFix",
                                                            stdDeviation: "8"
                                                        }), (0, l.jsx)("feComposite", {
                                                            in2: "SourceAlpha",
                                                            operator: "in",
                                                            result: "effect1_backgroundBlur_1282_24782"
                                                        }), (0, l.jsx)("feBlend", {
                                                            mode: "normal",
                                                            in: "SourceGraphic",
                                                            in2: "effect1_backgroundBlur_1282_24782",
                                                            result: "shape"
                                                        })]
                                                    })
                                                })]
                                            })
                                        })
                                    })]
                                })
                            })]
                        })
                    })
                },
                ea = (0, x.Z)({
                    delay: 1e4
                }),
                eo = function() {
                    var e = (0, c.K)(function(e) {
                            return e.widget
                        }),
                        t = e.style.carousel,
                        r = (null == t ? void 0 : t.background) ? t.background.enabled : B.background.enabled,
                        a = r ? t.background.color_primary : "transparent",
                        o = K(e),
                        s = (0, i.useState)(!1),
                        x = s[0],
                        v = s[1],
                        g = e.style,
                        p = (0, d.Z)((0, u.Z)({
                            skipSnaps: !1,
                            loop: !0
                        }, x ? [(0, U.Z)(), ea] : []), 2),
                        b = p[0],
                        y = p[1];
                    (0, i.useEffect)(function() {
                        y && !x && v(!0)
                    }, [y]);
                    var j = (0, i.useState)(!1),
                        w = j[0],
                        _ = j[1],
                        N = (0, i.useState)(!1),
                        k = N[0],
                        A = N[1],
                        S = (0, i.useState)(0),
                        F = S[0],
                        E = S[1],
                        Z = (0, i.useState)([]),
                        L = Z[0],
                        M = Z[1],
                        H = (0, i.useCallback)(function() {
                            return y && y.scrollPrev()
                        }, [y]),
                        Q = (0, i.useCallback)(function() {
                            return y && y.scrollNext()
                        }, [y]),
                        O = (0, i.useCallback)(function(e) {
                            return y && y.scrollTo(e)
                        }, [y]),
                        D = (0, i.useCallback)(function() {
                            y && (E(y.selectedScrollSnap()), _(y.canScrollPrev()), A(y.canScrollNext()))
                        }, [y, E]);
                    (0, i.useEffect)(function() {
                        y && (D(), M(y.scrollSnapList()), y.on("select", D))
                    }, [y, M, D]);
                    var V = e.style[e.layout].text.color_text_highlight || R,
                        W = z(e);
                    return (0, l.jsx)("div", {
                        className: $(r ? "px-4 py-10 sm:p-10 lg:p-16" : "", "w-full relative rounded-2xl"),
                        style: {
                            backgroundColor: a
                        },
                        children: (0, l.jsx)("div", {
                            children: (0, l.jsxs)("div", {
                                className: "overflow-hidden ",
                                ref: b,
                                children: [(0, l.jsx)("div", {
                                    className: "flex items-start ",
                                    children: e.testimonials.map(function(t) {
                                        return (0, l.jsxs)("div", {
                                            className: "flex flex-col gap-10 sm:flex-row lg:gap-32",
                                            style: {
                                                flex: "0 0 100%"
                                            },
                                            children: ["testimonial_video" === t.source && (0, l.jsx)(el, {
                                                testimonial: t
                                            }), "testimonial_video" !== t.source && (0, l.jsxs)("div", {
                                                className: "relative flex flex-shrink-0 w-48 h-48 lg:w-80 lg:h-80",
                                                children: [(0, l.jsx)(n(), {
                                                    layout: "fill",
                                                    className: "rounded-2xl object-cover",
                                                    src: t.author_picture_url || f.src,
                                                    alt: t.author_name
                                                }), W && (0, l.jsx)(P(), {
                                                    passHref: !0,
                                                    href: t.source_url || "https://praisehive.com",
                                                    children: (0, l.jsx)("a", {
                                                        target: "_blank",
                                                        rel: "noopener noreferrer nofollow",
                                                        className: "absolute flex items-center justify-center w-7 h-7 bottom-2 right-2 rounded-lg lg:w-10 lg:h-10 lg:bottom-3 lg:right-3 lg:rounded-lg shadow-sm",
                                                        style: {
                                                            background: X(t).background,
                                                            borderColor: e.style[e.layout].background.color_primary
                                                        },
                                                        children: (0, l.jsx)("div", {
                                                            className: "relative h-[18px] w-[18px] lg:h-6 lg:w-6",
                                                            children: (0, l.jsx)(n(), {
                                                                layout: "fill",
                                                                src: X(t).svg.src,
                                                                alt: t.source
                                                            })
                                                        })
                                                    })
                                                })]
                                            }), (0, l.jsxs)("div", {
                                                className: "flex flex-col flex-1",
                                                children: [t.rating && o && (0, l.jsx)("div", {
                                                    className: "flex gap-1 mb-4 lg:mb-6",
                                                    children: (0, l.jsx)(I, {
                                                        rating: t.rating
                                                    })
                                                }), (0, l.jsx)("div", {
                                                    className: "text-2xl font-medium mb-8 lg:text-4xl",
                                                    style: {
                                                        color: e.style[e.layout].text.color_text
                                                    },
                                                    children: (0, l.jsx)(m.D, {
                                                        components: {
                                                            a: function(e) {
                                                                return (0, l.jsx)("a", {
                                                                    href: e.href,
                                                                    target: "_blank",
                                                                    rel: "noopener noreferrer",
                                                                    children: e.children
                                                                })
                                                            },
                                                            strong: function(e) {
                                                                return (0, l.jsx)("strong", {
                                                                    className: "inline box-decoration-clone rounded py-[0.5px] lg:rounded-md",
                                                                    style: {
                                                                        boxShadow: "4px 0 0 ".concat(V, ", -4px 0 0 ").concat(V),
                                                                        background: V
                                                                    },
                                                                    children: e.children
                                                                })
                                                            }
                                                        },
                                                        children: t.text
                                                    })
                                                }), (0, l.jsx)("div", {
                                                    className: "flex gap-2 w-full justify-between items-end",
                                                    children: (0, l.jsxs)("div", {
                                                        children: [(0, l.jsxs)("p", {
                                                            className: "text-lg font-semibold mb-1 line-clamp-1",
                                                            style: {
                                                                color: e.style[e.layout].author.color_name
                                                            },
                                                            children: ["— ", t.author_name]
                                                        }), (0, l.jsx)("a", {
                                                            href: t.author_custom_url || void 0,
                                                            target: "_blank",
                                                            rel: "noopener noreferrer",
                                                            className: "text-base line-clamp-1",
                                                            style: {
                                                                color: e.style[e.layout].author.color_description
                                                            },
                                                            children: t.author_description
                                                        })]
                                                    })
                                                })]
                                            })]
                                        }, t.id)
                                    })
                                }), (g.carousel.pagination.enabled || g.carousel.arrows.enabled) && (0, l.jsxs)("div", {
                                    className: $(g.carousel.pagination.enabled && g.carousel.arrows.enabled ? "justify-between" : "justify-center", "flex items-center mt-10"),
                                    children: [g.carousel.pagination.enabled && (0, l.jsx)("div", {
                                        className: "flex gap-4 ",
                                        children: L.map(function(e, t) {
                                            return (0, l.jsx)(h, {
                                                selected: t === F,
                                                onClick: function() {
                                                    return O(t)
                                                }
                                            }, t)
                                        })
                                    }), g.carousel.arrows.enabled && (0, l.jsxs)("div", {
                                        className: "flex items-center gap-8",
                                        children: [(0, l.jsx)(C, {
                                            direction: "prev",
                                            onClick: H,
                                            enabled: w
                                        }), (0, l.jsx)(C, {
                                            direction: "next",
                                            onClick: Q,
                                            enabled: k
                                        })]
                                    })]
                                })]
                            })
                        })
                    })
                },
                en = function() {
                    var e = (0, c.K)(function(e) {
                        return e.widget
                    }).style.carousel.display;
                    switch ((0, i.useEffect)(function() {
                        window.document.documentElement.style.removeProperty("width")
                    }), e) {
                        case "carousel_simple_centered":
                            return (0, l.jsx)(er, {});
                        case "carousel_simple_left_aligned":
                            return (0, l.jsx)(eo, {});
                        default:
                            return null
                    }
                },
                es = r(1799),
                ei = function(e) {
                    var t = e.testimonial,
                        r = (0, c.K)(function(e) {
                            return e.widget
                        }),
                        a = z(r);
                    return (0, l.jsx)("div", {
                        className: "flex justify-between gap-6 mt-4",
                        children: (0, l.jsxs)("div", {
                            className: "flex w-full",
                            children: [(0, l.jsx)("div", {
                                className: "max-w-11 max-h-11 min-w-11 min-h-11 h-11 w-11 mr-3 ",
                                children: (0, l.jsx)(n(), {
                                    height: 44,
                                    width: 44,
                                    src: t.author_picture_url || f.src,
                                    alt: t.author_name,
                                    className: "rounded-full object-cover flex flex-shrink-0"
                                })
                            }), (0, l.jsxs)("div", {
                                className: "flex w-full gap-2 justify-between items-end overflow-hidden",
                                children: [(0, l.jsxs)("div", {
                                    className: "overflow-hidden",
                                    children: [(0, l.jsx)("p", {
                                        className: "text-md font-semibold line-clamp-1",
                                        style: {
                                            color: r.style[r.layout].author.color_name
                                        },
                                        children: t.author_name
                                    }), (0, l.jsx)("a", {
                                        href: t.author_custom_url || void 0,
                                        target: "_blank",
                                        rel: "noopener noreferrer",
                                        className: "text-sm line-clamp-1",
                                        style: {
                                            color: r.style[r.layout].author.color_description
                                        },
                                        children: (0, l.jsx)("p", {
                                            children: t.author_description
                                        })
                                    })]
                                }), a && (0, l.jsx)(P(), {
                                    passHref: !0,
                                    href: t.source_url || "https://praisehive.com",
                                    children: (0, l.jsx)("a", {
                                        target: "_blank",
                                        rel: "noopener noreferrer nofollow",
                                        className: "flex flex-shrink-0 items-center justify-center w-5 h-5 pb-1 rounded-full ",
                                        children: (0, l.jsx)(n(), {
                                            height: 20,
                                            width: 20,
                                            src: X(t).svg.src,
                                            alt: t.source
                                        })
                                    })
                                })]
                            })]
                        })
                    })
                },
                ec = function(e) {
                    var t, r = e.testimonial,
                        a = (0, c.K)(function(e) {
                            return e.widget
                        }),
                        o = a.style[a.layout].text.color_text_highlight || R;
                    return (0, l.jsxs)(l.Fragment, {
                        children: [(0, l.jsx)("div", {
                            className: "prose prose-p:my-0 prose-a:font-semibold prose-a:no-underline",
                            style: {
                                color: a.style[a.layout].text.color_text
                            },
                            children: (0, l.jsx)(m.D, {
                                components: {
                                    a: function(e) {
                                        return (0, l.jsx)("a", {
                                            href: e.href,
                                            target: "_blank",
                                            rel: "noopener noreferrer",
                                            children: e.children
                                        })
                                    },
                                    strong: function(e) {
                                        return (0, l.jsx)("strong", {
                                            className: "inline box-decoration-clone rounded py-[0.5]",
                                            style: {
                                                boxShadow: "3px 0 0 ".concat(o, ", -3px 0 0 ").concat(o),
                                                background: o
                                            },
                                            children: e.children
                                        })
                                    }
                                },
                                children: r.text
                            })
                        }), !!(null === (t = r.attachments) || void 0 === t ? void 0 : t.length) && (0, l.jsx)("div", {
                            className: "flex mt-2 gap-2 flex-wrap",
                            children: r.attachments.map(function(e, t) {
                                return e.visible ? "image" === e.type ? (0, l.jsx)("div", {
                                    className: $(e.visible ? "" : "grayscale", "relative h-20 rounded-md overflow-hidden"),
                                    style: {
                                        aspectRatio: e.width / e.height
                                    },
                                    children: (0, l.jsx)(n(), {
                                        src: e.image_url,
                                        width: e.width,
                                        height: e.height,
                                        alt: "Image attachment"
                                    })
                                }, t) : (0, l.jsx)(l.Fragment, {}) : (0, l.jsx)(l.Fragment, {})
                            })
                        })]
                    })
                },
                ed = function(e) {
                    var t = e.testimonial;
                    return (0, l.jsxs)("div", {
                        className: "mb-3",
                        children: [(0, l.jsx)("div", {
                            className: "flex items-center gap-1",
                            children: (0, l.jsx)(I, {
                                rating: t.rating
                            })
                        }), (0, l.jsxs)("p", {
                            className: "sr-only",
                            children: [t.rating, " out of 5 stars"]
                        })]
                    })
                },
                eu = r(5311),
                ex = r(3090),
                eh = function(e) {
                    var t, r, a, o, n, s, d, u, x, h, f = e.testimonial,
                        m = (0, i.useState)(!1),
                        v = m[0],
                        g = m[1],
                        p = K((0, c.K)(function(e) {
                            return e.widget
                        })),
                        b = (0, i.useRef)(null),
                        y = "https://image.mux.com/".concat(null === (r = null === (t = f.video) || void 0 === t ? void 0 : t.data.playback_ids[0]) || void 0 === r ? void 0 : r.id),
                        j = "animated.webp?width=640&fps=30",
                        w = v ? "".concat(y, "/").concat(j) : "".concat(y, "/thumbnail.jpg"),
                        _ = (null === (a = f.video) || void 0 === a ? void 0 : a.data.playback_ids) ? w : S.src;
                    (0, i.useEffect)(function() {
                        var e;
                        (e = new Image).src = "".concat(y, "/").concat(j), e.onload = function() {
                            return g(!0)
                        }, e.onerror = function(e) {
                            return console.error(e)
                        }
                    }, []);
                    var N = (null === (o = f.video) || void 0 === o ? void 0 : o.data.playback_ids) ? "https://stream.mux.com/".concat(null === (d = null === (n = f.video) || void 0 === n ? void 0 : null === (s = n.data) || void 0 === s ? void 0 : s.playback_ids[0]) || void 0 === d ? void 0 : d.id, ".m3u8") : "",
                        k = (null === (u = f.video) || void 0 === u ? void 0 : null === (x = u.data) || void 0 === x ? void 0 : null === (h = x.aspect_ratio) || void 0 === h ? void 0 : h.replace(":", "/")) || "16/9";
                    return (0, l.jsx)("div", {
                        className: $(f.text ? "rounded-t-xl" : "rounded-t-xl rounded-b-xl", "relative w-full  overflow-hidden [&>vds-media]:flex"),
                        style: {
                            aspectRatio: k
                        },
                        children: (0, l.jsxs)(L.Sy, {
                            src: N,
                            poster: _,
                            ref: b,
                            userIdleDelay: 1e3,
                            controls: !1,
                            children: [(0, l.jsx)(L.Z2, {
                                className: "[&>shadow-root>video]:w-full"
                            }), (0, l.jsxs)("div", {
                                className: "absolute bottom-0 transition p-4 w-full bg-gradient-to-t from-black to-transparent opacity-100 user-idle:opacity-0",
                                children: [f.rating && p && (0, l.jsxs)("div", {
                                    className: "mb-3",
                                    children: [(0, l.jsx)("div", {
                                        className: "flex w-full justify-end gap-1",
                                        children: (0, l.jsx)(I, {
                                            rating: f.rating
                                        })
                                    }), (0, l.jsxs)("p", {
                                        className: "sr-only",
                                        children: [f.rating, " out of 5 stars"]
                                    })]
                                }), (0, l.jsxs)("div", {
                                    className: "flex w-full justify-between items-center",
                                    children: [(0, l.jsxs)(L.UU, {
                                        className: "flex p-1 ",
                                        "aria-label": "Play",
                                        children: [(0, l.jsx)(eu.Z, {
                                            className: "h-6 w-6 text-white paused:block hidden"
                                        }), (0, l.jsx)(ex.Z, {
                                            className: "h-6 w-6 text-white not-paused:block hidden"
                                        })]
                                    }), (0, l.jsxs)("div", {
                                        className: "flex flex-col text-white items-end",
                                        children: [(0, l.jsx)("p", {
                                            className: "text-md font-semibold",
                                            children: f.author_name
                                        }), (0, l.jsx)("p", {
                                            className: "text-sm",
                                            children: f.author_description
                                        })]
                                    })]
                                })]
                            })]
                        })
                    })
                },
                ef = function(e) {
                    var t = e.testimonial,
                        r = (0, c.K)(function(e) {
                            return e.widget
                        }),
                        a = K(r);
                    return (0, l.jsxs)(l.Fragment, {
                        children: ["testimonial_video" !== t.source && (0, l.jsx)("div", {
                            className: "transition flex p-2 ".concat(ek),
                            "data-id": t.id,
                            children: (0, l.jsxs)("div", {
                                className: $(r.style[r.layout].border.enabled ? "border" : "", "rounded-xl bg-white p-4 w-full"),
                                style: {
                                    backgroundColor: r.style[r.layout].background.color_primary,
                                    borderColor: r.style[r.layout].border.color
                                },
                                children: [t.rating && a && (0, l.jsx)(ed, {
                                    testimonial: t
                                }), (0, l.jsx)(ec, {
                                    testimonial: t
                                }), (0, l.jsx)(ei, {
                                    testimonial: t
                                })]
                            })
                        }), "testimonial_video" === t.source && (0, l.jsxs)("div", {
                            className: "transition flex p-2 flex-col rounded-xl ".concat(ek),
                            "data-id": t.id,
                            children: [(0, l.jsx)(eh, {
                                testimonial: t
                            }), t.text && (0, l.jsx)("div", {
                                className: "p-4 rounded-b-xl",
                                style: (0, es.Z)({
                                    backgroundColor: r.style[r.layout].background.color_primary
                                }, t.text && {
                                    borderLeft: "1px solid ".concat(r.style[r.layout].border.color),
                                    borderRight: "1px solid ".concat(r.style[r.layout].border.color),
                                    borderBottom: "1px solid ".concat(r.style[r.layout].border.color)
                                }),
                                children: (0, l.jsx)(ec, {
                                    testimonial: t
                                })
                            })]
                        })]
                    })
                },
                em = r(1154),
                ev = function(e) {
                    var t = e.testimonial,
                        r = (0, c.K)(function(e) {
                            return e.widget
                        }),
                        a = z(r);
                    return (0, l.jsxs)("div", {
                        className: "flex flex-col items-center mt-4",
                        children: [(0, l.jsxs)("div", {
                            className: "relative max-w-[60px] max-h-[60px] min-w-[60px] min-h-[60px] h-[60px] w-[60px]",
                            children: [(0, l.jsx)(n(), {
                                height: 60,
                                width: 60,
                                src: t.author_picture_url || f.src,
                                alt: t.author_name,
                                className: "rounded-full object-cover flex flex-shrink-0"
                            }), a && (0, l.jsx)(P(), {
                                passHref: !0,
                                href: t.source_url || "https://praisehive.com",
                                children: (0, l.jsx)("a", {
                                    target: "_blank",
                                    rel: "noopener noreferrer nofollow",
                                    className: "absolute flex items-center justify-center w-5 h-5 -bottom-0.5 -right-0.5 rounded-full border-2 border-white",
                                    style: {
                                        background: X(t).background,
                                        borderColor: r.style[r.layout].background.color_primary
                                    },
                                    children: (0, l.jsx)(n(), {
                                        height: 12,
                                        width: 12,
                                        src: X(t).svg.src,
                                        alt: t.source
                                    })
                                })
                            })]
                        }), (0, l.jsx)("p", {
                            className: "text-md font-semibold mt-3",
                            style: {
                                color: r.style[r.layout].author.color_name
                            },
                            children: t.author_name
                        }), (0, l.jsx)("a", {
                            href: t.author_custom_url || void 0,
                            target: "_blank",
                            rel: "noopener noreferrer",
                            className: "text-sm mt-0.5",
                            style: {
                                color: r.style[r.layout].author.color_description
                            },
                            children: (0, l.jsx)("p", {
                                children: t.author_description
                            })
                        })]
                    })
                },
                eg = function(e) {
                    var t, r = e.testimonial,
                        a = (0, c.K)(function(e) {
                            return e.widget
                        }),
                        o = a.style[a.layout].text.color_text_highlight || R;
                    return (0, l.jsxs)(l.Fragment, {
                        children: [!!(null === (t = r.attachments) || void 0 === t ? void 0 : t.length) && (0, l.jsx)("div", {
                            className: "flex justify-center mb-2 gap-2 flex-wrap",
                            children: r.attachments.map(function(e, t) {
                                return e.visible ? "image" === e.type ? (0, l.jsx)("div", {
                                    className: $(e.visible ? "" : "grayscale", "relative h-20 rounded-md overflow-hidden"),
                                    style: {
                                        aspectRatio: e.width / e.height
                                    },
                                    children: (0, l.jsx)(n(), {
                                        src: e.image_url,
                                        width: e.width,
                                        height: e.height,
                                        alt: "Image attachment"
                                    })
                                }, t) : (0, l.jsx)(l.Fragment, {}) : (0, l.jsx)(l.Fragment, {})
                            })
                        }), (0, l.jsx)("div", {
                            className: "prose prose-p:my-0 prose-a:font-semibold prose-a:no-underline text-center",
                            style: {
                                color: a.style[a.layout].text.color_text
                            },
                            children: (0, l.jsx)(m.D, {
                                components: {
                                    a: function(e) {
                                        return (0, l.jsx)("a", {
                                            href: e.href,
                                            target: "_blank",
                                            rel: "noopener noreferrer",
                                            children: e.children
                                        })
                                    },
                                    strong: function(e) {
                                        return (0, l.jsx)("strong", {
                                            className: "inline box-decoration-clone rounded py-[0.5]",
                                            style: {
                                                boxShadow: "3px 0 0 ".concat(o, ", -3px 0 0 ").concat(o),
                                                background: o
                                            },
                                            children: e.children
                                        })
                                    }
                                },
                                children: r.text
                            })
                        })]
                    })
                },
                ep = function(e) {
                    var t = e.testimonial;
                    return (0, l.jsxs)("div", {
                        className: "mt-3",
                        children: [(0, l.jsx)("div", {
                            className: "flex justify-center items-center gap-1",
                            children: (0, l.jsx)(I, {
                                rating: t.rating
                            })
                        }), (0, l.jsxs)("p", {
                            className: "sr-only",
                            children: [t.rating, " out of 5 stars"]
                        })]
                    })
                },
                eb = function(e) {
                    var t = e.testimonial,
                        r = (0, c.K)(function(e) {
                            return e.widget
                        }),
                        a = K(r);
                    return (0, l.jsxs)(l.Fragment, {
                        children: ["testimonial_video" !== t.source && (0, l.jsx)("div", {
                            className: "transition flex p-2 ".concat(ek),
                            "data-id": t.id,
                            children: (0, l.jsxs)("div", {
                                className: $(r.style[r.layout].border.enabled ? "border" : "", "rounded-xl bg-white p-4 w-full"),
                                style: {
                                    backgroundColor: r.style[r.layout].background.color_primary,
                                    borderColor: r.style[r.layout].border.color
                                },
                                children: [(0, l.jsx)(eg, {
                                    testimonial: t
                                }), (0, l.jsx)(ev, {
                                    testimonial: t
                                }), t.rating && a && (0, l.jsx)(ep, {
                                    testimonial: t
                                })]
                            })
                        }), "testimonial_video" === t.source && (0, l.jsxs)("div", {
                            className: "transition flex p-2 flex-col rounded-xl ".concat(ek),
                            "data-id": t.id,
                            children: [(0, l.jsx)(eh, {
                                testimonial: t
                            }), t.text && (0, l.jsx)("div", {
                                className: "p-4 rounded-b-xl",
                                style: (0, es.Z)({
                                    backgroundColor: r.style[r.layout].background.color_primary
                                }, t.text && {
                                    borderLeft: "1px solid ".concat(r.style[r.layout].border.color),
                                    borderRight: "1px solid ".concat(r.style[r.layout].border.color),
                                    borderBottom: "1px solid ".concat(r.style[r.layout].border.color)
                                }),
                                children: (0, l.jsx)(eg, {
                                    testimonial: t
                                })
                            })]
                        })]
                    })
                },
                ey = function(e) {
                    var t = e.testimonial,
                        r = (0, c.K)(function(e) {
                            return e.widget
                        }),
                        a = z(r);
                    return (0, l.jsxs)("div", {
                        className: "mt-4 flex w-full justify-between items-end",
                        children: [(0, l.jsxs)("div", {
                            children: [(0, l.jsxs)("p", {
                                className: "text-md font-semibold",
                                style: {
                                    color: r.style[r.layout].author.color_name
                                },
                                children: ["— ", t.author_name]
                            }), (0, l.jsx)("a", {
                                href: t.author_custom_url || void 0,
                                target: "_blank",
                                rel: "noopener noreferrer",
                                className: "text-sm mt-1",
                                style: {
                                    color: r.style[r.layout].author.color_description
                                },
                                children: (0, l.jsx)("p", {
                                    children: t.author_description
                                })
                            })]
                        }), a && (0, l.jsx)(P(), {
                            passHref: !0,
                            href: t.source_url || "https://praisehive.com",
                            children: (0, l.jsx)("a", {
                                target: "_blank",
                                rel: "noopener noreferrer nofollow",
                                className: "flex flex-shrink-0 items-center justify-center w-5 h-5 pb-1 rounded-full ",
                                children: (0, l.jsx)(n(), {
                                    height: 20,
                                    width: 20,
                                    src: X(t).svg.src,
                                    alt: t.source
                                })
                            })
                        })]
                    })
                },
                ej = function(e) {
                    var t, r = e.testimonial,
                        a = (0, c.K)(function(e) {
                            return e.widget
                        }),
                        o = a.style[a.layout].text.color_text_highlight || R;
                    return (0, l.jsxs)(l.Fragment, {
                        children: [(0, l.jsx)("div", {
                            className: "prose prose-p:my-0 prose-a:font-semibold prose-a:no-underline",
                            style: {
                                color: a.style[a.layout].text.color_text
                            },
                            children: (0, l.jsx)(m.D, {
                                components: {
                                    a: function(e) {
                                        return (0, l.jsx)("a", {
                                            href: e.href,
                                            target: "_blank",
                                            rel: "noopener noreferrer",
                                            children: e.children
                                        })
                                    },
                                    strong: function(e) {
                                        return (0, l.jsx)("strong", {
                                            className: "inline box-decoration-clone rounded py-[0.5]",
                                            style: {
                                                boxShadow: "3px 0 0 ".concat(o, ", -3px 0 0 ").concat(o),
                                                background: o
                                            },
                                            children: e.children
                                        })
                                    }
                                },
                                children: r.text
                            })
                        }), !!(null === (t = r.attachments) || void 0 === t ? void 0 : t.length) && (0, l.jsx)("div", {
                            className: "flex mt-2 gap-2 flex-wrap",
                            children: r.attachments.map(function(e, t) {
                                return e.visible ? "image" === e.type ? (0, l.jsx)("div", {
                                    className: $(e.visible ? "" : "grayscale", "relative h-20 rounded-md overflow-hidden"),
                                    style: {
                                        aspectRatio: e.width / e.height
                                    },
                                    children: (0, l.jsx)(n(), {
                                        src: e.image_url,
                                        width: e.width,
                                        height: e.height,
                                        alt: "Image attachment"
                                    })
                                }, t) : (0, l.jsx)(l.Fragment, {}) : (0, l.jsx)(l.Fragment, {})
                            })
                        })]
                    })
                },
                ew = function(e) {
                    var t = e.testimonial;
                    return (0, l.jsxs)("div", {
                        className: "mb-3",
                        children: [(0, l.jsx)("div", {
                            className: "flex items-center gap-1",
                            children: (0, l.jsx)(I, {
                                rating: t.rating
                            })
                        }), (0, l.jsxs)("p", {
                            className: "sr-only",
                            children: [t.rating, " out of 5 stars"]
                        })]
                    })
                },
                e_ = function(e) {
                    var t = e.testimonial;
                    return (0, l.jsx)("div", {
                        className: "max-w-[160px] max-h-[160px] min-w-[160px] min-h-[160px] h-[160px] w-[160px] mb-4 ",
                        children: (0, l.jsx)(n(), {
                            height: 160,
                            width: 160,
                            src: t.author_picture_url || f.src,
                            alt: t.author_name,
                            className: "rounded-xl object-cover",
                            quality: 100
                        })
                    })
                },
                eN = function(e) {
                    var t = e.testimonial,
                        r = (0, c.K)(function(e) {
                            return e.widget
                        }),
                        a = K(r);
                    return (0, l.jsxs)(l.Fragment, {
                        children: ["testimonial_video" !== t.source && (0, l.jsx)("div", {
                            className: "transition flex p-2 ".concat(ek),
                            "data-id": t.id,
                            children: (0, l.jsxs)("div", {
                                className: $(r.style[r.layout].border.enabled ? "border" : "", "rounded-xl bg-white p-4 w-full"),
                                style: {
                                    backgroundColor: r.style[r.layout].background.color_primary,
                                    borderColor: r.style[r.layout].border.color
                                },
                                children: [(0, l.jsx)(e_, {
                                    testimonial: t
                                }), t.rating && a && (0, l.jsx)(ew, {
                                    testimonial: t
                                }), (0, l.jsx)(ej, {
                                    testimonial: t
                                }), (0, l.jsx)(ey, {
                                    testimonial: t
                                })]
                            })
                        }), "testimonial_video" === t.source && (0, l.jsxs)("div", {
                            className: "transition flex p-2 flex-col rounded-xl ".concat(ek),
                            "data-id": t.id,
                            children: [(0, l.jsx)(eh, {
                                testimonial: t
                            }), t.text && (0, l.jsx)("div", {
                                className: "p-4 rounded-b-xl",
                                style: (0, es.Z)({
                                    backgroundColor: r.style[r.layout].background.color_primary
                                }, t.text && {
                                    borderLeft: "1px solid ".concat(r.style[r.layout].border.color),
                                    borderRight: "1px solid ".concat(r.style[r.layout].border.color),
                                    borderBottom: "1px solid ".concat(r.style[r.layout].border.color)
                                }),
                                children: (0, l.jsx)(ej, {
                                    testimonial: t
                                })
                            })]
                        })]
                    })
                },
                ek = "h-fit w-full sm:w-[50%] lg:w-[33.33%]",
                eC = function() {
                    var e = (0, c.K)(function(e) {
                            return e.widget
                        }),
                        t = e.style.masonry.display,
                        r = [{
                            columns: 1,
                            gutter: 0
                        }, {
                            mq: "640px",
                            columns: 2,
                            gutter: 0
                        }, {
                            mq: "1024px",
                            columns: 3,
                            gutter: 0
                        }, ];
                    return (0, i.useEffect)(function() {
                        window.document.documentElement.style.removeProperty("width")
                    }), (0, i.useEffect)(function() {
                        var e = new em.Z({
                            container: "#masonry-container",
                            packed: "data-masonry-item",
                            sizes: r
                        });
                        window.addEventListener("resize", function(t) {
                            var r = document.getElementById("masonry-wrapper"),
                                l = document.getElementById("masonry-container");
                            r && l && (l.style.width = r.clientWidth + "px", e.pack())
                        }), e.resize(!0).pack()
                    }), (0, l.jsx)("div", {
                        id: "masonry-wrapper",
                        className: "mx-auto w-full overflow-hidden",
                        children: (0, l.jsx)("div", {
                            id: "masonry-container",
                            children: e.testimonials.map(function(e) {
                                return (0, l.jsxs)(i.Fragment, {
                                    children: ["masonry_default" === t && (0, l.jsx)(ef, {
                                        testimonial: e
                                    }, e.id), "masonry_simple_centered" === t && (0, l.jsx)(eb, {
                                        testimonial: e
                                    }, e.id), "masonry_simple_left_aligned" === t && (0, l.jsx)(eN, {
                                        testimonial: e
                                    }, e.id)]
                                }, e.id)
                            })
                        })
                    })
                },
                eA = function() {
                    for (var e, t, r, a, o, s, i, d, u, x, h = (0, c.K)(function(e) {
                            return e.widget
                        }), m = h.style.avatars, v = !!(null == m ? void 0 : m.text), g = v ? m.text.enabled : F.text.enabled, p = v ? m.text.custom_text : F.text.custom_text, b = (null == m ? void 0 : null === (t = m.text) || void 0 === t ? void 0 : t.color_text) || F.text.color_text, y = K(h), j = (null == m ? void 0 : null === (r = m.rating) || void 0 === r ? void 0 : r.average) ? m.rating.average.enabled : F.rating.average.enabled, w = (null === (a = m.rating) || void 0 === a ? void 0 : null === (o = a.average) || void 0 === o ? void 0 : o.color_text) || F.rating.average.color_text, _ = (null == m ? void 0 : null === (s = m.avatars) || void 0 === s ? void 0 : null === (i = s.border) || void 0 === i ? void 0 : i.color) || F.avatars.border.color, N = (null == m ? void 0 : null === (d = m.avatars) || void 0 === d ? void 0 : null === (u = d.border) || void 0 === u ? void 0 : u.width) || F.avatars.border.width, k = (null == m ? void 0 : null === (x = m.avatars) || void 0 === x ? void 0 : x.count) || F.avatars.count, C = [], A = 0; A < k; A++) h.testimonials[A] ? C.push(h.testimonials[A]) : C.push({
                        author_picture_url: null
                    });
                    return (0, l.jsxs)("div", {
                        className: "flex gap-3",
                        children: [(0, l.jsx)("div", {
                            className: "flex -space-x-[14px] overflow-hidden",
                            children: C.map(function(e, t) {
                                return (0, l.jsxs)("div", {
                                    className: "flex group relative flex-shrink-0  rounded-full",
                                    style: {
                                        borderWidth: N,
                                        borderColor: _,
                                        width: "42px",
                                        height: "42px",
                                        background: _
                                    },
                                    children: [(0, l.jsx)(n(), {
                                        src: e.author_picture_url || f.src,
                                        height: 42,
                                        width: 42,
                                        alt: e.author_name,
                                        className: "rounded-full object-cover flex flex-shrink-0"
                                    }), !h.white_label_enabled && (0, l.jsx)("a", {
                                        href: "https://praisehive.com?source=widget_avatars",
                                        target: "_blank",
                                        rel: "noopener noreferrer",
                                        className: " flex items-center justify-center absolute  flex-shrink-0  rounded-full duration-75 opacity-0 bg-transparent  group-hover:bg-gray-900 group-hover:opacity-100",
                                        style: {
                                            left: -N + "px",
                                            top: -N + "px",
                                            width: "42px",
                                            height: "42px"
                                        },
                                        children: (0, l.jsx)(n(), {
                                            src: H.src,
                                            height: 22,
                                            width: 22,
                                            alt: "PraiseHive.com",
                                            className: "rounded-full object-cover flex flex-shrink-0"
                                        })
                                    }), h.white_label_enabled && (0, l.jsx)("a", {
                                        href: e.source_url || void 0,
                                        target: "_blank",
                                        rel: "noopener noreferrer",
                                        className: "flex items-center justify-center absolute flex-shrink-0 rounded-full",
                                        style: {
                                            left: -N + "px",
                                            top: -N + "px",
                                            width: "42px",
                                            height: "42px"
                                        }
                                    })]
                                }, e.id || t)
                            })
                        }), (y || g) && (0, l.jsxs)("div", {
                            className: "flex flex-col space-y-0.5 justify-center",
                            children: [y && (0, l.jsxs)("div", {
                                className: "flex items-end gap-1.5 -ml-0.5",
                                children: [(0, l.jsx)("div", {
                                    className: "flex gap-1 ",
                                    children: (0, l.jsx)(I, {
                                        rating: 5
                                    })
                                }), j && (0, l.jsx)("p", {
                                    className: "text-base font-semibold leading-4",
                                    style: {
                                        color: w
                                    },
                                    children: ((e = h.testimonials.filter(function(e) {
                                        return void 0 !== e.rating && null !== e.rating
                                    })).reduce(function(e, t) {
                                        return e + t.rating
                                    }, 0) / e.length).toFixed(1)
                                })]
                            }), g && (0, l.jsx)("p", {
                                className: "text-sm font-medium whitespace-nowrap",
                                style: {
                                    color: b
                                },
                                children: p || "From ".concat(h.testimonials.length, " testimonials")
                            })]
                        })]
                    })
                },
                eP = function() {
                    for (var e, t, r, a, o, s, i, d, u, x, h = (0, c.K)(function(e) {
                            return e.widget
                        }), m = h.style.avatars, v = !!(null == m ? void 0 : m.text), g = v ? m.text.enabled : F.text.enabled, p = v ? m.text.custom_text : F.text.custom_text, b = (null == m ? void 0 : null === (t = m.text) || void 0 === t ? void 0 : t.color_text) || F.text.color_text, y = K(h), j = (null == m ? void 0 : null === (r = m.rating) || void 0 === r ? void 0 : r.average) ? m.rating.average.enabled : F.rating.average.enabled, w = (null === (a = m.rating) || void 0 === a ? void 0 : null === (o = a.average) || void 0 === o ? void 0 : o.color_text) || F.rating.average.color_text, _ = (null == m ? void 0 : null === (s = m.avatars) || void 0 === s ? void 0 : null === (i = s.border) || void 0 === i ? void 0 : i.color) || F.avatars.border.color, N = (null == m ? void 0 : null === (d = m.avatars) || void 0 === d ? void 0 : null === (u = d.border) || void 0 === u ? void 0 : u.width) || F.avatars.border.width, k = (null == m ? void 0 : null === (x = m.avatars) || void 0 === x ? void 0 : x.count) || F.avatars.count, C = [], A = 0; A < k; A++) h.testimonials[A] ? C.push(h.testimonials[A]) : C.push({
                        author_picture_url: null
                    });
                    return (0, l.jsxs)("div", {
                        className: "flex flex-col gap-1.5",
                        children: [(0, l.jsx)("div", {
                            className: "flex -space-x-[12px] overflow-hidden",
                            children: C.map(function(e, t) {
                                return (0, l.jsxs)("div", {
                                    className: "group relative flex flex-shrink-0 rounded-full",
                                    style: {
                                        borderWidth: N,
                                        borderColor: _,
                                        background: _,
                                        width: "42px",
                                        height: "42px"
                                    },
                                    children: [(0, l.jsx)(n(), {
                                        src: e.author_picture_url || f.src,
                                        height: 42,
                                        width: 42,
                                        alt: e.author_name,
                                        className: "rounded-full object-cover flex flex-shrink-0"
                                    }), !h.white_label_enabled && (0, l.jsx)("a", {
                                        href: "https://praisehive.com?source=widget_avatars",
                                        target: "_blank",
                                        rel: "noopener noreferrer",
                                        className: " flex items-center justify-center absolute  flex-shrink-0 rounded-full duration-75 opacity-0 bg-transparent  group-hover:bg-gray-900 group-hover:opacity-100",
                                        style: {
                                            left: -N + "px",
                                            top: -N + "px",
                                            width: "42px",
                                            height: "42px"
                                        },
                                        children: (0, l.jsx)(n(), {
                                            src: H.src,
                                            height: 22,
                                            width: 22,
                                            alt: "PraiseHive.com",
                                            className: "rounded-full object-cover flex flex-shrink-0"
                                        })
                                    }), h.white_label_enabled && (0, l.jsx)("a", {
                                        href: e.source_url || void 0,
                                        target: "_blank",
                                        rel: "noopener noreferrer",
                                        className: "flex items-center justify-center absolute  flex-shrink-0 rounded-full",
                                        style: {
                                            left: -N + "px",
                                            top: -N + "px",
                                            width: "42px",
                                            height: "42px"
                                        }
                                    })]
                                }, e.id || t)
                            })
                        }), (y || g) && (0, l.jsxs)("div", {
                            className: "flex gap-[10px]",
                            children: [y && (0, l.jsxs)("div", {
                                className: "flex items-end gap-1.5",
                                children: [(0, l.jsx)("div", {
                                    className: "flex gap-0.5 ",
                                    children: (0, l.jsx)(I, {
                                        rating: 5
                                    })
                                }), j && (0, l.jsx)("p", {
                                    className: "text-base font-semibold leading-4",
                                    style: {
                                        color: w
                                    },
                                    children: ((e = h.testimonials.filter(function(e) {
                                        return void 0 !== e.rating && null !== e.rating
                                    })).reduce(function(e, t) {
                                        return e + t.rating
                                    }, 0) / e.length).toFixed(1)
                                })]
                            }), g && (0, l.jsx)("p", {
                                className: "flex items-end text-sm font-medium leading-[14px] whitespace-nowrap",
                                style: {
                                    color: b
                                },
                                children: p || "(".concat(h.testimonials.length, " reviews)")
                            })]
                        })]
                    })
                },
                eS = function() {
                    for (var e, t, r, a, o, s, i, d, u, x = (0, c.K)(function(e) {
                            return e.widget
                        }), h = x.style.avatars, m = !!(null == h ? void 0 : h.text), v = m ? h.text.enabled : F.text.enabled, g = m ? h.text.custom_text : F.text.custom_text, p = (null == h ? void 0 : null === (e = h.text) || void 0 === e ? void 0 : e.color_text) || F.text.color_text, b = K(x), y = (null == h ? void 0 : null === (t = h.rating) || void 0 === t ? void 0 : t.average) ? h.rating.average.enabled : F.rating.average.enabled, j = (null === (r = h.rating) || void 0 === r ? void 0 : null === (a = r.average) || void 0 === a ? void 0 : a.color_text) || F.rating.average.color_text, w = (null == h ? void 0 : null === (o = h.avatars) || void 0 === o ? void 0 : null === (s = o.border) || void 0 === s ? void 0 : s.color) || F.avatars.border.color, _ = (null == h ? void 0 : null === (i = h.avatars) || void 0 === i ? void 0 : null === (d = i.border) || void 0 === d ? void 0 : d.width) || F.avatars.border.width, N = (null == h ? void 0 : null === (u = h.avatars) || void 0 === u ? void 0 : u.count) || F.avatars.count, k = [], C = 0; C < N; C++) x.testimonials[C] ? k.push(x.testimonials[C]) : k.push({
                        author_picture_url: null
                    });
                    var A, P = Math.trunc(k.length / 2);
                    return (0, l.jsxs)("div", {
                        className: "flex flex-col gap-3",
                        children: [(0, l.jsx)("div", {
                            className: "flex items-center -space-x-[12px] overflow-hidden",
                            children: k.map(function(e, t) {
                                var r = Math.abs((P - t) * 8),
                                    a = 58 - r;
                                return (0, l.jsxs)("div", {
                                    className: "group relative flex flex-shrink-0 rounded-full",
                                    style: {
                                        borderWidth: _,
                                        borderColor: w,
                                        background: w,
                                        height: a + "px",
                                        width: a + "px",
                                        zIndex: 0 === r ? "auto" : -r
                                    },
                                    children: [(0, l.jsx)(n(), {
                                        src: e.author_picture_url || f.src,
                                        height: a,
                                        width: a,
                                        alt: e.author_name,
                                        className: "rounded-full object-cover flex flex-shrink-0"
                                    }), !x.white_label_enabled && (0, l.jsx)("a", {
                                        href: "https://praisehive.com?source=widget_avatars",
                                        target: "_blank",
                                        rel: "noopener noreferrer",
                                        className: " flex items-center justify-center absolute  flex-shrink-0 rounded-full duration-75 opacity-0 bg-transparent  group-hover:bg-gray-900 group-hover:opacity-100",
                                        style: {
                                            height: a + "px",
                                            width: a + "px",
                                            left: -_ + "px",
                                            top: -_ + "px"
                                        },
                                        children: (0, l.jsx)(n(), {
                                            src: H.src,
                                            height: a / 2,
                                            width: a / 2,
                                            alt: "PraiseHive.com",
                                            className: "rounded-full object-cover flex flex-shrink-0"
                                        })
                                    }), x.white_label_enabled && (0, l.jsx)("a", {
                                        href: e.source_url || void 0,
                                        target: "_blank",
                                        rel: "noopener noreferrer",
                                        className: "flex items-center justify-center absolute flex-shrink-0 rounded-full",
                                        style: {
                                            height: a + "px",
                                            width: a + "px",
                                            left: -_ + "px",
                                            top: -_ + "px"
                                        }
                                    })]
                                }, e.id || t)
                            })
                        }), (b || v) && (0, l.jsxs)("div", {
                            className: "flex flex-col items-center gap-0.5",
                            children: [b && (0, l.jsxs)("div", {
                                className: "flex items-end gap-1.5",
                                children: [(0, l.jsx)("div", {
                                    className: "flex gap-1",
                                    children: (0, l.jsx)(I, {
                                        rating: 5,
                                        size: "md"
                                    })
                                }), y && (0, l.jsx)("p", {
                                    className: "text-lg font-semibold leading-[18px]",
                                    style: {
                                        color: j
                                    },
                                    children: ((A = x.testimonials.filter(function(e) {
                                        return void 0 !== e.rating && null !== e.rating
                                    })).reduce(function(e, t) {
                                        return e + t.rating
                                    }, 0) / A.length).toFixed(1)
                                })]
                            }), v && (0, l.jsx)("p", {
                                className: "flex items-end whitespace-nowrap",
                                style: {
                                    color: p
                                },
                                children: g || "Join ".concat(x.testimonials.length, " satisfied users")
                            })]
                        })]
                    })
                },
                eF = function() {
                    var e, t = (null === (e = (0, c.K)(function(e) {
                        return e.widget
                    }).style.avatars) || void 0 === e ? void 0 : e.display) || F.display;
                    switch ((0, i.useEffect)(function() {
                        window.document.documentElement.style.width = "fit-content"
                    }), t) {
                        case "avatars_default_horizontal":
                            return (0, l.jsx)(eA, {});
                        case "avatars_default_vertical":
                            return (0, l.jsx)(eP, {});
                        case "avatars_bubble":
                            return (0, l.jsx)(eS, {});
                        default:
                            return null
                    }
                },
                eB = function() {
                    var e = (0, c.K)(function(e) {
                            return e.widget
                        }),
                        t = e.layout,
                        r = function() {
                            switch (t) {
                                case "carousel":
                                    return (0, l.jsx)(en, {});
                                case "masonry":
                                    return (0, l.jsx)(eC, {});
                                case "avatars":
                                    return (0, l.jsx)(eF, {});
                                default:
                                    return null
                            }
                        };
                    return "avatars" === t ? (0, l.jsx)("div", {
                        className: "w-fit",
                        children: r()
                    }) : (0, l.jsxs)(l.Fragment, {
                        children: [r(), !e.white_label_enabled && (0, l.jsx)(s, {})]
                    })
                }
        }
    }
]);